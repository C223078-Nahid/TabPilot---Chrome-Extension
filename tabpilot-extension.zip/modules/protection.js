/**
 * TabPilot — protection.js
 * Tab protection (per-tab) & domain whitelist.
 *
 * v1.6.4 model (user-requested rework of the v1.6.x site-level model):
 * marking a tab protected protects EXACTLY THAT TAB — never its sibling
 * tabs of the same site. Protection means both of these:
 *  1. TabPilot's optimizer never discards it — a hard rule ("Keep
 *     user-protected tabs" is always enforced), applied to every trigger
 *     including explicit selections.
 *  2. CHROME will not discard it either: the tab is marked
 *     chrome.tabs.update(tabId, { autoDiscardable: false }). That flag
 *     removes the tab from Chrome's own automatic-discard eligibility —
 *     Memory Saver and the internal discards list — no matter how long
 *     the tab sits unused. Unprotecting restores autoDiscardable: true,
 *     UNLESS the tab was already non-discardable before TabPilot touched
 *     it (preset), in which case the user's own Chrome flag is left
 *     untouched.
 *
 * Storage (v3 shape, chrome.storage.local key tp:protectedTabs):
 *   { v: 3, tabs: { [tabId]: { ts, preset } } }
 *  - ONLY numeric tab ids and timestamps are stored — no hostname, no
 *    title, no URL, nothing that identifies a site. (The v1.6.x model
 *    persisted http(s) hostnames; the v3 model stores strictly less.)
 *  - Tab ids are session-scoped: they change on every browser restart,
 *    so per-tab protection lasts UNTIL THE BROWSER CLOSES. It does
 *    survive service-worker restarts and extension updates/reloads
 *    (see reconcile below) — which is the most a "this specific tab
 *    only" promise can honestly offer.
 *  - A RAM-backed session marker (tp:sessionEpoch) says "these ids
 *    belong to the CURRENT browser session". It is wiped when the
 *    browser exits (ids now stale) and when the extension is reloaded
 *    (ids still valid — reconcile tells the two apart by the flag).
 *
 * Reconciliation (browser startup / install / update):
 *  - LEGACY SHAPES are MIGRATED once: v1.5's { [tabId]: {domain, …} }
 *    and v1.6's { v: 2, sites: { [host]: ts } } are folded into a set of
 *    site keys; every currently OPEN tab of those sites is protected
 *    per-tab (flag + entry), and the stored value is REPLACED with the
 *    v3 shape — the hostnames actively leave the disk (privacy), and
 *    the open tabs keep protection under the new per-tab semantics.
 *  - Same live session (session marker present): entries whose tab no
 *    longer exists are dropped; the autoDiscardable flag is re-asserted
 *    for surviving entries (drift repair).
 *  - Marker missing (browser restarted OR extension reloaded): an
 *    entry survives only when its tab id still exists AND still has
 *    autoDiscardable === false. After a browser restart, restored tabs
 *    come back with the default (discardable) flag, so all stale ids
 *    drop; after an in-session extension reload the browser — and our
 *    flags — stayed alive, so the entries are re-adopted and the marker
 *    is re-armed.
 *  - tabs.onReplaced (prerender swap replaces the tab id): the service
 *    worker moves the entry to the new id and re-asserts the flag.
 *
 * PRIVACY: nothing but whitelisted domains (Settings) and numeric tab
 * ids + timestamps ever reaches disk. No tab title, no URL, no hostname
 * of a protected tab — for any scheme (file:, chrome:, incognito, …).
 * Per-tab keys carry no browsing data at all, which is what made the
 * old site/session split unnecessary: every tab is protected the same
 * way, incognito or not, because the stored key is just a number.
 *
 * WHITELIST: the Settings-managed domain whitelist is UNCHANGED and
 * deliberately coarser — suffix-matched per domain, bypassable by an
 * explicit selection, seeded on fresh installs. It covers "sites I
 * never want auto-discarded"; the shield covers "this exact tab".
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;
  const Storage = TP.Storage;

  /**
   * True only for http(s) URLs — the only schemes whose "hostname" is a
   * real network host. Used ONLY to fold legacy site maps into per-tab
   * protection during migration (v1.6.x stored hostnames; v1.6.4 does
   * not persist hostnames at all). chrome://settings has hostname
   * "settings" and must never be matched against a whitelist entry or
   * legacy site key (v1.6.1 audit N5).
   */
  function isHttpSite(url) {
    if (typeof url !== 'string' || !url) return false;
    const scheme = (url.split(':')[0] || '').toLowerCase();
    return scheme === 'http' || scheme === 'https';
  }

  /**
   * Site key (hostname, "www." stripped) of an http(s) URL — the key of
   * the LEGACY v1.6.x sites map, kept for the one-time migration only.
   * '' for every other scheme.
   */
  function siteKeyOf(url) {
    if (!isHttpSite(url)) return '';
    const host = Util.hostnameOf(url);
    if (!host) return '';
    return host.indexOf('www.') === 0 ? host.slice(4) : host;
  }

  /* ------------------------------------------------------------------ *
   * Stored map (v3) helpers
   * ------------------------------------------------------------------ */

  function isV3(raw) {
    return !!(raw && typeof raw === 'object' && !Array.isArray(raw) &&
      raw.v === 3 && raw.tabs && typeof raw.tabs === 'object' &&
      !Array.isArray(raw.tabs));
  }

  /** Sanitize an arbitrary value into a clean v3 tabs map (no writes). */
  function sanitizeTabs(rawTabs) {
    const out = {};
    if (!rawTabs || typeof rawTabs !== 'object' || Array.isArray(rawTabs)) return out;
    Object.keys(rawTabs).forEach(function (key) {
      const id = Number(key);
      if (!isFinite(id) || id < 0) return;           // not a tab id: drop
      const entry = rawTabs[key];
      if (entry && typeof entry === 'object') {
        out[id] = { ts: typeof entry.ts === 'number' ? entry.ts : Date.now(),
                    preset: entry.preset === true };
      } else if (typeof entry === 'number') {         // tolerated short shape
        out[id] = { ts: entry, preset: false };
      }
    });
    return out;
  }

  function emptyV3() {
    return { v: 3, tabs: {} };
  }

  function writeMap(tabsMap) {
    return Storage.set(Storage.KEYS.PROTECTED_TABS, { v: 3, tabs: tabsMap });
  }

  /**
   * Read the protection map. One-time migration: a legacy v1.5/v1.6
   * stored value is converted to v3 (see migrateLegacySites) before it
   * is returned — readers never see the old shapes.
   */
  function readMap() {
    return Storage.get(Storage.KEYS.PROTECTED_TABS).then(function (raw) {
      if (raw === undefined) return {};              // fresh profile: nothing stored
      if (isV3(raw)) return sanitizeTabs(raw.tabs);
      return migrateLegacySites(raw).then(function (migrated) {
        return migrated.tabs;
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * Chrome-level auto-discard flag
   * ------------------------------------------------------------------ */

  /**
   * Set/clear the tab's Chrome auto-discard flag. This is what keeps
   * Chrome's Memory Saver and the internal discards list away from the
   * tab: a tab with autoDiscardable:false is never auto-discarded, no
   * matter how long it has been unused.
   */
  function setAutoDiscardable(tabId, value) {
    return Util.callApi(chrome.tabs, 'update', tabId, { autoDiscardable: value });
  }

  /* ------------------------------------------------------------------ *
   * State + pure checks
   * ------------------------------------------------------------------ */

  /**
   * Read the protection state: whitelist + per-tab protected map, in
   * one object for the pure checkers below.
   * { whitelist: [...], protectedTabs: { [tabId]: { ts, preset } } }
   */
  function getState() {
    return Promise.all([
      Storage.get(Storage.KEYS.WHITELIST),
      readMap()
    ]).then(function (results) {
      const whitelist = Array.isArray(results[0]) ? results[0].filter(function (d) {
        return typeof d === 'string' && d;
      }) : [];
      return { whitelist: whitelist, protectedTabs: results[1] };
    });
  }

  /**
   * Explicit protection check. reason 'user' = THIS EXACT TAB is
   * protected (tab id in the map) — sibling tabs of the same site are
   * NOT covered (v1.6.4). reason 'domain' = whitelisted domain
   * (http(s) only — v1.6.1 audit N5: chrome://settings must not match
   * an intranet "settings" whitelist entry).
   * Returns { protected: boolean, reason: 'user' | 'domain' | null }.
   */
  function isTabProtected(tab, state) {
    const st = state || {};
    const protectedTabs = st.protectedTabs || {};
    if (tab && protectedTabs[tab.id]) {
      return { protected: true, reason: 'user' };
    }
    if (isHttpSite(tab && tab.url)) {
      const whitelist = Array.isArray(st.whitelist) ? st.whitelist : [];
      const host = Util.hostnameOf(tab && tab.url);
      if (host) {
        for (let i = 0; i < whitelist.length; i++) {
          if (Util.matchesDomain(host, whitelist[i])) {
            return { protected: true, reason: 'domain' };
          }
        }
      }
    }
    return { protected: false, reason: null };
  }

  /** Combined check used for badges/UI: explicit + rule-based protection. */
  function isTabShielded(tab, ctx) {
    // ctx = { state, settings, activeIds:Set }
    const explicit = isTabProtected(tab, ctx.state);
    if (explicit.protected) return explicit;
    if (tab && tab.pinned && ctx.settings.protection.neverPinned) return { protected: true, reason: 'pinned' };
    if (tab && tab.audible && ctx.settings.protection.neverAudible) return { protected: true, reason: 'audible' };
    if (tab && tab.active && ctx.settings.protection.neverActive) return { protected: true, reason: 'active' };
    return { protected: false, reason: null };
  }

  /**
   * Honest description of what protecting THIS tab means (v1.6.4): the
   * protection is per-tab and session-scoped, for every tab and every
   * scheme — { kind: 'tab', durable: false }. `state` is accepted for
   * API compatibility and ignored.
   */
  function protectionScopeOf(tab, state) {
    return { kind: 'tab', durable: false };
  }

  /* ------------------------------------------------------------------ *
   * Mutations
   * ------------------------------------------------------------------ */

  /**
   * Protect EXACTLY THIS TAB:
   *  1. mark it non-auto-discardable in Chrome (the promise the feature
   *     makes — so it must succeed; a closed/unflaggable tab rejects);
   *  2. record the tab id + timestamp in the v3 map.
   * `preset` is true when the tab was ALREADY autoDiscardable:false
   * before us (the user's own chrome://discards flag) — unprotect then
   * leaves that flag untouched instead of resetting it.
   * A re-protect of an already-protected tab just refreshes the
   * timestamp and keeps the recorded preset.
   */
  function protectTab(tab) {
    const id = tab && typeof tab.id === 'number' ? tab.id : null;
    if (id == null) {
      return Promise.reject(new Error('Cannot protect this tab — its id is not available'));
    }
    return setAutoDiscardable(id, false).then(function () {
      return readMap().then(function (tabsMap) {
        const prev = tabsMap[id];
        tabsMap[id] = {
          ts: Date.now(),
          preset: prev ? prev.preset === true : tab.autoDiscardable === false
        };
        return writeMap(tabsMap).then(function () { return true; });
      });
    });
  }

  /**
   * Remove THIS TAB's protection: drop the map entry and restore
   * Chrome's autoDiscardable flag to true — unless the tab was already
   * non-discardable before TabPilot touched it (preset), in which case
   * the user's own flag is kept. A closed tab simply loses its entry.
   */
  function unprotectTab(tab) {
    const id = tab && typeof tab.id === 'number' ? tab.id : null;
    if (id == null) return Promise.resolve(false);
    return readMap().then(function (tabsMap) {
      const entry = tabsMap[id];
      if (!entry) return false;                      // not ours: never touch flags we do not own
      delete tabsMap[id];
      return writeMap(tabsMap).then(function () {
        if (entry.preset) return false;              // user's own flag: leave it
        return setAutoDiscardable(id, true).then(function () { return true; },
                                                 function () { return true; });
      });
    });
  }

  /**
   * Toggle. A tab protected ONLY by the whitelist is left untouched —
   * the whitelist is managed in Settings, and the UI tooltip says so.
   * Resolves to true when the tab is protected afterwards.
   */
  function toggleTab(tab) {
    return getState().then(function (state) {
      const verdict = isTabProtected(tab, state);
      if (verdict.protected && verdict.reason === 'domain') return 'whitelisted';
      return verdict.protected ? unprotectTab(tab) : protectTab(tab);
    }).then(function (result) {
      if (result === 'whitelisted') return true; // still protected (by the whitelist)
      return getState().then(function (state) {
        return isTabProtected(tab, state).protected;
      });
    });
  }

  /**
   * Tab closed (service worker tabs.onRemoved): forget the entry. No
   * flag restore is possible or needed — the tab is gone.
   */
  function forgetTab(tabId) {
    return readMap().then(function (tabsMap) {
      if (!tabsMap[tabId]) return false;
      delete tabsMap[tabId];
      return writeMap(tabsMap).then(function () { return true; });
    });
  }

  /**
   * Tab id replaced (service worker tabs.onReplaced — prerender swap):
   * move the entry to the new id and re-assert the flag on it (the new
   * tab object starts with Chrome's default autoDiscardable:true).
   */
  function tabReplaced(oldTabId, newTabId) {
    return readMap().then(function (tabsMap) {
      const entry = tabsMap[oldTabId];
      if (!entry) return false;
      delete tabsMap[oldTabId];
      tabsMap[newTabId] = entry;
      return writeMap(tabsMap).then(function () {
        return setAutoDiscardable(newTabId, false).then(function () { return true; },
                                                        function () { return true; });
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * Migration & reconciliation (service worker startup paths)
   * ------------------------------------------------------------------ */

  /**
   * Hostnames of a LEGACY stored value:
   *  - v2 (v1.6.0–v1.6.3): { v: 2, sites: { [host]: ts } } — keys;
   *  - v1.5.0: { [tabId]: { title, url, domain, ts } } — `domain`
   *    fields (entry.url is never returned, only read here to drop
   *    non-http(s) pages exactly like v1.6.1 did).
   */
  function legacySiteKeys(raw) {
    const sites = {};
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return sites;
    if (raw.v === 2 && raw.sites && typeof raw.sites === 'object') {
      Object.keys(raw.sites).forEach(function (key) {
        // Plain hostnames only — v1.6.0 wrote full URLs and
        // browser-internal names as keys (v1.6.2 audit R1); those are
        // dropped here exactly like the v1.6.2 purge dropped them.
        if (typeof key === 'string' && key && !/[:\s/]/.test(key)) sites[key] = true;
      });
      return sites;
    }
    Object.keys(raw).forEach(function (key) {
      const entry = raw[key];
      if (entry && typeof entry === 'object' && typeof entry.domain === 'string' && entry.domain) {
        const host = entry.url
          ? siteKeyOf(entry.url)
          : siteKeyOf('http://' + entry.domain);
        if (host) sites[host] = true;
      }
    });
    return sites;
  }

  /**
   * One-time migration of a legacy stored value to the v3 per-tab map:
   * every currently OPEN tab whose site is in the legacy map gets
   * protected per-tab (flag + entry); the stored value is then REPLACED
   * by the v3 shape, so the hostnames actively leave the disk. Tabs of
   * those sites opened LATER are not covered — that is the new per-tab
   * semantics the user asked for.
   */
  function migrateLegacySites(raw) {
    const sites = legacySiteKeys(raw);
    if (!Object.keys(sites).length) {
      // Nothing convertible (fresh/garbage/legacy-with-nothing-left):
      // normalize the stored value once so this never runs again.
      return writeMap({}).then(function () { return emptyV3(); });
    }
    return Util.callApi(chrome.tabs, 'query', {}).then(function (tabs) {
      const ids = [];
      (tabs || []).forEach(function (tab) {
        const key = siteKeyOf(tab && tab.url);
        if (key && sites[key]) ids.push(tab.id);
      });
      let chain = Promise.resolve();
      const flagged = [];
      ids.forEach(function (id) {
        chain = chain.then(function () {
          return setAutoDiscardable(id, false).then(function () { flagged.push(id); },
                                                     function () { /* tab closed mid-migration */ });
        });
      });
      return chain.then(function () {
        const tabsMap = {};
        flagged.forEach(function (id) { tabsMap[id] = { ts: Date.now(), preset: false }; });
        return writeMap(tabsMap).then(function () {
          return { v: 3, tabs: tabsMap };
        });
      });
    });
  }

  /**
   * Startup reconciliation (onInstalled / onStartup in the service
   * worker; also safe to call from any extension page):
   *  1. legacy stored shapes are migrated to v3 (see above);
   *  2. entries whose tab no longer exists are dropped;
   *  3. when the session marker is missing (browser restarted, or the
   *     extension was reloaded/updated) an entry survives only if its
   *     tab still carries our autoDiscardable:false flag — restored
   *     tabs come back discardable, so stale ids from a previous
   *     browser session drop, while ids that still carry our flag
   *     (extension reload mid-session) are re-adopted and the marker
   *     is re-armed;
   *  4. the flag is re-asserted for surviving entries (drift repair).
   */
  function reconcileProtection() {
    return Storage.get(Storage.KEYS.PROTECTED_TABS).then(function (raw) {
      if (raw !== undefined && !isV3(raw)) {
        return migrateLegacySites(raw);              // 1. legacy → v3 (includes flag pass)
      }
      return Promise.all([
        Storage.getSession(Storage.SESSION_KEYS.SESSION_EPOCH),
        Util.callApi(chrome.tabs, 'query', {})
      ]).then(function (results) {
        const marker = results[0];
        const tabs = results[1] || [];
        const live = {};
        tabs.forEach(function (t) { live[t.id] = t; });
        const current = isV3(raw) ? sanitizeTabs(raw.tabs) : {};
        const next = {};
        let changed = false;
        Object.keys(current).forEach(function (key) {
          const tab = live[key];
          if (!tab) { changed = true; return; }      // 2. tab closed: drop
          if (!marker && tab.autoDiscardable !== false) {
            changed = true;                          // 3. stale id from a dead session
            return;
          }
          next[key] = current[key];
        });
        const jobs = [];
        Object.keys(next).forEach(function (key) {   // 4. drift repair
          const tab = live[key];
          if (tab && tab.autoDiscardable !== false) {
            jobs.push(setAutoDiscardable(Number(key), false).catch(function () {}));
          }
        });
        if (changed || !isV3(raw)) {
          jobs.push(writeMap(next));
        }
        if (!marker) {
          jobs.push(Storage.setSession(Storage.SESSION_KEYS.SESSION_EPOCH, Date.now()));
        }
        return Promise.all(jobs).then(function () {
          return next;
        });
      });
    }).catch(function (err) {
      console.warn('[TabPilot] reconcileProtection failed:', err && err.message);
      return {};
    });
  }

  /* ------------------------------------------------------------------ *
   * Whitelist (Settings-managed; unchanged semantics)
   * ------------------------------------------------------------------ */

  /**
   * Whitelist a domain (v1.6.1 audit N4, reworked in v1.6.2 audit R2,
   * tightened in v1.6.3 for v1.6.2 audit S3). Known public suffixes are
   * dangerous entries — one would silently switch the optimizer off for a
   * large part of the web — so:
   *  - a SINGLE label that looks like a public suffix ("dev", "wiki",
   *    "io", …) is NOT refused outright: it may be a real intranet
   *    host, so it gets a warning + explicit confirm step. The UI shows
   *    the warning and re-calls with { confirmed: true } ("Add anyway");
   *    the rejected Error carries .confirmable = true for that. The
   *    five classic generic TLDs ("com", "org", "net", "edu", "gov") are
   *    the exception: nobody has an intranet host with one of those
   *    names, and confirming one would protect the whole gTLD, so they
   *    are REFUSED even with confirmation (v1.6.2 audit S3).
   *  - a MULTI-label entry that IS a known public suffix ("co.uk",
   *    "com.au", "*.co.uk") can never be an intranet host and is
   *    refused outright with a precise message. Curated lists can never
   *    be complete (v1.6.2 audit S3: "com.bd", "ac.in", "co.at" and
   *    friends were all silently accepted), so multi-label entries of
   *    the form <generic prefix>.<two-letter country code> ("com.bd",
   *    "gov.in", "or.jp", …) are refused by PATTERN as well — every
   *    two-letter TLD is a country code, and a two-label entry of that
   *    shape is always a public suffix, never a real host (a real host
   *    under it, "example.com.bd", has three labels and stays
   *    acceptable).
   *  - plausible single-label intranet hosts — "localhost", "nas", "db",
   *    "wiki" after confirming, "test"/"local" (not public suffixes at
   *    all) — are accepted, short ones included (audit R2: the old
   *    under-3-characters and curated-list refusals blocked real
   *    intranet hosts with a misleading "bare top-level domain" message).
   */
  function addDomain(domain, opts) {
    const confirmed = !!(opts && opts.confirmed);
    const normalized = Util.normalizeDomain(domain);
    if (!normalized) return Promise.reject(new Error('Invalid domain: ' + domain));
    // Check the entry without its "*." prefix and any trailing dot
    // ("*.com", "com." are just as dangerous as "com").
    const bareLabel = normalized.replace(/^\*\./, '').replace(/\.$/, '');
    if (bareLabel === '*' || normalized === '*') {
      return Promise.reject(new Error(
        '"*" alone matches nothing — use a full domain (example.com) or a pattern (*.example.com).'));
    }
    if (bareLabel.indexOf('.') === -1) {
      // v1.6.2 audit S3: the classic generic TLDs are refused OUTRIGHT —
      // nobody has an intranet host called "com", and the "Add anyway"
      // step must not be able to protect every *.com site.
      if (Util.isBareGenericTld(bareLabel)) {
        return Promise.reject(new Error(
          '"' + bareLabel + '" is a top-level domain — protecting it would cover every *.' + bareLabel +
          ' site. Add a full domain (e.g. example.' + bareLabel + ') instead.'));
      }
      if (Util.isLikelyPublicSuffix(bareLabel) && !confirmed) {
        const err = new Error(
          '"' + bareLabel + '" looks like a public suffix — protecting it would cover every *.' + bareLabel +
          ' site. If "' + bareLabel + '" is an intranet host you really use, add it anyway.');
        err.confirmable = true; // UI: show warning + "Add anyway" step
        return Promise.reject(err);
      }
    } else if (Util.isKnownSecondLevelSuffix(bareLabel) ||
               Util.looksLikeSecondLevelSuffix(bareLabel)) {
      // Known by list, or matching the <generic prefix>.<country code>
      // pattern (v1.6.2 audit S3) — either way a public suffix that can
      // never be a real intranet host: refuse, no confirm step.
      return Promise.reject(new Error(
        '"' + bareLabel + '" is a public suffix — it would protect every *.' + bareLabel +
        ' site. Add a full domain (e.g. example.' + bareLabel + ') instead.'));
    }
    return getState().then(function (state) {
      if (state.whitelist.indexOf(normalized) !== -1) return state.whitelist;
      const next = state.whitelist.concat([normalized]).sort();
      return Storage.set(Storage.KEYS.WHITELIST, next).then(function () { return next; });
    });
  }

  function removeDomain(domain) {
    return getState().then(function (state) {
      const next = state.whitelist.filter(function (d) { return d !== domain; });
      return Storage.set(Storage.KEYS.WHITELIST, next).then(function () { return next; });
    });
  }

  /** Whitelist a tab's whole domain in one action ("Protect all tabs from…").
   * `opts.confirmed` (audit R2) passes the confirm step through for
   * intranet hosts whose name looks like a public suffix ("http://dev/"). */
  function protectTabDomain(tab, opts) {
    return addDomain(Util.hostnameOf(tab && tab.url), opts);
  }

  /** Count of currently open tabs that explicit protection covers. */
  function protectedCount(tabs, state) {
    let count = 0;
    (tabs || []).forEach(function (tab) {
      if (isTabProtected(tab, state).protected) count++;
    });
    return count;
  }

  TP.Protection = {
    getState: getState,
    isTabProtected: isTabProtected,
    isTabShielded: isTabShielded,
    protectionScopeOf: protectionScopeOf,
    siteKeyOf: siteKeyOf,
    protectTab: protectTab,
    unprotectTab: unprotectTab,
    toggleTab: toggleTab,
    forgetTab: forgetTab,
    tabReplaced: tabReplaced,
    reconcileProtection: reconcileProtection,
    addDomain: addDomain,
    removeDomain: removeDomain,
    protectTabDomain: protectTabDomain,
    protectedCount: protectedCount,
    matchesDomain: Util.matchesDomain
  };
})(typeof self !== 'undefined' ? self : globalThis);
