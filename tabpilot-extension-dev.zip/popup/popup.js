/**
 * TabPilot — popup.js
 * Browser-action popup with three views behind a tab bar:
 *
 *   Tabs (default) — the tab manager IS the main feature: search,
 *     filter, sort and act on every open tab. Quick actions above the
 *     list (Discard All Inactive / Reload All Discarded) need no
 *     selection at all — the discard asks for a two-click confirmation,
 *     since discarding drops in-progress form state; the multi-selection
 *     toolbar at the bottom is ALWAYS visible — check rows, or Select
 *     all / Select inactive, then Discard / Protect / Unprotect / Close
 *     (Discard and Close both confirm). User-protected tabs are skipped
 *     everywhere — "Keep user-protected tabs" is always enforced.
 *     Per-tab memory on every row: measured renderer privateMemory via
 *     chrome.processes wherever Chrome grants that permission (Dev
 *     channel / allowlisted builds; delivered live through the
 *     onUpdatedWithMemory event), and a clearly-labeled heuristic
 *     estimate (amber, "… MB est.") on stable Chrome, where no API can
 *     measure it. The meta line (counts + memory honesty note) sits
 *     under the toolbar. Favicons render from Chrome's own local cache
 *     (the _favicon endpoint) — never from the websites.
 *
 *   Overview — the restored full overview section: resource cards
 *     (status pill + big value + sparkline + detail sub-line), the tab
 *     chips row (tabs / active / inactive / discarded / protected),
 *     the open-tab memory line and the Optimize action.
 *
 *   Settings — the same shared settings component as the dashboard and
 *     the options page (modules/settings-ui.js), mounted in a scrolling
 *     view.
 *
 * The monitoring loop runs regardless of the active view, so Overview
 * cards are already live when you switch to them; switching to Overview
 * re-arms the sparkline redraw (canvases cannot paint while hidden).
 *
 * Startup budget: the static DOM paints immediately; the first metrics
 * arrive within one API round-trip. CPU utilization needs two samples —
 * the monitor fires a quick second sample ~450 ms after start, so real
 * numbers appear well under a second.
 *
 * When the popup closes, its interval timers and event subscriptions
 * die with the page — nothing keeps sampling in the background (the
 * service worker never samples).
 */
(function () {
  'use strict';

  const TP = self.TabPilot;
  const Util = TP.Util;
  const Storage = TP.Storage;
  const $ = function (id) { return document.getElementById(id); };

  const PILL_LABELS = {
    available: 'Live',
    estimated: 'Estimated',
    warming: 'Measuring…',
    unavailable: 'Unavailable',
    permission: 'Blocked',
    error: 'Error',
    disabled: 'Off'
  };

  const ICONS = {
    focus: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 2.5h4v4"/><path d="M13 3 7.5 8.5"/><path d="M11.5 9.5v4h-9v-9h4"/></svg>',
    reload: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.5 8a5.5 5.5 0 1 1-1.6-3.9L13.5 5.6"/><path d="M13.5 2.8v2.8h-2.8"/></svg>',
    discard: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.5 9.2A6 6 0 1 1 6.8 2.5 4.8 4.8 0 0 0 13.5 9.2z"/></svg>',
    shield: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 1.8 13.5 4v3.4c0 3.5-2.4 5.7-5.5 6.8-3.1-1.1-5.5-3.3-5.5-6.8V4z"/><path d="m5.6 7.8 1.7 1.7 3.1-3.3"/></svg>',
    close: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><line x1="3.5" y1="3.5" x2="12.5" y2="12.5"/><line x1="12.5" y1="3.5" x2="3.5" y2="12.5"/></svg>'
  };

  let settings = null;
  let monitor = null;
  let chartDirty = false;

  /* tab manager state */
  let protState = { whitelist: [], protectedSites: {}, sessionSites: {} };
  let tabsData = [];
  let lastAccessMap = {};
  let tabFilter = 'all';
  let tabSort = 'recent';
  let tabSearch = '';
  let memoryInfo = { supported: false, map: {}, estimates: {} };
  let memoryStop = null;          // stop() for the onUpdatedWithMemory watch
  let memoryRenderTimer = null;
  const selection = new Set();    // checked tab ids (bulk actions)

  /* View switcher state — the popup always opens on Tabs. */
  const VIEW_ORDER = ['overview', 'tabs', 'settings'];
  let currentView = 'tabs';

  /* ------------------------------------------------------------------ *
   * Boot
   * ------------------------------------------------------------------ */

  document.addEventListener('DOMContentLoaded', function () {
    TP.Theme.init();
    Storage.getSettings().then(function (s) {
      settings = s;
      wireControls();
      renderModeMeta();
      startMonitor();
      return TP.History.init(s);
    }).then(function () {
      wireMemorySortOption();
      loadTabs();
      renderLastOptimization();
      watchExternalChanges();
      // Settings view mounts the SAME shared component the dashboard and
      // options page use (single implementation, zero drift).
      if (TP.SettingsUI) TP.SettingsUI.mount($('settingsRoot'));
    });
  });

  window.addEventListener('pagehide', function () {
    if (monitor) monitor.stop();
    if (memoryStop) memoryStop();   // stop the process-memory event watch
    TP.History.flush(true); // persist samples collected during this popup session
  });

  /* ------------------------------------------------------------------ *
   * Controls
   * ------------------------------------------------------------------ */

  function wireControls() {
    $('btnDashboard').addEventListener('click', function () {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
      window.close();
    });
    $('btnOptions').addEventListener('click', function () {
      chrome.runtime.openOptionsPage();
      window.close();
    });
    $('btnFullSettings').addEventListener('click', function () {
      chrome.runtime.openOptionsPage();
      window.close();
    });

    wireViewSwitcher();

    $('btnOptimize').addEventListener('click', function () {
      runOptimize($('btnOptimize'));
    });

    let searchTimer = null;
    $('tabSearch').addEventListener('input', function () {
      if (searchTimer) clearTimeout(searchTimer);
      searchTimer = setTimeout(function () {
        tabSearch = $('tabSearch').value.trim().toLowerCase();
        renderTabs();
      }, 140);
    });

    $('filterChips').addEventListener('click', function (event) {
      const chip = event.target.closest('button[data-filter]');
      if (!chip) return;
      tabFilter = chip.dataset.filter || 'all';
      $('filterChips').querySelectorAll('button').forEach(function (b) {
        b.setAttribute('aria-pressed', String(b === chip));
      });
      renderTabs();
    });

    $('sortSelect').addEventListener('change', function () {
      tabSort = $('sortSelect').value;
      renderTabs();
    });

    $('tabList').addEventListener('click', onTabListClick);
    $('tabList').addEventListener('change', function (event) {
      const cb = event.target;
      if (cb.tagName !== 'INPUT' || cb.type !== 'checkbox') return;
      const row = cb.closest('.tab-row');
      if (!row) return;
      const id = Number(row.dataset.id);
      if (cb.checked) selection.add(id); else selection.delete(id);
      row.dataset.selected = String(cb.checked);
      updateBulkBar();
    });
    $('tabList').addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const row = event.target.closest('.tab-row');
      if (!row || event.target.closest('button') || event.target.closest('input')) return;
      event.preventDefault();
      focusTab(findTab(row.dataset.id));
    });

    /* Bulk actions for the checked tabs (mirrors the dashboard). */
    $('btnBulkClear').addEventListener('click', function () {
      selection.clear();
      renderTabs();
    });
    $('btnBulkDiscard').addEventListener('click', bulkDiscard);
    $('btnBulkClose').addEventListener('click', bulkClose);
    $('btnBulkProtect').addEventListener('click', function () { bulkProtect(true); });
    $('btnBulkUnprotect').addEventListener('click', function () { bulkProtect(false); });

    /* Selection helpers + quick actions (always-visible toolbar). */
    $('btnSelectAll').addEventListener('click', selectAllVisible);
    $('btnSelectInactive').addEventListener('click', selectInactiveVisible);
    const btnDiscardInactive = $('btnDiscardInactive');
    btnDiscardInactive.addEventListener('click', function () { discardAllInactive(btnDiscardInactive); });
    const btnReloadDiscarded = $('btnReloadDiscarded');
    btnReloadDiscarded.addEventListener('click', function () { reloadAllDiscarded(btnReloadDiscarded); });
  }

  /* ------------------------------------------------------------------ *
   * View switcher (Overview / Tabs / Settings — Tabs is the default)
   * ------------------------------------------------------------------ */

  function switchView(name) {
    if (VIEW_ORDER.indexOf(name) === -1) name = 'tabs';
    currentView = name;
    document.querySelectorAll('#popupNav button[data-view]').forEach(function (btn) {
      const selected = btn.dataset.view === name;
      btn.setAttribute('aria-selected', String(selected));
      btn.tabIndex = selected ? 0 : -1;
    });
    VIEW_ORDER.forEach(function (view) {
      $('view-' + view).hidden = view !== name;
    });
    // Canvases cannot paint while their view is display:none — re-arm
    // the sparkline redraw so Overview graphs appear the moment it opens.
    if (name === 'overview') chartDirty = true;
  }

  function wireViewSwitcher() {
    // Ship state: Tabs selected (matches the static HTML).
    switchView('tabs');

    $('popupNav').addEventListener('click', function (event) {
      const btn = event.target.closest('button[data-view]');
      if (btn) switchView(btn.dataset.view);
    });

    // Tablist keyboard pattern: arrows / Home / End move the selection.
    $('popupNav').addEventListener('keydown', function (event) {
      let target = null;
      const idx = VIEW_ORDER.indexOf(currentView);
      if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
        target = (idx + 1) % VIEW_ORDER.length;
      } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
        target = (idx - 1 + VIEW_ORDER.length) % VIEW_ORDER.length;
      } else if (event.key === 'Home') {
        target = 0;
      } else if (event.key === 'End') {
        target = VIEW_ORDER.length - 1;
      } else {
        return;
      }
      event.preventDefault();
      switchView(VIEW_ORDER[target]);
      const btn = $('popupNav').querySelector('button[data-view="' + VIEW_ORDER[target] + '"]');
      if (btn) btn.focus();
    });
  }

  /**
   * "Sort: memory" always exists — measured where chrome.processes is
   * granted, heuristic estimate everywhere else (labelled "est.").
   */
  function wireMemorySortOption() {
    const supported = TP.TabMemory.isSupported();
    const option = document.createElement('option');
    option.value = 'memory';
    option.textContent = supported ? 'Sort: memory' : 'Sort: memory (est.)';
    option.title = supported
      ? 'Renderer private memory measured via chrome.processes (live events)'
      : 'Heuristic estimates from tab state & site type — not measured';
    $('sortSelect').appendChild(option);
  }

  function runOptimize(btn) {
    btn.disabled = true;
    btn.dataset.label = btn.textContent;
    btn.textContent = 'Optimizing…';
    requestOptimize('manual', null).then(function (response) {
      btn.disabled = false;
      btn.textContent = btn.dataset.label || 'Optimize Browser';
      if (chrome.runtime.lastError || !response || !response.ok) {
        toast((response && response.error) || chrome.runtime.lastError?.message || 'Optimization failed', 'error');
        return;
      }
      const summary = response.summary || {};
      if (summary.status === 'automation-disabled') { toast('Nothing to optimize right now', ''); return; }
      const parts = [];
      if (summary.discardedCount > 0) parts.push(summary.discardedCount + (summary.discardedCount === 1 ? ' tab' : ' tabs') + ' discarded');
      else parts.push('Nothing to discard');
      const skipped = summary.skipped || {};
      if (skipped.protected || skipped['user-protected'] || skipped.whitelisted) parts.push('protected tabs skipped');
      toast(parts.join(' · '), summary.discardedCount > 0 ? 'success' : '');
      renderLastOptimization();
      loadTabs();
    });
  }

  /**
   * Optimize through the service worker (preferred: keeps measuring and
   * summary-writing alive even if the popup closes). Falls back to running
   * the same optimizer locally if the worker does not respond.
   */
  function requestOptimize(trigger, tabIds) {
    return new Promise(function (resolve) {
      const localFallback = function (errorMessage) {
        if (self.TabPilot.Optimizer) {
          self.TabPilot.Optimizer.run({ trigger: trigger, tabIds: tabIds })
            .then(function (summary) { resolve({ ok: true, summary: summary }); })
            .catch(function (err) { resolve({ ok: false, error: (err && err.message) || 'failed' }); });
        } else {
          resolve({ ok: false, error: errorMessage });
        }
      };
      try {
        chrome.runtime.sendMessage({ type: 'tp:optimize', trigger: trigger, tabIds: tabIds || null }, function (response) {
          if (chrome.runtime.lastError || !response) {
            localFallback((chrome.runtime.lastError && chrome.runtime.lastError.message) || 'Service worker unavailable');
          } else {
            resolve(response);
          }
        });
      } catch (err) {
        localFallback(err && err.message);
      }
    });
  }

  /* ------------------------------------------------------------------ *
   * Tab manager
   * ------------------------------------------------------------------ */

  async function loadTabs() {
    try {
      const results = await Promise.all([
        TP.Tabs.getAll(),
        Storage.getSession(Storage.SESSION_KEYS.LAST_ACCESS),
        TP.Protection.getState()
      ]);
      lastAccessMap = results[1] || {};
      protState = results[2];
      tabsData = results[0].map(function (tab) {
        tab.lastAccessedAt = TP.Tabs.lastAccessedOf(tab, lastAccessMap);
        return tab;
      });

      // Drop selections for tabs that no longer exist.
      const live = {};
      tabsData.forEach(function (t) { live[t.id] = true; });
      Array.from(selection).forEach(function (id) { if (!live[id]) selection.delete(id); });

      // Per-tab memory: measured skeleton wherever chrome.processes is
      // granted (bytes arrive live via events), estimates elsewhere.
      memoryInfo = await TP.TabMemory.getTabMemoryMap(tabsData);
      startMemoryWatch();
    } catch (err) {
      console.error('[TabPilot] loading tabs failed:', err);
      tabsData = [];
      memoryInfo = { supported: false, map: {}, estimates: {} };
    }
    renderTabs();
  }

  const scheduleTabReload = Util.throttle(loadTabs, 600);

  function visibleTabs() {
    let list = tabsData.slice();
    if (tabFilter === 'active') list = list.filter(function (t) { return t.active; });
    else if (tabFilter === 'inactive') list = list.filter(function (t) { return !t.active && !t.discarded; });
    else if (tabFilter === 'discarded') list = list.filter(function (t) { return t.discarded; });
    else if (tabFilter === 'protected') {
      list = list.filter(function (t) { return TP.Protection.isTabProtected(t, protState).protected; });
    } else if (tabFilter === 'audible') list = list.filter(function (t) { return t.audible; });

    if (tabSearch) {
      list = list.filter(function (t) {
        return (t.title || '').toLowerCase().indexOf(tabSearch) !== -1 ||
               (t.domain || '').toLowerCase().indexOf(tabSearch) !== -1 ||
               (t.url || '').toLowerCase().indexOf(tabSearch) !== -1;
      });
    }
    return sortTabs(list);
  }

  function sortTabs(list) {
    const now = Date.now();
    const idleOf = function (t) {
      return t.lastAccessedAt ? now - t.lastAccessedAt : Infinity;
    };
    if (tabSort === 'recent') {
      list.sort(function (a, b) { return idleOf(a) - idleOf(b); });
    } else if (tabSort === 'oldest') {
      list.sort(function (a, b) { return idleOf(b) - idleOf(a); });
    } else if (tabSort === 'alpha') {
      list.sort(function (a, b) { return (a.title || '').localeCompare(b.title || ''); });
    } else if (tabSort === 'memory') {
      // Measured bytes where chrome.processes is available, heuristic
      // estimates everywhere else — discarded tabs rank at 0 (freed).
      const bytesOf = function (t) {
        if (t.discarded) return 0; // renderer memory genuinely freed
        const entry = memoryInfo.supported && memoryInfo.map && memoryInfo.map[t.id];
        if (entry && typeof entry.bytes === 'number') return entry.bytes;
        const est = memoryInfo.estimates && memoryInfo.estimates[t.id];
        return est && typeof est.bytes === 'number' ? est.bytes : -1;
      };
      list.sort(function (a, b) { return bytesOf(b) - bytesOf(a); });
    } else {
      list.sort(function (a, b) { return (a.windowId - b.windowId) || (a.index - b.index); });
    }
    return list;
  }

  function renderTabs() {
    const listEl = $('tabList');
    const list = visibleTabs();
    const fragment = document.createDocumentFragment();
    list.forEach(function (tab) { fragment.appendChild(buildTabRow(tab)); });

    listEl.innerHTML = '';
    listEl.appendChild(fragment);
    $('tabsEmpty').hidden = list.length > 0;

    const counts = TP.Tabs.counts(tabsData, protState, settings);
    let meta = tabsData.length + ' tabs · ' + list.length + ' shown' +
      ' · ' + counts.active + ' active · ' + counts.discarded + ' discarded · ' + counts.protected + ' protected' +
      (selection.size ? ' · ' + selection.size + ' selected' : '');

    // Memory note: what is measured vs estimated, honestly.
    const liveTabs = tabsData.filter(function (t) { return !t.discarded; });
    const measured = liveTabs.filter(function (t) {
      const entry = memoryInfo.map && memoryInfo.map[t.id];
      return entry && typeof entry.bytes === 'number';
    }).length;
    if (!memoryInfo.supported) {
      meta += '\nPer-tab memory: estimated (tab state + site type) — Chrome\u2019s stable channel does not expose chrome.processes to third-party extensions. Real numbers: Chrome Task Manager (Shift+Esc).';
    } else if (measured === 0) {
      meta += '\nPer-tab memory: chrome.processes active — waiting for the first renderer memory samples (estimates shown meanwhile).';
    } else if (measured < liveTabs.length) {
      meta += '\nPer-tab memory: ' + measured + ' of ' + liveTabs.length + ' tabs measured live via chrome.processes; the rest estimated.';
    } else {
      meta += '\nMemory = renderer private memory, measured live via chrome.processes (process-wide when tabs share a renderer).';
    }
    if (memoryInfo.partial) {
      meta += '\n(' + (memoryInfo.reason || 'process query hiccup') + ')';
    }
    $('listMeta').textContent = meta;
    renderOverviewStats(counts);
    updateBulkBar();
  }

  /**
   * Overview view: tab chips (tabs / active / inactive / discarded /
   * protected), the live tab count on the nav badge, and the honest
   * open-tab memory line (measured where chrome.processes is granted,
   * heuristic estimate everywhere else — shared renderer processes are
   * only ever counted once).
   */
  function renderOverviewStats(counts) {
    $('navTabCount').textContent = String(counts.total);
    $('tabTotal').textContent = String(counts.total);
    $('tabActive').textContent = String(counts.active);
    $('tabInactive').textContent = String(counts.inactive);
    $('tabDiscarded').textContent = String(counts.discarded);
    $('tabProtected').textContent = String(counts.protected);

    const live = tabsData.filter(function (t) { return !t.discarded; });
    let total = 0;
    let measuredTabs = 0;
    let estimatedTabs = 0;

    if (memoryInfo.supported) {
      // Sum each renderer PROCESS once: tabs sharing a renderer share
      // that process's private memory.
      const byPid = {};
      live.forEach(function (t) {
        const entry = memoryInfo.map && memoryInfo.map[t.id];
        if (entry && typeof entry.bytes === 'number') {
          if (entry.pid != null) {
            if (!(entry.pid in byPid)) byPid[entry.pid] = entry.bytes;
          } else {
            total += entry.bytes;
          }
          measuredTabs++;
        } else {
          const est = memoryInfo.estimates && memoryInfo.estimates[t.id];
          if (est && typeof est.bytes === 'number') { total += est.bytes; estimatedTabs++; }
        }
      });
      Object.keys(byPid).forEach(function (pid) { total += byPid[pid]; });
    } else {
      live.forEach(function (t) {
        const est = memoryInfo.estimates && memoryInfo.estimates[t.id];
        if (est && typeof est.bytes === 'number') { total += est.bytes; estimatedTabs++; }
      });
    }

    const el2 = $('ovMem');
    if (!live.length) {
      el2.textContent = 'No open tabs to measure.';
      el2.title = 'Every tab is discarded or closed.';
      return;
    }
    if (memoryInfo.supported && measuredTabs > 0 && estimatedTabs === 0) {
      el2.textContent = 'Open-tab memory: ≈ ' + Util.formatBytes(total, 1) +
        ' measured (renderer private — processes shared by tabs counted once)';
      el2.title = 'Sum of renderer private memory from chrome.processes, live. Per-tab values are shown on every row in the Tabs view.';
    } else if (memoryInfo.supported && measuredTabs > 0) {
      el2.textContent = 'Open-tab memory: ≈ ' + Util.formatBytes(total, 1) +
        ' (' + measuredTabs + ' measured · ' + estimatedTabs + ' estimated)';
      el2.title = 'Measured renderer memory via chrome.processes where samples have arrived; heuristic estimates for the rest. Per-tab values in the Tabs view.';
    } else {
      el2.textContent = 'Open-tab memory: ≈ ' + Util.formatBytes(total, 1) +
        ' estimated (heuristic — per-tab values in the Tabs view)';
      el2.title = 'Chrome’s stable channel does not expose chrome.processes to third-party extensions, so this is a clearly-labeled estimate from tab state + site type. Real numbers: Chrome Task Manager (Shift+Esc).';
    }
  }

  function buildTabRow(tab) {
    const row = el('div', 'tab-row');
    row.setAttribute('role', 'listitem');
    row.tabIndex = 0;
    row.dataset.id = String(tab.id);
    row.dataset.discarded = String(!!tab.discarded);
    row.dataset.selected = String(selection.has(tab.id));

    // Selection checkbox (bulk actions) — a click must NOT open the tab.
    const check = el('label', 'tab-check');
    const checkbox = el('input');
    checkbox.type = 'checkbox';
    checkbox.checked = selection.has(tab.id);
    checkbox.setAttribute('aria-label', 'Select tab');
    check.appendChild(checkbox);
    row.appendChild(check);

    row.appendChild(buildFavicon(tab));

    const main = el('div', 'tab-main');
    const titleRow = el('div', 'tab-title-row');
    titleRow.appendChild(el('span', 'tab-title', tab.title || tab.url || 'Untitled'));

    const badges = el('span', 'tab-badges');
    if (tab.active) { const b = el('span', 'tp-badge', 'Active'); b.dataset.kind = 'active'; badges.appendChild(b); }
    if (tab.pinned) { const b = el('span', 'tp-badge', 'Pin'); b.dataset.kind = 'pinned'; badges.appendChild(b); }
    if (tab.audible) { const b = el('span', 'tp-badge', 'Audio'); b.dataset.kind = 'audible'; badges.appendChild(b); }
    if (TP.Protection.isTabProtected(tab, protState).protected) {
      const b = el('span', 'tp-badge', 'Protected'); b.dataset.kind = 'protected'; badges.appendChild(b);
    }
    if (tab.discarded) { const b = el('span', 'tp-badge', 'Discarded'); b.dataset.kind = 'discarded'; badges.appendChild(b); }
    titleRow.appendChild(badges);

    const sub = el('div', 'tab-sub');
    sub.appendChild(el('span', 'tab-domain', tab.domain || shortenUrl(tab.url)));
    sub.appendChild(el('span', 'sep', '·'));
    sub.appendChild(idleSpan(tab));
    const mem = memorySpan(tab);
    if (mem) {
      sub.appendChild(el('span', 'sep', '·'));
      sub.appendChild(mem);
    }

    main.appendChild(titleRow);
    main.appendChild(sub);
    row.appendChild(main);

    const actions = el('div', 'tab-actions');
    actions.appendChild(actionBtn('focus', tab, 'Open this tab'));
    actions.appendChild(actionBtn('reload', tab, 'Reload'));
    actions.appendChild(actionBtn('discard', tab, discardTitle(tab), !canDiscard(tab)));
    actions.appendChild(actionBtn('shield', tab, protectTitle(tab)));
    actions.appendChild(actionBtn('close', tab, 'Close tab'));
    row.appendChild(actions);

    const measuredEntry = memoryInfo.supported && memoryInfo.map &&
      typeof memoryInfo.map[tab.id] === 'object' && memoryInfo.map[tab.id] !== null &&
      typeof memoryInfo.map[tab.id].bytes === 'number' ? memoryInfo.map[tab.id] : null;
    row.title = (tab.title || tab.url || 'Untitled') +
      '\n' + (tab.url || '') +
      (tab.discarded ? '\nDiscarded — memory freed, reloads on click.' : '') +
      (measuredEntry
        ? '\n' + TP.TabMemory.describe(measuredEntry, tab)
        : '\n' + TP.TabMemory.describeEstimate(memoryInfo.estimates && memoryInfo.estimates[tab.id], tab));
    return row;
  }

  function idleSpan(tab) {
    if (tab.discarded) return el('span', null, 'discarded');
    if (tab.active) return el('span', null, 'now');
    if (tab.lastAccessedAt) {
      return el('span', null, 'idle ' + Util.formatDuration(Date.now() - tab.lastAccessedAt));
    }
    return el('span', null, 'idle ?');
  }

  /**
   * Per-tab memory cell — shown on EVERY row.
   *  - Measured (chrome.processes granted): real renderer privateMemory
   *    from the live onUpdatedWithMemory event stream, with an explicit
   *    marker when several tabs share one renderer process.
   *  - Everywhere else (or until the first sample arrives): heuristic
   *    estimate, amber and marked "est." so it can never be mistaken
   *    for a measurement.
   *  - Discarded tabs: factual "memory freed" on every platform.
   */
  function memorySpan(tab) {
    if (tab.discarded) {
      const span = el('span', 'tab-mem', 'memory freed');
      span.style.color = 'var(--green)';
      span.title = 'Discarded — its renderer memory is already freed.';
      return span;
    }

    if (memoryInfo.supported) {
      const entry = memoryInfo.map && memoryInfo.map[tab.id];
      if (entry && typeof entry.bytes === 'number') {
        const shared = entry.sharedWith > 1;
        const span = el('span', 'tab-mem mono',
          '≈ ' + Util.formatBytes(entry.bytes, 1) + (shared ? ' · ' + entry.sharedWith + ' tabs' : ''));
        if (shared) span.dataset.shared = 'true';
        span.title = TP.TabMemory.describe(entry, tab);
        return span;
      }
      // Renderer resolved but no memory sample yet → estimate below.
    }

    // Heuristic estimate — amber + "est." marker, never a claim.
    const est = memoryInfo.estimates && memoryInfo.estimates[tab.id];
    if (!est || typeof est.bytes !== 'number') {
      return el('span', 'tab-mem text-3', '');
    }
    const span = el('span', 'tab-mem mono', '≈ ' + Util.formatBytes(est.bytes, 0) + ' est.');
    span.dataset.est = 'true';
    span.title = TP.TabMemory.describeEstimate(est, tab);
    return span;
  }

  function canDiscard(tab) {
    if (tab.active || tab.pinned || tab.discarded || tab.autoDiscardable === false) return false;
    if (String(tab.url || '').startsWith('chrome-extension://')) return false;
    // User site protection is ALWAYS enforced — even for explicit actions.
    // (Whitelisted domains remain discardable by explicit selection.)
    const prot = TP.Protection.isTabProtected(tab, protState);
    return !(prot.protected && prot.reason === 'user');
  }

  function discardTitle(tab) {
    if (tab.active) return 'Active tabs can never be discarded';
    if (tab.pinned) return 'Pinned tabs can never be discarded';
    if (tab.discarded) return 'Already discarded';
    if (tab.autoDiscardable === false) return 'Marked non-discardable by Chrome';
    const prot = TP.Protection.isTabProtected(tab, protState);
    if (prot.protected && prot.reason === 'user') {
      return 'Protected by you (always enforced) — remove protection first';
    }
    if (prot.protected) return 'Whitelisted domain — discard anyway (explicit action)';
    return 'Discard now (free its memory)';
  }

  function protectTitle(tab) {
    const prot = TP.Protection.isTabProtected(tab, protState);
    if (prot.protected && prot.reason === 'domain') {
      return 'Whitelisted domain — manage the list in Settings → Protection';
    }
    // v1.6.1 audit N2: the shield protects the whole SITE, not just this
    // tab — the tooltip must say so. v1.6.2 audit R3: the wording must
    // match what the code actually does for THIS tab — only http(s)
    // non-incognito protection survives restarts; incognito tabs are
    // session-only (never on disk) and hostless pages (file:, chrome:, …)
    // cover exactly this page, this session.
    const scope = TP.Protection.protectionScopeOf(tab, protState);
    if (scope.kind === 'page') {
      return prot.protected
        ? 'Remove protection for this page (until the browser closes)'
        : 'Protect this page only (until the browser closes — never saved to disk)';
    }
    if (!scope.durable) {
      return prot.protected
        ? 'Remove protection for this site (all its tabs — this session only, never saved to disk)'
        : 'Protect this site (all its tabs — incognito, this session only, never saved to disk)';
    }
    return prot.protected
      ? 'Remove protection for this site (all its tabs, survives restarts)'
      : 'Protect this site (all tabs, survives restarts)';
  }

  function actionBtn(icon, tab, title, disabled) {
    const btn = el('button', 'tp-icon-btn');
    btn.dataset.action = icon;
    btn.dataset.tabId = String(tab.id);
    btn.title = title;
    btn.setAttribute('aria-label', title);
    btn.innerHTML = ICONS[icon];
    if (disabled) btn.disabled = true;
    return btn;
  }

  function buildFavicon(tab) {
    const fav = el('span', 'tab-fav');
    const domain = tab.domain || '?';
    fav.style.background = domainColor(domain);
    // Favicons come from Chrome's OWN favicon store via the internal
    // _favicon endpoint — the extension never contacts any website
    // (tab.favIconUrl is deliberately NOT used: it points at the site's
    // server, which would make every list render a network request the
    // privacy policy forbids). Served from the browser's cache; falls
    // back to a letter tile when disabled or unavailable.
    const src = settings.privacy.favicons ? Util.faviconUrl(tab.url, 32) : '';
    if (src) {
      const img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.loading = 'lazy';
      img.onerror = function () { img.replaceWith(document.createTextNode(letterOf(domain))); };
      fav.appendChild(img);
    } else {
      fav.textContent = letterOf(domain);
    }
    return fav;
  }

  function letterOf(domain) {
    const ch = (domain || '?').replace(/^www\./, '')[0] || '?';
    return /[a-z0-9]/i.test(ch) ? ch.toUpperCase() : '?';
  }

  function domainColor(domain) {
    let hash = 0;
    for (let i = 0; i < domain.length; i++) hash = (hash * 31 + domain.charCodeAt(i)) | 0;
    const hues = [212, 152, 262, 187, 4, 330, 44];
    const h = hues[Math.abs(hash) % hues.length];
    return 'hsl(' + h + ', 32%, 34%)';
  }

  function shortenUrl(url) {
    if (!url) return '—';
    return url.length > 28 ? url.slice(0, 25) + '…' : url;
  }

  function findTab(id) {
    return tabsData.filter(function (t) { return t.id === Number(id); })[0] || null;
  }

  /* ------------------------------------------------------------------ *
   * Row actions
   * ------------------------------------------------------------------ */

  function onTabListClick(event) {
    // Checkbox / label clicks are selection toggles — never open the tab.
    if (event.target.closest('.tab-check')) return;

    const btn = event.target.closest('button[data-action]');
    if (btn) {
      const tab = findTab(btn.dataset.tabId);
      if (!tab) return;
      runAction(btn.dataset.action, tab);
      return;
    }
    // Click on the row body (not its buttons) → open the tab.
    const row = event.target.closest('.tab-row');
    if (row) focusTab(findTab(row.dataset.id));
  }

  function runAction(action, tab) {
    if (action === 'focus') {
      focusTab(tab);
    } else if (action === 'reload') {
      TP.Tabs.reloadOne(tab.id).catch(function (err) {
        toast('Reload failed: ' + err.message, 'error');
      }).then(loadTabs);
    } else if (action === 'discard') {
      // Explicit single-tab discard — bypasses SOFT protections (whitelist,
      // idle rules) only. User site protection is always enforced, which
      // is why the button is disabled for protected tabs (canDiscard).
      requestOptimize('selection', [tab.id]).then(handleActionResponse);
    } else if (action === 'shield') {
      TP.Protection.toggleTab(tab)
        .catch(function (err) { toast(err.message, 'error'); })
        .then(loadTabs);
    } else if (action === 'close') {
      TP.Tabs.closeOne(tab.id).catch(function (err) {
        toast('Close failed: ' + err.message, 'error');
      }).then(loadTabs);
    }
  }

  function focusTab(tab) {
    if (!tab) return;
    TP.Tabs.activate(tab).catch(function (err) { toast(err.message, 'error'); });
  }

  /* ------------------------------------------------------------------ *
   * Bulk actions on the checked selection (mirrors the dashboard).
   * The toolbar is ALWAYS visible: with no selection the actions are
   * simply disabled — Select all / Select inactive fill the selection.
   * ------------------------------------------------------------------ */

  function updateBulkBar() {
    const bar = $('bulkBar');
    bar.hidden = false; // always visible
    const n = selection.size;
    $('bulkCount').textContent = n + ' selected';
    const has = n > 0;
    ['btnBulkDiscard', 'btnBulkProtect', 'btnBulkUnprotect', 'btnBulkClose', 'btnBulkClear']
      .forEach(function (id) { $(id).disabled = !has; });
    document.querySelectorAll('#tabList .tab-row').forEach(function (row) {
      const id = Number(row.dataset.id);
      row.dataset.selected = String(selection.has(id));
      const cb = row.querySelector('input[type="checkbox"]');
      if (cb) cb.checked = selection.has(id);
    });
  }

  /** Select every tab shown by the current filter + search. */
  function selectAllVisible() {
    visibleTabs().forEach(function (tab) { selection.add(tab.id); });
    renderTabs();
    toast('Selected ' + selection.size + ' tabs', '');
  }

  /**
   * Select every INACTIVE tab shown by the current filter + search —
   * the one-click setup for a quick Discard (inactive tabs are the
   * optimizer's candidates).
   */
  function selectInactiveVisible() {
    const candidates = visibleTabs().filter(function (t) { return !t.active && !t.discarded; });
    candidates.forEach(function (tab) { selection.add(tab.id); });
    renderTabs();
    if (!candidates.length) {
      toast('No inactive tabs in the current view', '');
      return;
    }
    toast('Selected ' + candidates.length + ' inactive tabs', '');
  }

  /**
   * Quick action: discard EVERY inactive tab across all windows — no
   * selection needed. Runs the same explicit 'selection' path as the
   * bulk bar (soft protections and idle rules are bypassed because
   * this is a deliberate action; Chrome hard rules still apply, so
   * active/pinned tabs are always skipped). Two-step confirmation like
   * Close: a discard drops in-progress form state, so bulk discards ask.
   */
  function discardAllInactive(btn) {
    if (btn.dataset.confirming !== '1') {
      btn.dataset.confirming = '1';
      btn.textContent = 'Confirm discard';
      setTimeout(function () { btn.textContent = 'Discard All Inactive'; delete btn.dataset.confirming; }, 3000);
      return;
    }
    btn.textContent = 'Discard All Inactive';
    delete btn.dataset.confirming;
    const ids = tabsData.filter(function (t) { return !t.active && !t.discarded; })
      .map(function (t) { return t.id; });
    if (!ids.length) {
      toast('No inactive tabs to discard', '');
      return;
    }
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = 'Discarding…';
    requestOptimize('selection', ids).then(function (response) {
      btn.disabled = false;
      btn.textContent = label;
      handleActionResponse(response);
    });
  }

  /**
   * Quick action: reload every discarded tab across all windows — the
   * inverse of a discard sweep: wakes the tabs up (memory restored,
   * still inactive) without losing any of them.
   */
  function reloadAllDiscarded(btn) {
    const discarded = tabsData.filter(function (t) { return t.discarded; });
    if (!discarded.length) {
      toast('No discarded tabs to reload', '');
      return;
    }
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = 'Reloading…';
    const ids = discarded.map(function (t) { return t.id; });
    TP.Tabs.reloadMany(ids).then(function (result) {
      btn.disabled = false;
      btn.textContent = label;
      const failed = result.failed.length;
      toast('Reloaded ' + result.ok.length + ' discarded tab' + (result.ok.length === 1 ? '' : 's') +
        (failed ? ' · ' + failed + ' failed' : ''), failed ? '' : 'success');
      loadTabs();
    });
  }

  function bulkDiscard(event) {
    const btn = event.currentTarget;
    // Two-step confirmation, mirroring bulkClose: discarding drops
    // in-progress form state in the discarded tabs.
    if (btn.dataset.confirming !== '1') {
      btn.dataset.confirming = '1';
      btn.textContent = 'Confirm';
      setTimeout(function () { btn.textContent = 'Discard'; delete btn.dataset.confirming; }, 3000);
      return;
    }
    btn.textContent = 'Discard';
    delete btn.dataset.confirming;
    const ids = Array.from(selection);
    if (!ids.length) return;
    // Explicit selection = deliberate user action; the optimizer marks it
    // clearly in the summary ("selection") while Chrome hard rules still
    // apply (active/pinned tabs are skipped, never force-discarded) and
    // user-protected tabs are always skipped (unprotect first).
    requestOptimize('selection', ids).then(function (response) {
      handleActionResponse(response);
      selection.clear();
      renderTabs();
    });
  }

  function bulkClose(event) {
    const btn = event.currentTarget;
    if (btn.dataset.confirming !== '1') {
      btn.dataset.confirming = '1';
      btn.textContent = 'Confirm';
      setTimeout(function () { btn.textContent = 'Close'; delete btn.dataset.confirming; }, 3000);
      return;
    }
    btn.textContent = 'Close';
    delete btn.dataset.confirming;
    const ids = Array.from(selection);
    if (!ids.length) return;
    TP.Tabs.closeMany(ids).then(function (result) {
      const failed = result.failed.length;
      toast('Closed ' + result.ok.length + ' tabs' + (failed ? ' · ' + failed + ' failed' : ''),
        failed ? '' : 'success');
      selection.clear();
      loadTabs();
    });
  }

  function bulkProtect(protect) {
    const ids = Array.from(selection);
    if (!ids.length) return;
    // v1.6.2 audit R3: tell the truth about what bulk protect stores —
    // http(s) non-incognito tabs persist and survive restarts, incognito
    // and hostless-scheme tabs (file:, chrome:, …) are session-only.
    // v1.6.2 audit S4: the count is of distinct SITES, not tabs — five
    // tabs from one site are one durable site (deduplicated by site key;
    // the "www." variant shares the key).
    const durableSites = new Set();
    ids.forEach(function (id) {
      const tab = findTab(id);
      if (!tab) return;
      if (TP.Protection.protectionScopeOf(tab, protState).durable) {
        durableSites.add(TP.Protection.siteKeyOf(tab.url));
      }
    });
    const durable = durableSites.size;
    let chain = Promise.resolve();
    ids.forEach(function (id) {
      const tab = findTab(id);
      if (!tab) return;
      chain = chain.then(function () {
        return protect ? TP.Protection.protectTab(tab) : TP.Protection.unprotectTab(tab);
      });
    });
    chain.then(function () {
      let text = (protect ? 'Protected' : 'Unprotected') + ' ' + ids.length + ' tabs';
      if (protect && durable < ids.length) {
        text += durable
          ? ' — ' + durable + ' site' + (durable > 1 ? 's' : '') + ' persist, the rest this session only'
          : ' — this session only (never saved to disk)';
      }
      toast(text, 'success');
      loadTabs();
    }).catch(function (err) {
      toast((err && err.message) || 'Protection failed', 'error');
      loadTabs();
    });
  }

  /* ------------------------------------------------------------------ *
   * Live process memory (chrome.processes → onUpdatedWithMemory events)
   * ------------------------------------------------------------------ */

  /**
   * Subscribe to real per-process memory wherever chrome.processes is
   * granted. Events arrive every ~1–2 s; each sample fills the measured
   * bytes of the affected tabs and re-renders the list (throttled).
   */
  function startMemoryWatch() {
    if (memoryStop) { memoryStop(); memoryStop = null; }
    if (!memoryInfo.supported) return;
    memoryStop = TP.TabMemory.watchProcessMemory(function (sample) {
      let changed = false;
      const map = memoryInfo.map || {};
      Object.keys(map).forEach(function (tabId) {
        const entry = map[tabId];
        if (entry && entry.pid != null && sample[entry.pid]) {
          entry.bytes = sample[entry.pid].bytes;
          entry.cpuPct = sample[entry.pid].cpuPct;
          changed = true;
        }
      });
      if (changed) {
        memoryInfo.memoryAvailable = true;
        if (memoryRenderTimer) return; // throttle re-renders
        memoryRenderTimer = setTimeout(function () {
          memoryRenderTimer = null;
          renderTabs();
        }, 800);
      }
    });
  }

  function handleActionResponse(response) {
    if (chrome.runtime.lastError || !response || !response.ok) {
      toast((response && response.error) || 'Discarding failed', 'error');
    } else {
      const summary = response.summary || {};
      const failed = (summary.failed || []).length;
      const protectedSkipped = (summary.skipped && summary.skipped['user-protected']) || 0;
      let text = summary.discardedCount
        ? summary.discardedCount + (summary.discardedCount === 1 ? ' tab discarded' : ' tabs discarded')
        : 'Nothing discarded';
      if (failed) text += ' · ' + failed + ' failed (Chrome restriction)';
      if (protectedSkipped) {
        text += ' · ' + protectedSkipped + ' protected tab' +
          (protectedSkipped === 1 ? ' skipped (unprotect first)' : 's skipped (unprotect first)');
      }
      toast(text, summary.discardedCount ? 'success' : '');
    }
    renderLastOptimization();
    loadTabs();
  }

  /* ------------------------------------------------------------------ *
   * Monitoring loop (compact resource strip)
   * ------------------------------------------------------------------ */

  function startMonitor() {
    if (monitor) monitor.stop();
    monitor = TP.Metrics.create({
      intervalMs: Math.max(1000, settings.monitoring.intervalMs),
      quickStart: true,
      enabled: function (id) {
        return settings.monitoring.enabled && settings.monitoring.monitors[id];
      },
      onSample: onSample
    });
    monitor.start();

    const draw = function () {
      if (chartDirty) {
        chartDirty = false;
        if (settings.monitoring.showGraphs) drawSparklines();
      }
      requestAnimationFrame(draw);
    };
    requestAnimationFrame(draw);

    const statusDot = $('statusDot');
    const statusText = $('statusText');
    if (settings.monitoring.enabled) {
      statusDot.classList.add('on');
      statusText.textContent = 'Monitoring · ' + (settings.monitoring.intervalMs / 1000) + 's';
    } else {
      statusDot.classList.add('off');
      statusText.textContent = 'Monitoring off';
    }
  }

  function onSample(snap) {
    renderCpu(snap.cpu);
    renderMemory(snap.memory);
    renderDisk(snap.disk);
    renderNetwork(snap.network);
    renderGpu(snap.gpu);
    TP.History.push(snap);
    TP.History.flush(false); // internally throttled to one write / 10 s
    chartDirty = true;
  }

  /* ------------------------------------------------------------------
   * Card renderers (restored full overview cards: pill + value + sub)
   * ------------------------------------------------------------------ */

  function setPill(cardId, status, customLabel) {
    const pill = document.querySelector('#' + cardId + ' .tp-pill');
    if (!pill) return;
    pill.dataset.status = status;
    pill.textContent = customLabel || PILL_LABELS[status] || status;
  }

  function renderCpu(cpu) {
    if (!cpu) return;
    const value = $('cpuValue');
    const sub = $('cpuSub');
    const card = $('card-cpu');
    const st = cpu.static || {};
    if (cpu.status === 'warming') {
      setPill('card-cpu', 'warming');
      value.textContent = '…';
    } else if (cpu.utilization && typeof cpu.utilization.system === 'number') {
      setPill('card-cpu', 'available', 'System · Live');
      value.textContent = Util.formatPercent(cpu.utilization.system);
    } else {
      setPill('card-cpu', cpu.status);
      value.textContent = '—';
      sub.textContent = shortenReason(cpu.reason) || PILL_LABELS[cpu.status] || 'Unavailable';
    }
    sub.textContent = (st.cores || '—') + ' cores · ' + (st.archName || '') +
      (cpu.processes && cpu.processes.available && typeof cpu.processes.browserCpuPct === 'number'
        ? ' · browser ' + Util.formatPercent(cpu.processes.browserCpuPct)
        : '');
    sub.title = (st.modelName || '') +
      '\nSystem-wide CPU utilization — all processes, not just Chrome' +
      '\nPer-tab CPU: unavailable (Chrome API limitation)';
    card.title = sub.title;
  }

  function renderMemory(mem) {
    if (!mem) return;
    const value = $('memValue');
    const sub = $('memSub');
    if (mem.status === 'available') {
      setPill('card-memory', 'available');
      value.textContent = Util.formatBytes(mem.used, 1) + ' / ' + Util.formatBytes(mem.capacity, 0);
      sub.textContent = Util.formatPercent(mem.usedPct) + ' used · ' + Util.formatBytes(mem.available, 1) + ' free';
    } else {
      setPill('card-memory', mem.status);
      value.textContent = '—';
      sub.textContent = shortenReason(mem.reason) || PILL_LABELS[mem.status] || 'Unavailable';
    }
    sub.title = mem.reason || 'System RAM: real measurement via chrome.system.memory' +
      '\nPer-tab memory: ' + (memoryInfo.supported
        ? 'measured per tab via chrome.processes (live)'
        : 'shown per tab in the Tabs view as clearly-labeled estimates — Chrome grants chrome.processes only on its Dev channel (Shift+Esc for real values)');
    $('card-memory').title = sub.title;
  }

  function renderDisk(disk) {
    if (!disk) return;
    const value = $('diskValue');
    const sub = $('diskSub');
    const primary = disk.primary;
    if (disk.status === 'available' && primary && primary.usedPct != null) {
      setPill('card-disk', 'available');
      value.textContent = Util.formatPercent(primary.usedPct);
      sub.textContent = Util.formatBytes(primary.available, 0) + ' free of ' + Util.formatBytes(primary.capacity, 0) + ' · ' + primary.name;
    } else {
      setPill('card-disk', disk.status);
      value.textContent = '—';
      sub.textContent = shortenReason(disk.reason) || PILL_LABELS[disk.status] || 'Unavailable';
    }
    sub.title = (disk.reason || 'Primary storage volume') +
      '\nDisk I/O throughput: unavailable (no Chrome API)';
    $('card-disk').title = sub.title;
  }

  function renderNetwork(net) {
    if (!net) return;
    const value = $('netValue');
    const sub = $('netSub');
    if (net.browser) {
      setPill('card-network', 'available', 'Browser · Live');
      value.textContent = '↓ ' + Util.formatThroughput(net.browser.downBps) +
                          '  ↑ ' + Util.formatThroughput(net.browser.upBps);
      sub.textContent = 'Observed browser traffic (ChromeOS)';
      sub.title = 'Observed browser traffic (ChromeOS)\nOS-wide and per-tab traffic are not accessible to extensions';
    } else {
      setPill('card-network', 'unavailable', 'Throughput N/A');
      value.textContent = '—';
      const conn = net.connection;
      if (conn && conn.status === 'estimated' && conn.downlinkMbps != null) {
        setPill('card-network', 'estimated', 'Estimate');
        value.textContent = '≈ ' + conn.downlinkMbps + ' Mbps';
        sub.textContent = 'coarse browser estimate';
        sub.title = 'navigator.connection provides a coarse estimate only.\nOS-wide and per-tab traffic are not accessible to extensions.';
      } else {
        sub.textContent = 'Throughput not available';
        sub.title = 'Network throughput is only observable on ChromeOS.\nOS-wide and per-tab traffic are not accessible to extensions.';
      }
    }
    $('card-network').title = sub.title;
  }

  function renderGpu(gpu) {
    if (!gpu) return;
    const value = $('gpuValue');
    const sub = $('gpuSub');
    if (gpu.status === 'available' || gpu.status === 'estimated') {
      setPill('card-gpu', gpu.status === 'available' ? 'available' : 'estimated', gpu.status === 'available' ? 'WebGL · Live' : 'WebGL · Est.');
      value.textContent = gpu.device || gpu.renderer || gpu.vendor || '—';
      sub.textContent = 'Utilization: unavailable — no Chrome API exposes it';
    } else {
      setPill('card-gpu', gpu.status);
      value.textContent = '—';
      sub.textContent = shortenReason(gpu.reason) || PILL_LABELS[gpu.status] || 'Unavailable';
    }
    sub.title = (gpu.reason || 'GPU (via WebGL)') +
      '\nVendor: ' + (gpu.vendor || '—') + '\nRenderer: ' + (gpu.renderer || '—');
    value.title = sub.title;
    $('card-gpu').title = sub.title;
  }

  function shortenReason(reason) {
    const text = String(reason || '');
    return text.length > 64 ? text.slice(0, 61) + '…' : text;
  }

  function drawSparklines() {
    const windowMs = 2 * 60000;
    TP.Charts.drawSparkline($('cpuSpark'), TP.History.getRange('cpu', windowMs),
      { color: css('--blue'), fixedMin: 0, fixedMax: 100 });
    TP.Charts.drawSparkline($('memSpark'), TP.History.getRange('mem', windowMs),
      { color: css('--green'), fixedMin: 0, fixedMax: 100 });
    TP.Charts.drawSparkline($('diskSpark'), TP.History.getRange('disk', windowMs),
      { color: css('--amber'), fixedMin: 0, fixedMax: 100 });
  }

  function css(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  /* ------------------------------------------------------------------ *
   * External changes (events while the popup is open)
   * ------------------------------------------------------------------ */

  function watchExternalChanges() {
    // Tab events while the popup is open.
    ['onCreated', 'onRemoved', 'onUpdated', 'onActivated', 'onMoved'].forEach(function (name) {
      chrome.tabs[name].addListener(scheduleTabReload);
    });
    // Last optimization summary written by the service worker (measurement
    // completes after the popup may have closed).
    Storage.onLocalChanged([Storage.KEYS.LAST_OPTIMIZATION, Storage.KEYS.LAST_SAVINGS], function () {
      renderLastOptimization();
      scheduleTabReload();
    });
    Storage.onLocalChanged([Storage.KEYS.SETTINGS], function () {
      Storage.getSettings().then(function (s) {
        settings = s;
        renderModeMeta();
        renderTabs(); // favicons toggle etc.
      });
    });
    Storage.onLocalChanged([Storage.KEYS.PROTECTED_TABS, Storage.KEYS.WHITELIST], function () {
      scheduleTabReload();
    });
  }

  /* ------------------------------------------------------------------ *
   * Mode / last optimization
   * ------------------------------------------------------------------ */

  function renderModeMeta() {
    if (!settings) return;
    const o = settings.optimization;
    const names = { manual: 'Manual', balanced: 'Balanced', aggressive: 'Aggressive', protected: 'Protected' };
    $('modeName').textContent = names[o.mode] + ' mode';
    const effIdle = o.mode === 'aggressive'
      ? Math.max(2, Math.ceil(o.idleMinutes / 2))
      : o.idleMinutes;
    const auto = o.autoDiscard && (o.mode === 'balanced' || o.mode === 'aggressive');
    $('autoMeta').textContent = auto
      ? 'auto · idle ≥ ' + effIdle + ' min'
      : 'manual only · idle ≥ ' + effIdle + ' min';
  }

  function renderLastOptimization() {
    Promise.all([
      Storage.get(Storage.KEYS.LAST_OPTIMIZATION),
      Storage.get(Storage.KEYS.LAST_SAVINGS),
      Storage.get(Storage.KEYS.SAVINGS_HISTORY)
    ]).then(function (results) {
      const summary = results[0];
      const savings = results[1];
      const history = Array.isArray(results[2]) ? results[2] : [];
      // Merge deferred measurement by timestamp (see optimizer.js).
      // v1.6.1 audit N7: memoryDeltaBytes is the new name; records and
      // summaries written by v1.6.0 still read through the fallbacks.
      if (summary && savings && savings.ts === summary.time && savings.measured) {
        summary.memoryDeltaBytes = savings.memoryDeltaBytes != null
          ? savings.memoryDeltaBytes : savings.freedBytes;
        summary.memoryMeasured = savings.measured;
        summary.memoryNote = savings.note;
      }
      const el2 = $('lastOpt');
      if (!summary) {
        el2.textContent = savings && savings.measured
          ? 'Earlier run: ' + savings.note
          : 'No optimization yet';
        return;
      }
      const ago = Util.formatDuration(Date.now() - summary.time, { long: true });
      let text = ago + ' ago: ' +
        (summary.discardedCount || 0) + ' discarded · ' +
        (summary.skipped ? sumSkipped(summary.skipped) : 0) + ' skipped';
      // Neutral, honest framing (audit #7): a positive system-memory delta
      // is an observation, not an attribution to TabPilot.
      const deltaBytes = summary.memoryDeltaBytes != null
        ? summary.memoryDeltaBytes : summary.memoryFreedBytes; // legacy name
      if (summary.memoryMeasured && deltaBytes) {
        text += ' · system Δ +' + Util.formatBytes(deltaBytes) + ' (approx.)';
      } else if (summary.memoryMeasured && summary.memoryNote && summary.memoryNote.indexOf('Inconclusive') === 0) {
        text += ' · memory inconclusive';
      }
      el2.textContent = text;
      el2.title = buildSummaryTooltip(summary, history);
    });
  }

  function sumSkipped(skips) {
    let total = 0;
    Object.keys(skips).forEach(function (key) { total += skips[key] || 0; });
    return total;
  }

  function buildSummaryTooltip(summary, history) {
    const lines = ['Last optimization'];
    const labels = {
      'active': 'active', 'pinned': 'pinned', 'audible': 'audible',
      'already-discarded': 'already discarded', 'user-protected': 'protected (you — always enforced)',
      'whitelisted': 'whitelisted domain', 'loading': 'still loading',
      'recent': 'too recent', 'extension-page': 'extension pages',
      'non-discardable': 'non-discardable', 'unknown-age': 'idle unknown', 'min-preserve': 'kept (min tabs)'
    };
    Object.keys(summary.skipped || {}).forEach(function (key) {
      if (summary.skipped[key]) lines.push('Skipped ' + summary.skipped[key] + ' × ' + (labels[key] || key));
    });
    lines.push(summary.memoryNote || '');
    // Recent measurements (last 3) — consecutive runs no longer overwrite
    // each other's verification (audit #7).
    (history || []).slice(-3).forEach(function (rec) {
      lines.push('· ' + Util.formatDuration(Date.now() - rec.ts) + ' ago: ' +
        (rec.note || '').split(' (')[0]);
    });
    return lines.filter(Boolean).join('\n');
  }

  /* ------------------------------------------------------------------ *
   * DOM helper / toast
   * ------------------------------------------------------------------ */

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  let toastTimer = null;

  function toast(message, kind) {
    const element = $('toast');
    element.textContent = message;
    element.dataset.kind = kind || '';
    element.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { element.classList.remove('show'); }, 4200);
  }
})();
