/**
 * TabPilot — service-worker.js (Manifest V3)
 *
 * Responsibilities (event-driven ONLY — no loops, no polling):
 *  1. Track per-tab "last accessed" timestamps (tabs.onCreated / onActivated)
 *     in chrome.storage.session, so idle detection survives SW termination.
 *  2. Run the optimizer:
 *      - on request from the popup / dashboard (runtime.onMessage), so that
 *        measurement and summary-writing continue even if the page closes,
 *      - periodically via a 1-minute chrome.alarms alarm when (and only when)
 *        automatic optimization is enabled (balanced/aggressive + autoDiscard).
 *  3. Finish deferred memory-delta measurements (one-shot alarm + queue).
 *  4. Clean up per-tab state when tabs/windows close and keep the action
 *     badge in sync with automation state.
 *
 * MV3 lifecycle: the worker is terminated by Chrome at any time. Every
 * listener is registered synchronously at the top level (required for event
 * delivery after a cold start) and all state lives in storage, never in
 * module variables.
 *
 * WRITE SERIALIZATION (audit #5): LAST_ACCESS / WINDOW_ACTIVE are single
 * objects that many handlers read-modify-write. Chrome fires bursts (e.g.
 * one onRemoved per tab when a window closes), so unsynchronized writes
 * lose updates. Every mutation of those maps now goes through serialized(),
 * a promise chain that runs one mutation at a time inside this worker.
 */
importScripts(
  '../modules/util.js',
  '../modules/storage.js',
  '../modules/protection.js',
  '../modules/tab-manager.js',
  '../modules/optimizer.js'
);

const TP = self.TabPilot;

const ALARM_AUTO = 'tp:auto-optimize';
// Chrome clamps alarm periods: 1 min minimum on Chrome 116-119, 30 s on 120+.
// A 1-minute check is negligible: it queries tabs once and compares
// timestamps; the worker exits immediately when nothing is eligible.
const AUTO_PERIOD_MIN = 1;

/* ------------------------------------------------------------------ *
 * Write serialization for shared session maps (audit #5)
 * ------------------------------------------------------------------ */

/**
 * Promise-queue mutex: serialized(fn) runs fn (which must return a
 * promise) strictly after the previous serialized call settles. Failures
 * never break the chain. All read-modify-write cycles on LAST_ACCESS and
 * WINDOW_ACTIVE go through here.
 */
let serializationChain = Promise.resolve();
function serialized(fn) {
  const run = serializationChain.then(fn);
  serializationChain = run.catch(function () { /* keep the queue alive */ });
  return run;
}

/* ------------------------------------------------------------------ *
 * Idle tracking (storage.session = RAM-backed, dies with the browser —
 * exactly the right lifetime for "tab was used at" timestamps)
 * ------------------------------------------------------------------ */

/** Called on tab activation: stamp the newly active tab AND the tab the
 *  user just switched away from (its idle clock starts now — conservative). */
function onTabActivated(activeInfo) {
  return serialized(function () {
    const now = Date.now();
    return Promise.all([
      TP.Storage.getSession(TP.Storage.SESSION_KEYS.LAST_ACCESS),
      TP.Storage.getSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE)
    ]).then(function (results) {
      const lastAccess = results[0] || {};
      const windowActive = results[1] || {};

      const previousId = windowActive[activeInfo.windowId];
      if (previousId != null && previousId !== activeInfo.tabId) {
        lastAccess[previousId] = now;
      }
      lastAccess[activeInfo.tabId] = now;
      windowActive[activeInfo.windowId] = activeInfo.tabId;

      return Promise.all([
        TP.Storage.setSession(TP.Storage.SESSION_KEYS.LAST_ACCESS, lastAccess),
        TP.Storage.setSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE, windowActive)
      ]);
    });
  }).catch(function (err) {
    console.warn('[TabPilot] onTabActivated failed:', err && err.message);
  });
}

function onTabCreated(tab) {
  return serialized(function () {
    return TP.Storage.getSession(TP.Storage.SESSION_KEYS.LAST_ACCESS).then(function (lastAccess) {
      const map = lastAccess || {};
      map[tab.id] = Date.now();
      return TP.Storage.setSession(TP.Storage.SESSION_KEYS.LAST_ACCESS, map);
    });
  }).catch(function (err) {
    console.warn('[TabPilot] onTabCreated failed:', err && err.message);
  });
}

function onTabRemoved(tabId) {
  // Remove the closed tab's idle timestamp. Protection state no longer
  // references tab ids (site-keyed), so there is nothing else to forget.
  return serialized(function () {
    return TP.Storage.getSession(TP.Storage.SESSION_KEYS.LAST_ACCESS).then(function (lastAccess) {
      const map = lastAccess || {};
      if (!(tabId in map)) return null;
      delete map[tabId];
      return TP.Storage.setSession(TP.Storage.SESSION_KEYS.LAST_ACCESS, map);
    });
  }).catch(function (err) {
    console.warn('[TabPilot] onTabRemoved failed:', err && err.message);
  });
}

/** Window closed: drop its WINDOW_ACTIVE entry (it can never be referenced
 *  again — window ids are unique per session). */
function onWindowRemoved(windowId) {
  return serialized(function () {
    return TP.Storage.getSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE).then(function (windowActive) {
      const map = windowActive || {};
      if (!(windowId in map)) return null;
      delete map[windowId];
      return TP.Storage.setSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE, map);
    });
  }).catch(function (err) {
    console.warn('[TabPilot] onWindowRemoved failed:', err && err.message);
  });
}

/** Tab moved between windows: refresh the WINDOW_ACTIVE entries of the
 *  affected windows from a live query instead of guessing. */
function resyncWindowActive(windowId) {
  if (windowId == null || windowId < 0) return Promise.resolve();
  return serialized(function () {
    return Promise.all([
      TP.Storage.getSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE),
      TP.Util.callApi(chrome.tabs, 'query', { windowId: windowId })
    ]).then(function (results) {
      const map = results[0] || {};
      const tabs = results[1] || [];
      const active = tabs.filter(function (t) { return t.active; })[0];
      if (active) map[windowId] = active.id;
      else delete map[windowId];
      return TP.Storage.setSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE, map);
    });
  }).catch(function (err) {
    console.warn('[TabPilot] resyncWindowActive failed:', err && err.message);
  });
}

function onTabAttached(tabId, attachInfo) {
  return resyncWindowActive(attachInfo && attachInfo.newWindowId);
}

function onTabDetached(tabId, detachInfo) {
  return resyncWindowActive(detachInfo && detachInfo.oldWindowId);
}

/** Seed timestamps for tabs that already exist (install / browser startup). */
async function baselineLastAccess() {
  return serialized(function () {
    return TP.Tabs.getAll().then(function (tabs) {
      const now = Date.now();
      return Promise.all([
        TP.Storage.getSession(TP.Storage.SESSION_KEYS.LAST_ACCESS),
        TP.Storage.getSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE)
      ]).then(function (results) {
        const lastAccess = results[0] || {};
        const windowActive = results[1] || {};
        tabs.forEach(function (tab) {
          if (!(tab.id in lastAccess)) lastAccess[tab.id] = now;
          if (tab.active) windowActive[tab.windowId] = tab.id;
        });
        // Unconditional write: the window map must refresh even when no
        // lastAccess entry was added.
        return Promise.all([
          TP.Storage.setSession(TP.Storage.SESSION_KEYS.LAST_ACCESS, lastAccess),
          TP.Storage.setSession(TP.Storage.SESSION_KEYS.WINDOW_ACTIVE, windowActive)
        ]);
      });
    });
  }).catch(function (err) {
    console.warn('[TabPilot] baselineLastAccess failed:', err && err.message);
  });
}

/* ------------------------------------------------------------------ *
 * Automation scheduling
 * ------------------------------------------------------------------ */

/**
 * Keep the auto-optimize alarm in sync with settings — WITHOUT resetting a
 * running alarm (audit #4). alarms.create() with an existing name REPLACES
 * the alarm (restart of its delay), and this worker wakes on every tab
 * event; recreating on every wake meant frequent switchers could starve the
 * auto-run forever. Now the alarm is only created when missing (or when the
 * desired period changed), and cleared when automation is off.
 */
async function syncAutomation() {
  try {
    const settings = await TP.Storage.getSettings();
    const active = TP.Optimizer.isAutomationActive(settings);
    if (!active) {
      await TP.Util.callApi(chrome.alarms, 'clear', ALARM_AUTO);
      updateBadge(false);
      return;
    }
    const existing = await TP.Util.callApi(chrome.alarms, 'get', ALARM_AUTO);
    const periodOk = existing &&
      existing.periodInMinutes === AUTO_PERIOD_MIN;
    if (!periodOk) {
      await TP.Util.callApi(chrome.alarms, 'create', ALARM_AUTO, {
        delayInMinutes: AUTO_PERIOD_MIN,
        periodInMinutes: AUTO_PERIOD_MIN
      });
    }
    updateBadge(true);
  } catch (err) {
    console.warn('[TabPilot] syncAutomation failed:', err && err.message);
  }
}

/** Small green dot on the toolbar icon while automation is active. */
function updateBadge(active) {
  try {
    chrome.action.setBadgeText({ text: active ? '•' : '' });
    if (active) {
      chrome.action.setBadgeBackgroundColor({ color: '#3ddc97' });
      if (typeof chrome.action.setBadgeTextColor === 'function') {
        chrome.action.setBadgeTextColor({ color: '#0b0d12' });
      }
    }
  } catch (err) { /* cosmetic only */ }
}

/* ------------------------------------------------------------------ *
 * Alarms
 * ------------------------------------------------------------------ */

async function onAlarm(alarm) {
  try {
    if (alarm.name === ALARM_AUTO) {
      await TP.Optimizer.run({ trigger: 'auto' });
    } else if (alarm.name === TP.Optimizer.VERIFY_ALARM) {
      await TP.Optimizer.completePendingMeasurement();
    }
  } catch (err) {
    console.warn('[TabPilot] alarm handler failed:', err && err.message);
  }
}

/* ------------------------------------------------------------------ *
 * Messages from popup / dashboard
 * ------------------------------------------------------------------ */

function onMessage(request, sender, sendResponse) {
  if (request && request.type === 'tp:optimize') {
    TP.Optimizer.run({
      trigger: request.trigger === 'selection' ? 'selection' : 'manual',
      tabIds: Array.isArray(request.tabIds) ? request.tabIds : null
    }).then(function (summary) {
      sendResponse({ ok: true, summary: summary });
    }).catch(function (err) {
      sendResponse({ ok: false, error: (err && err.message) || 'Optimization failed' });
    });
    return true; // keep the message channel open for the async reply
  }
  if (request && request.type === 'tp:sync-automation') {
    syncAutomation().then(function () {
      sendResponse({ ok: true });
    });
    return true;
  }
  return false;
}

/* ------------------------------------------------------------------ *
 * Lifecycle
 * ------------------------------------------------------------------ */

async function onInstalled(details) {
  try {
    // FRESH INSTALL ONLY (v1.6.1 audit N3): gate on details.reason so an
    // UPDATE never seeds conferencing/web-mail domains into the whitelist
    // of an upgrading user who deliberately emptied it — the v1.6.0 code
    // ran the seed on every onInstalled and the comments claimed it didn't.
    // (seedWhitelistIfFresh stays key-existence-idempotent as a second line
    // of defense.) Upgraders also KEEP their stored optimization mode: only
    // fresh installs get the Manual-by-default opt-in — see
    // docs/RELEASE-NOTES.md.
    const freshInstall = !details || details.reason === 'install';
    await TP.Storage.getSettings();          // writes settings defaults on first run
    if (freshInstall) {
      await TP.Storage.seedWhitelistIfFresh(); // fresh install: conferencing/web-mail seed (audit #3)
    }
    // PRIVACY (v1.6.1 audit N6): v1.5.0 persisted discarded-tab titles in
    // the stored last-optimization summary — scrub them once on upgrade
    // (idempotent; no write when the summary is already clean).
    await TP.Storage.scrubLegacySummaries();
    await baselineLastAccess();
    await syncAutomation();
  } catch (err) {
    console.warn('[TabPilot] onInstalled failed:', err && err.message);
  }
}

async function onStartup() {
  try {
    // Also scrub on startup: covers profiles that upgraded while the
    // browser was closed and skip onInstalled on the next cold start.
    await TP.Storage.scrubLegacySummaries();
    await baselineLastAccess();
    await syncAutomation();
  } catch (err) {
    console.warn('[TabPilot] onStartup failed:', err && err.message);
  }
}

/* Settings changed elsewhere (e.g. another page) -> re-sync the alarm.
 * syncAutomation only creates/clears when needed, so an unrelated settings
 * write (theme change) no longer resets a running alarm (audit #4). */
function onStorageChanged(changes, area) {
  if (area === 'local' && TP.Storage.KEYS.SETTINGS in changes) {
    syncAutomation();
  }
}

/* Registered synchronously at the top level on every worker start. */
chrome.runtime.onInstalled.addListener(onInstalled);
chrome.runtime.onStartup.addListener(onStartup);
chrome.runtime.onMessage.addListener(onMessage);
chrome.alarms.onAlarm.addListener(onAlarm);
chrome.tabs.onActivated.addListener(onTabActivated);
chrome.tabs.onCreated.addListener(onTabCreated);
chrome.tabs.onRemoved.addListener(onTabRemoved);
chrome.tabs.onAttached.addListener(onTabAttached);
chrome.tabs.onDetached.addListener(onTabDetached);
chrome.windows.onRemoved.addListener(onWindowRemoved);
chrome.storage.onChanged.addListener(onStorageChanged);

/* Initial sync in case the worker cold-starts without onInstalled/onStartup
 * (e.g. woken by a tab event after an idle termination). Harmless: it only
 * creates the alarm if it is missing and automation is enabled. */
syncAutomation();
