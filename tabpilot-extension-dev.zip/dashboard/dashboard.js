/**
 * TabPilot — dashboard.js
 * Full-page dashboard controller.
 *
 * Sections: Overview (resource cards, history charts, tab overview,
 * optimization, system info), Tabs (the tab manager) and Settings
 * (the shared settings component).
 *
 * Efficiency rules implemented here:
 *  - Sampling stops the moment the page is hidden or closed.
 *  - Chart redraws are folded into one requestAnimationFrame.
 *  - The tab list rebuilds only on tab events and explicit actions.
 *  - Everything user-generated is inserted via textContent (no innerHTML
 *    for dynamic strings) — safe and fast.
 */
(function () {
  'use strict';

  const TP = self.TabPilot;
  const Util = TP.Util;
  const Storage = TP.Storage;
  const $ = function (id) { return document.getElementById(id); };

  let settings = null;
  let monitor = null;
  let protState = { whitelist: [], protectedSites: {}, sessionSites: {} };
  let tabsData = [];
  let lastAccessMap = {};

  /* tabs-section state */
  let tabFilter = 'all';
  let tabSort = 'recent';
  let tabSearch = '';
  const selection = new Set();
  let currentDialogTab = null;

  /* chart state */
  let rangeMs = 5 * 60000;
  let chartsDirty = false;

  const PILL_LABELS = {
    available: 'Live', estimated: 'Estimated', warming: 'Measuring…',
    unavailable: 'Unavailable', permission: 'Blocked', error: 'Error', disabled: 'Off'
  };

  const ICONS = {
    focus: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 2.5h4v4"/><path d="M13 3 7.5 8.5"/><path d="M11.5 9.5v4h-9v-9h4"/></svg>',
    reload: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.5 8a5.5 5.5 0 1 1-1.6-3.9L13.5 5.6"/><path d="M13.5 2.8v2.8h-2.8"/></svg>',
    discard: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.5 9.2A6 6 0 1 1 6.8 2.5 4.8 4.8 0 0 0 13.5 9.2z"/></svg>',
    shield: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 1.8 13.5 4v3.4c0 3.5-2.4 5.7-5.5 6.8-3.1-1.1-5.5-3.3-5.5-6.8V4z"/><path d="m5.6 7.8 1.7 1.7 3.1-3.3"/></svg>',
    close: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><line x1="3.5" y1="3.5" x2="12.5" y2="12.5"/><line x1="12.5" y1="3.5" x2="3.5" y2="12.5"/></svg>'
  };

  /* ================================================================== *
   * Boot
   * ================================================================== */

  document.addEventListener('DOMContentLoaded', function () {
    TP.Theme.init();
    Storage.getSettings().then(function (s) {
      settings = s;
      return TP.History.init(s);
    }).then(function () {
      wireNav();
      wireOverviewControls();
      wireTabsControls();
      wireDialog();
      watchExternalChanges();
      TP.SettingsUI.mount($('settingsRoot'));
      startMonitor();
      renderSystemInfo();
      syncOptPanel();
      renderLastSummary();
      loadEverything();
      requestAnimationFrame(chartLoop);
    });
  });

  window.addEventListener('pagehide', function () {
    if (monitor) monitor.stop();
    TP.History.flush(true);
  });

  window.addEventListener('resize', function () { chartsDirty = true; });

  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) loadEverything(); // refresh tab state when returning
  });

  async function loadEverything() {
    await Promise.all([refreshProtectionState(), loadTabs()]);
    renderTabChips();
    renderModePanelBits();
  }

  async function refreshProtectionState() {
    protState = await TP.Protection.getState();
  }

  /* ================================================================== *
   * Navigation — one scrolling page; the header buttons jump to the
   * matching section (smooth scroll), and a scroll-spy keeps the nav
   * highlight in sync with what is currently in view.
   * ================================================================== */

  const SECTIONS = ['overview', 'tabs', 'settings'];
  let spySuppressed = false;
  let spyTimer = null;
  let spyRaf = null;
  let userScrolled = false; // aborts the initial hash re-land

  function wireNav() {
    $('navSeg').addEventListener('click', function (event) {
      const btn = event.target.closest('button[data-section]');
      if (!btn) return;
      activateSection(btn.dataset.section, false);
    });
    window.addEventListener('hashchange', function () {
      // Back/forward or a pasted #hash — jump instantly.
      activateSection((location.hash || '#overview').slice(1), true);
    });
    const initial = (location.hash || '#overview').slice(1);
    activateSection(initial, true);
    window.addEventListener('scroll', scheduleScrollSpy, { passive: true });

    $('btnManageTabs').addEventListener('click', function () { activateSection('tabs', false); });
    $('btnOptionsPage').addEventListener('click', function () { chrome.runtime.openOptionsPage(); });

    // The first render is async (tab list, settings mount) and shifts the
    // sections below it — re-land on the requested section once layout has
    // settled, unless the user has already scrolled on their own.
    ['wheel', 'touchmove', 'keydown'].forEach(function (name) {
      window.addEventListener(name, function () { userScrolled = true; }, { passive: true, once: true });
    });
    [450, 1200].forEach(function (delay) {
      setTimeout(function () {
        if (!userScrolled) activateSection(initial, true);
      }, delay);
    });
  }

  /** Jump to a section: smooth for clicks, instant for hash loads. */
  function activateSection(name, instant) {
    if (SECTIONS.indexOf(name) === -1) name = 'overview';
    syncNavSelection(name);
    const target = $('section-' + name);
    if (!target) return;
    const header = document.querySelector('.dash-header');
    const offset = (header ? header.offsetHeight : 0) + 12;
    const top = Math.max(0, target.getBoundingClientRect().top + window.scrollY - offset);
    suppressScrollSpy();
    window.scrollTo({ top: top, behavior: instant ? 'auto' : 'smooth' });
    // Keep the URL shareable (dashboard.html#tabs) without firing hashchange.
    if (!instant && location.hash !== '#' + name) {
      history.replaceState(null, '', '#' + name);
    }
    chartsDirty = true; // canvas sizes may settle after the scroll
  }

  function syncNavSelection(name) {
    $('navSeg').querySelectorAll('button').forEach(function (button) {
      button.setAttribute('aria-selected', String(button.dataset.section === name));
    });
  }

  function suppressScrollSpy() {
    spySuppressed = true;
    if (spyTimer) clearTimeout(spyTimer);
    spyTimer = setTimeout(function () {
      spySuppressed = false;
      scheduleScrollSpy(); // re-sync: the programmatic scroll has settled
    }, 900);
  }

  /** Highlight the button of the section that is currently in view. */
  function scheduleScrollSpy() {
    if (spyRaf) return;
    spyRaf = requestAnimationFrame(function () {
      spyRaf = null;
      if (spySuppressed) return;
      const header = document.querySelector('.dash-header');
      const probe = window.scrollY + (header ? header.offsetHeight : 0) + 48;
      let current = 'overview';
      SECTIONS.forEach(function (name) {
        const sec = $('section-' + name);
        if (sec && sec.getBoundingClientRect().top + window.scrollY <= probe) current = name;
      });
      syncNavSelection(current);
    });
  }

  /* ================================================================== *
   * Monitoring
   * ================================================================== */

  function startMonitor() {
    if (monitor) monitor.stop();
    const statusDot = $('statusDot');
    const statusText = $('statusText');
    if (!settings.monitoring.enabled) {
      statusDot.className = 'status-dot off';
      statusText.textContent = 'Monitoring disabled in settings';
      document.querySelectorAll('#section-overview .tp-pill').forEach(function (pill) {
        pill.dataset.status = 'disabled';
        pill.textContent = PILL_LABELS.disabled;
      });
      return;
    }
    monitor = TP.Metrics.create({
      intervalMs: Math.max(1000, settings.monitoring.intervalMs),
      enabled: function (id) { return settings.monitoring.monitors[id]; },
      onSample: onSample
    });
    monitor.start();
    statusDot.className = 'status-dot on';
    statusText.textContent = 'Monitoring · ' + (settings.monitoring.intervalMs / 1000) + 's';
  }

  let selfOverheadTick = 0;

  function onSample(snap) {
    renderCpuCard(snap.cpu);
    renderMemoryCard(snap.memory);
    renderDiskCard(snap.disk);
    renderNetworkCard(snap.network);
    renderGpuCard(snap.gpu);
    TP.History.push(snap);
    TP.History.flush(false);
    if (settings.monitoring.showGraphs) chartsDirty = true;
    if (++selfOverheadTick % 5 === 0) renderSelfOverhead();
  }

  /* ------------------------------------------------------------------ *
   * Resource cards
   * ------------------------------------------------------------------ */

  function setPill(cardId, status, label) {
    const pill = document.querySelector('#' + cardId + ' .tp-pill');
    if (!pill) return;
    pill.dataset.status = status;
    pill.textContent = label || PILL_LABELS[status] || status;
  }

  function renderCpuCard(cpu) {
    if (!cpu) return;
    const st = cpu.static || {};
    $('cpuModel').textContent = st.modelName || '—';
    $('cpuModel').title = st.modelName || '';
    $('cpuCoresCount').textContent = (st.cores || '—') + ' / ' + (st.archName || '—');
    if (cpu.status === 'warming') {
      setPill('card-cpu', 'warming');
      $('cpuValue').textContent = '…';
    } else if (cpu.utilization && typeof cpu.utilization.system === 'number') {
      setPill('card-cpu', 'available', 'System · Live');
      $('cpuValue').textContent = Util.formatPercent(cpu.utilization.system);
    } else {
      setPill('card-cpu', cpu.status);
      $('cpuValue').textContent = '—';
    }
    if (cpu.processes && cpu.processes.available) {
      $('cpuBrowser').textContent = typeof cpu.processes.browserCpuPct === 'number'
        ? Util.formatPercent(cpu.processes.browserCpuPct) + ' of system capacity'
        : 'measuring…';
    } else {
      $('cpuBrowser').textContent = 'Unavailable outside ChromeOS (per-process data)';
    }
    if (cpu.perCore) TP.Charts.drawCoreBars($('cpuCores'), cpu.perCore, { color: cssVar('--blue') });
    $('sysCpu').textContent = st.modelName || '—';
    $('sysArch').textContent = (st.archName || '—') + (st.cores ? ' · ' + st.cores + ' cores' : '');
    $('sysFeatures').textContent = (st.features || []).slice(0, 8).join(', ') || '—';
  }

  function renderMemoryCard(mem) {
    if (!mem) return;
    if (mem.status === 'available') {
      setPill('card-memory', 'available');
      $('memValue').textContent = Util.formatPercent(mem.usedPct);
      $('memUsedTotal').textContent = Util.formatBytes(mem.used, 1) + ' / ' + Util.formatBytes(mem.capacity, 0);
      $('memAvailable').textContent = Util.formatBytes(mem.available, 1);
      $('memSub').textContent = 'Measured: ' + Util.formatBytes(mem.used, 1) + ' of ' + Util.formatBytes(mem.capacity, 0) + ' in use';
    } else {
      setPill('card-memory', mem.status);
      $('memValue').textContent = '—';
      $('memSub').textContent = mem.reason || '';
      $('memUsedTotal').textContent = '—';
      $('memAvailable').textContent = '—';
    }
  }

  function renderDiskCard(disk) {
    if (!disk) return;
    const primary = disk.primary;
    if (disk.status === 'available' && primary && primary.usedPct != null) {
      setPill('card-disk', 'available');
      $('diskValue').textContent = Util.formatPercent(primary.usedPct);
      $('diskPrimary').textContent = primary.name + ' (' + primary.type + ')';
      $('diskFree').textContent = Util.formatBytes(primary.available, 0) + ' / ' + Util.formatBytes(primary.capacity, 0);
      $('diskSub').textContent = primary.name + ': ' + Util.formatBytes(primary.available, 0) + ' free';
      const others = disk.volumes.filter(function (v) { return v.id !== primary.id && v.capacity; });
      $('diskOthers').textContent = others.length
        ? others.map(function (v) { return v.name + ' (' + Util.formatBytes(v.capacity, 0) + ')'; }).join(', ')
        : 'none detected';
    } else {
      setPill('card-disk', disk.status);
      $('diskValue').textContent = '—';
      $('diskSub').textContent = disk.reason || '';
    }
  }

  function renderNetworkCard(net) {
    if (!net) return;
    if (net.browser) {
      setPill('card-network', 'available', 'Browser · Live');
      $('netValue').textContent = '↓ ' + Util.formatThroughput(net.browser.downBps) + ' · ↑ ' + Util.formatThroughput(net.browser.upBps);
      $('netDown').textContent = Util.formatThroughput(net.browser.downBps) + ' (total ' + Util.formatBytes(net.browser.totalDown) + ')';
      $('netUp').textContent = Util.formatThroughput(net.browser.upBps) + ' (total ' + Util.formatBytes(net.browser.totalUp) + ')';
      $('netSub').textContent = 'Observed browser traffic (per-process counters) — not OS-wide traffic';
      $('netChartNote').hidden = true;
      $('chartNet').style.display = '';
    } else {
      setPill('card-network', 'unavailable', 'Throughput N/A');
      $('netValue').textContent = '—';
      $('netDown').textContent = 'Unavailable outside ChromeOS';
      $('netUp').textContent = 'Unavailable outside ChromeOS';
      const conn = net.connection;
      $('netConn').textContent = conn && conn.downlinkMbps != null
        ? '≈ ' + conn.downlinkMbps + ' Mbps · ' + (conn.effectiveType || conn.type || 'unknown') + ' (browser estimate)'
        : 'not available';
      $('netSub').textContent = 'Chrome does not expose traffic to extensions on this platform';
      $('netChartNote').hidden = false;
      $('netChartNote').textContent = 'Network throughput is not charted here: Chrome exposes browser traffic only on ChromeOS. The connection estimate above is the browser\u2019s own coarse rating, not a measurement.';
      $('chartNet').style.display = 'none';
    }
  }

  function renderGpuCard(gpu) {
    if (!gpu) return;
    if (gpu.status === 'available' || gpu.status === 'estimated') {
      setPill('card-gpu', gpu.status, gpu.status === 'available' ? 'WebGL · Live' : 'WebGL · Est.');
      $('gpuValue').textContent = gpu.device || gpu.renderer || gpu.vendor || '—';
      $('gpuValue').title = 'Renderer: ' + (gpu.renderer || '—');
      $('gpuVendor').textContent = gpu.vendor || '—';
      $('gpuRenderer').textContent = gpu.renderer || '—';
      $('gpuSub').textContent = (gpu.vendor || '') + (gpu.reason || '');
      $('gpuProcess').textContent = 'Unavailable outside ChromeOS';
    } else {
      setPill('card-gpu', gpu.status);
      $('gpuValue').textContent = '—';
      $('gpuSub').textContent = gpu.reason || '';
    }
  }

  /* ------------------------------------------------------------------ *
   * Charts
   * ------------------------------------------------------------------ */

  function chartLoop() {
    if (chartsDirty) {
      chartsDirty = false;
      drawAllCharts();
    }
    requestAnimationFrame(chartLoop);
  }

  function drawAllCharts() {
    if (!settings.monitoring.showGraphs) return;
    const blue = cssVar('--blue');
    const green = cssVar('--green');
    const amber = cssVar('--amber');
    const cyan = cssVar('--cyan');
    const red = cssVar('--red');

    const pct = function (v) { return Math.round(v) + '%'; };

    TP.Charts.drawChart($('chartCpu'), {
      windowMs: rangeMs,
      fixedMin: 0, fixedMax: 100, format: pct,
      series: [{ points: TP.History.getRange('cpu', rangeMs), color: blue }]
    });
    TP.Charts.drawChart($('chartMem'), {
      windowMs: rangeMs,
      fixedMin: 0, fixedMax: 100, format: pct,
      series: [{ points: TP.History.getRange('mem', rangeMs), color: green }]
    });
    TP.Charts.drawChart($('chartDisk'), {
      windowMs: rangeMs,
      fixedMin: 0, fixedMax: 100, format: pct,
      series: [{ points: TP.History.getRange('disk', rangeMs), color: amber }]
    });
    TP.Charts.drawChart($('chartNet'), {
      windowMs: rangeMs,
      format: function (v) { return Util.formatThroughput(v); },
      series: [
        { points: TP.History.getRange('netDown', rangeMs), color: cyan, fill: false },
        { points: TP.History.getRange('netUp', rangeMs), color: red, fill: false }
      ]
    });

    TP.Charts.drawSparkline($('cpuSpark'), TP.History.getRange('cpu', Math.min(rangeMs, 10 * 60000)),
      { color: blue, fixedMin: 0, fixedMax: 100 });
    TP.Charts.drawSparkline($('memSpark'), TP.History.getRange('mem', Math.min(rangeMs, 10 * 60000)),
      { color: green, fixedMin: 0, fixedMax: 100 });
    TP.Charts.drawSparkline($('diskSpark'), TP.History.getRange('disk', Math.min(rangeMs, 10 * 60000)),
      { color: amber, fixedMin: 0, fixedMax: 100 });
    TP.Charts.drawSparkline($('netSpark'), TP.History.getRange('netDown', Math.min(rangeMs, 10 * 60000)),
      { color: cyan });
  }

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function wireOverviewControls() {
    $('rangeSeg').addEventListener('click', function (event) {
      const btn = event.target.closest('button[data-range]');
      if (!btn) return;
      rangeMs = Number(btn.dataset.range);
      $('rangeSeg').querySelectorAll('button').forEach(function (b) {
        b.setAttribute('aria-selected', String(b === btn));
      });
      chartsDirty = true;
    });

    $('btnClearHistory').addEventListener('click', function () {
      TP.History.clear().then(function () {
        chartsDirty = true;
        toast('Performance history cleared');
      });
    });

    $('btnOptimize').addEventListener('click', function () { runOptimize(); });
    $('tabChips').addEventListener('click', function (event) {
      const chip = event.target.closest('[data-filter]');
      if (!chip) return;
      tabFilter = chip.dataset.filter || 'all';
      syncFilterChips();
      activateSection('tabs');
      renderTabsSection();
    });
  }

  function syncFilterChips() {
    $('filterChips').querySelectorAll('button').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.dataset.filter === tabFilter));
    });
  }

  /* ================================================================== *
   * Optimization panel
   * ================================================================== */

  function wireOverviewOptControls() {
    $('modeCards').addEventListener('change', function (event) {
      const radio = event.target.closest('input[name="mode"]');
      if (radio) saveSettings({ optimization: { mode: radio.value } });
    });
    $('optIdle').addEventListener('change', function () {
      saveSettings({ optimization: { idleMinutes: Number($('optIdle').value) } });
    });
    $('optMinKeep').addEventListener('change', function () {
      saveSettings({ optimization: { minPreservedTabs: Util.clamp(parseInt($('optMinKeep').value, 10) || 5, 1, 20) } });
    });
    $('optAuto').addEventListener('change', function () {
      saveSettings({ optimization: { autoDiscard: $('optAuto').checked } });
    });
  }

  function syncOptPanel() {
    const o = settings.optimization;
    const radios = $('modeCards').querySelectorAll('input[name="mode"]');
    radios.forEach(function (r) { r.checked = r.value === o.mode; });
    $('optIdle').value = String(o.idleMinutes);
    $('optMinKeep').value = String(o.minPreservedTabs);
    const auto = o.autoDiscard && (o.mode === 'balanced' || o.mode === 'aggressive');
    $('optAuto').checked = auto;
    $('optAuto').disabled = !(o.mode === 'balanced' || o.mode === 'aggressive');
    const effIdle = o.mode === 'aggressive' ? Math.max(2, Math.ceil(o.idleMinutes / 2)) : o.idleMinutes;
    $('optAutoNote').textContent = auto
      ? '· active: idle ≥ ' + effIdle + ' min, check every 1 min'
      : '· requires Balanced or Aggressive mode';
  }

  function renderModePanelBits() { syncOptPanel(); }

  function runOptimize() {
    const btn = $('btnOptimize');
    btn.disabled = true;
    btn.textContent = 'Optimizing…';
    requestOptimize('manual', null).then(function (response) {
      btn.disabled = false;
      btn.innerHTML = '<svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M8.6 1.2 3 9h4l-.9 5.8L12.4 7H8.3l.3-5.8z"/></svg><span>Optimize Browser</span>';
      if (!response || !response.ok) {
        toast((response && response.error) || 'Optimization failed', 'error');
        return;
      }
      renderLastSummary();
      loadEverything();
    });
  }

  /**
   * Optimize through the service worker (preferred — measurement and summary
   * persist even if the page closes). Falls back to running the same
   * optimizer locally when the worker does not respond (it may be in the
   * middle of a cold start or was stopped unexpectedly).
   */
  function requestOptimize(trigger, tabIds) {
    return new Promise(function (resolve) {
      const localFallback = function (errorMessage) {
        if (TP.Optimizer) {
          TP.Optimizer.run({ trigger: trigger, tabIds: tabIds })
            .then(function (summary) { resolve({ ok: true, summary: summary }); })
            .catch(function (err) { resolve({ ok: false, error: (err && err.message) || 'failed' }); });
        } else {
          resolve({ ok: false, error: errorMessage });
        }
      };
      try {
        chrome.runtime.sendMessage({ type: 'tp:optimize', trigger: trigger, tabIds: tabIds || null }, function (response) {
          if (chrome.runtime.lastError || !response) {
            localFallback((chrome.runtime.lastError && chrome.runtime.lastError.message) || 'Service worker unavailable');
          } else {
            resolve(response);
          }
        });
      } catch (err) {
        localFallback(err && err.message);
      }
    });
  }

  const SKIP_LABELS = {
    'active': 'active', 'pinned': 'pinned', 'audible': 'audible',
    'already-discarded': 'already discarded',
    'user-protected': 'protected (you — always enforced)',
    'whitelisted': 'whitelisted domain', 'recent': 'too recent',
    'loading': 'still loading',
    'extension-page': 'extension pages', 'non-discardable': 'non-discardable',
    'unknown-age': 'idle unknown', 'min-preserve': 'kept (minimum tabs)'
  };

  async function renderLastSummary() {
    const summaryEl = $('optSummary');
    const results = await Promise.all([
      Storage.get(Storage.KEYS.LAST_OPTIMIZATION),
      Storage.get(Storage.KEYS.LAST_SAVINGS),
      Storage.get(Storage.KEYS.SAVINGS_HISTORY)
    ]);
    let summary = results[0];
    const savings = results[1];
    const history = Array.isArray(results[2]) ? results[2] : [];
    // Merge the deferred measurement record by timestamp (race-proof:
    // the periodic auto check may rewrite LAST_OPTIMIZATION while the
    // measurement alarm is pending). v1.6.1 audit N7: the field is
    // memoryDeltaBytes now; savings records written by v1.6.0 (freedBytes)
    // and summaries (memoryFreedBytes) still read through the fallbacks.
    if (summary && savings && savings.ts === summary.time && savings.measured) {
      summary.memoryDeltaBytes = savings.memoryDeltaBytes != null
        ? savings.memoryDeltaBytes : savings.freedBytes;
      summary.memoryMeasured = savings.measured;
      summary.memoryNote = savings.note;
      if (savings.renderersAfter != null && summary.renderers) summary.renderers.after = savings.renderersAfter;
    }
    if (!summary) {
      summaryEl.innerHTML = '';
      summaryEl.appendChild(document.createTextNode('No optimization has run yet. Click “Optimize Browser” to discard eligible inactive tabs.'));
      return;
    }
    summaryEl.innerHTML = '';
    const ago = Util.formatDuration(Date.now() - summary.time, { long: true });

    const head = el('div');
    const big = el('span', 'big',
      summary.discardedCount > 0
        ? summary.discardedCount + (summary.discardedCount === 1 ? ' tab discarded' : ' tabs discarded')
        : 'Nothing to discard');
    head.appendChild(big);
    head.appendChild(document.createTextNode(
      ' · ' + ago + ' ago · mode: ' + (summary.mode || '?') +
      (summary.trigger === 'auto' ? ' (automatic)' : summary.trigger === 'selection' ? ' (your selection)' : '')));
    summaryEl.appendChild(head);

    const detail = el('div');
    detail.appendChild(document.createTextNode(
      summary.scanned + ' tabs scanned · ' + sumSkipped(summary.skipped) + ' skipped'));
    if (summary.renderers && (summary.renderers.before != null || summary.renderers.after != null)) {
      detail.appendChild(document.createTextNode(
        ' · renderer processes: ' + (summary.renderers.before != null ? summary.renderers.before : '—') +
        ' → ' + (summary.renderers.after != null ? summary.renderers.after : '—')));
    }
    summaryEl.appendChild(detail);

    if (summary.memoryNote) {
      const mem = el('div');
      mem.appendChild(document.createTextNode(summary.memoryNote));
      summaryEl.appendChild(mem);
    }

    // Recent measurements (last 3) that do not belong to the summary shown
    // — consecutive runs no longer overwrite each other's verification.
    // v1.6.1 audit N7: each earlier run is its own line element (plain
    // text nodes with "\n" collapsed into one run-together paragraph).
    const recs = history.filter(function (rec) { return rec && rec.ts !== (summary && summary.time); });
    if (recs.length) {
      const older = el('div', 'earlier-runs');
      recs.slice(-3).reverse().forEach(function (rec) {
        const olderAgo = Util.formatDuration(Date.now() - (rec.completedAt || rec.ts), { long: true });
        older.appendChild(el('div', 'earlier-line', 'Earlier run (' + olderAgo + ' ago): ' + (rec.note || '')));
      });
      summaryEl.appendChild(older);
    }

    const skips = summary.skipped || {};
    const skipKeys = Object.keys(skips).filter(function (k) { return skips[k] > 0; });
    if (skipKeys.length) {
      const list = el('ul');
      skipKeys.slice(0, 6).forEach(function (key) {
        list.appendChild(el('li', null, skips[key] + ' × ' + (SKIP_LABELS[key] || key)));
      });
      summaryEl.appendChild(list);
    }

    // PRIVACY (v1.6.1 audit N6): only ids + bare domains are stored;
    // legacy v1.5.0 titles are scrubbed on install/update/startup.
    const titles = (summary.tabsDiscarded || []).slice(0, 8).map(function (t) { return (t && t.domain) || (t && t.id); });
    if (titles.length) {
      const list = el('ul');
      titles.forEach(function (title) { list.appendChild(el('li', null, title)); });
      if ((summary.tabsDiscarded || []).length > 8) {
        list.appendChild(el('li', null, '… and ' + (summary.tabsDiscarded.length - 8) + ' more'));
      }
      summaryEl.appendChild(list);
    }
  }

  function sumSkipped(skips) {
    let total = 0;
    Object.keys(skips || {}).forEach(function (key) { total += skips[key] || 0; });
    return total;
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  /* ================================================================== *
   * Tab overview chips
   * ================================================================== */

  function renderTabChips() {
    const counts = TP.Tabs.counts(tabsData, protState, settings);
    const wrap = $('tabChips');
    wrap.innerHTML = '';
    const defs = [
      // [count key, label, accent, tab-manager filter to apply on click]
      ['total', 'tabs', '', 'all'],
      ['active', 'active', 'green', 'active'],
      ['inactive', 'inactive', '', 'inactive'],
      ['discarded', 'discarded', 'blue', 'discarded'],
      ['protected', 'protected', 'amber', 'protected'],
      ['pinned', 'pinned', '', 'all'],
      ['audible', 'audible', 'blue', 'audible']
    ];
    defs.forEach(function (def) {
      const chip = el('button', 'tp-chip clickable');
      chip.dataset.filter = def[3];
      chip.dataset.accent = def[2];
      chip.appendChild(el('span', 'num', String(counts[def[0]])));
      chip.appendChild(document.createTextNode(' ' + def[1]));
      chip.title = 'Show ' + def[1] + ' tabs in the tab manager';
      wrap.appendChild(chip);
    });
  }

  /* ================================================================== *
   * Tabs section
   * ================================================================== */

  function wireTabsControls() {
    wireOverviewOptControls();

    $('filterChips').addEventListener('click', function (event) {
      const btn = event.target.closest('button[data-filter]');
      if (!btn) return;
      tabFilter = btn.dataset.filter;
      $('filterChips').querySelectorAll('button').forEach(function (b) {
        b.setAttribute('aria-pressed', String(b === btn));
      });
      renderTabsSection();
    });

    $('sortSelect').addEventListener('change', function () {
      tabSort = $('sortSelect').value;
      renderTabsSection();
    });

    let searchDebounced = null;
    $('tabSearch').addEventListener('input', function () {
      const value = $('tabSearch').value;
      if (searchDebounced) clearTimeout(searchDebounced);
      searchDebounced = setTimeout(function () {
        tabSearch = value.trim().toLowerCase();
        renderTabsSection();
      }, 160);
    });

    $('btnRefreshTabs').addEventListener('click', function () { loadEverything(); });

    $('tabList').addEventListener('click', onTabListClick);
    $('tabList').addEventListener('change', function (event) {
      const checkbox = event.target.closest('input[type="checkbox"]');
      if (!checkbox) return;
      const id = Number(checkbox.closest('.tab-row').dataset.id);
      if (checkbox.checked) selection.add(id); else selection.delete(id);
      updateBulkBar();
    });

    $('btnBulkClear').addEventListener('click', function () {
      selection.clear();
      renderTabsSection();
    });
    $('btnBulkDiscard').addEventListener('click', bulkDiscard);
    $('btnBulkClose').addEventListener('click', bulkClose);
    $('btnBulkProtect').addEventListener('click', function () { bulkProtect(true); });
    $('btnBulkUnprotect').addEventListener('click', function () { bulkProtect(false); });

    ['onCreated', 'onRemoved', 'onUpdated', 'onActivated', 'onMoved'].forEach(function (name) {
      chrome.tabs[name].addListener(scheduleTabsReload);
    });
  }

  const scheduleTabsReload = Util.throttle(function () {
    loadEverything();
  }, 700);

  async function loadTabs() {
    const [tabs, lastAccess] = await Promise.all([
      TP.Tabs.getAll(),
      Storage.getSession(Storage.SESSION_KEYS.LAST_ACCESS)
    ]);
    lastAccessMap = lastAccess || {};
    // Enrich with our tracked timestamps.
    tabsData = tabs.map(function (tab) {
      tab.lastAccessedAt = TP.Tabs.lastAccessedOf(tab, lastAccessMap);
      return tab;
    });
    // Drop selections for tabs that no longer exist.
    const live = {};
    tabsData.forEach(function (t) { live[t.id] = true; });
    Array.from(selection).forEach(function (id) { if (!live[id]) selection.delete(id); });
    renderTabsSection(); // all sections share one scrolling page now
  }

  function visibleTabs() {
    let list = tabsData.slice();
    if (tabFilter === 'active') list = list.filter(function (t) { return t.active; });
    else if (tabFilter === 'inactive') list = list.filter(function (t) { return !t.active && !t.discarded; });
    else if (tabFilter === 'discarded') list = list.filter(function (t) { return t.discarded; });
    else if (tabFilter === 'protected') {
      list = list.filter(function (t) { return TP.Protection.isTabProtected(t, protState).protected; });
    } else if (tabFilter === 'audible') list = list.filter(function (t) { return t.audible; });
    else if (tabFilter === 'pinned') list = list.filter(function (t) { return t.pinned; });

    if (tabSearch) {
      list = list.filter(function (t) {
        return (t.title || '').toLowerCase().indexOf(tabSearch) !== -1 ||
               (t.domain || '').toLowerCase().indexOf(tabSearch) !== -1 ||
               (t.url || '').toLowerCase().indexOf(tabSearch) !== -1;
      });
    }
    return sortTabs(list);
  }

  function sortTabs(list) {
    const now = Date.now();
    const idleOf = function (t) {
      return t.lastAccessedAt ? now - t.lastAccessedAt : Infinity;
    };
    if (tabSort === 'recent') {
      list.sort(function (a, b) { return idleOf(a) - idleOf(b); });
    } else if (tabSort === 'oldest') {
      list.sort(function (a, b) { return idleOf(b) - idleOf(a); });
    } else if (tabSort === 'alpha') {
      list.sort(function (a, b) { return (a.title || '').localeCompare(b.title || ''); });
    } else {
      list.sort(function (a, b) {
        return (a.windowId - b.windowId) || (a.index - b.index);
      });
    }
    return list;
  }

  function renderTabsSection() {
    const listEl = $('tabList');
    const list = visibleTabs();
    const fragment = document.createDocumentFragment();

    list.forEach(function (tab) {
      fragment.appendChild(buildTabRow(tab));
    });

    listEl.innerHTML = '';
    listEl.appendChild(fragment);
    $('tabsEmpty').hidden = list.length > 0;
    $('listMeta').textContent = tabsData.length + ' tabs total · ' + list.length + ' shown' +
      (selection.size ? ' · ' + selection.size + ' selected' : '') +
      (tabSort === 'memory' || tabSort === 'cpu' ? '' : '');
    $('listMeta').textContent += noteForSorting();
    updateBulkBar();
    renderIdleLabels();
  }

  function noteForSorting() {
    if (tabSort === 'recent' || tabSort === 'oldest') {
      return ' · per-tab memory/CPU sorting unavailable (Chrome API limitation)';
    }
    return '';
  }

  function buildTabRow(tab) {
    const row = el('div', 'tab-row tp-card');
    row.dataset.id = String(tab.id);
    row.dataset.discarded = String(!!tab.discarded);
    row.dataset.selected = String(selection.has(tab.id));

    const check = el('label', 'tab-check');
    const checkbox = el('input');
    checkbox.type = 'checkbox';
    checkbox.checked = selection.has(tab.id);
    checkbox.setAttribute('aria-label', 'Select tab');
    check.appendChild(checkbox);
    row.appendChild(check);

    row.appendChild(buildFavicon(tab));

    const main = el('div', 'tab-main');
    main.title = 'Open tab details';
    const titleRow = el('div', 'tab-title-row');
    titleRow.appendChild(el('span', 'tab-title', tab.title || tab.url || 'Untitled'));

    if (tab.active) titleRow.appendChild(el('span', 'tp-badge', 'Active')).dataset.kind = 'active';
    if (tab.pinned) { const b = el('span', 'tp-badge', 'Pin'); b.dataset.kind = 'pinned'; titleRow.appendChild(b); }
    if (tab.audible) { const b = el('span', 'tp-badge', 'Audio'); b.dataset.kind = 'audible'; titleRow.appendChild(b); }
    if (TP.Protection.isTabProtected(tab, protState).protected) {
      const b = el('span', 'tp-badge', 'Protected'); b.dataset.kind = 'protected'; titleRow.appendChild(b);
    }
    if (tab.discarded) { const b = el('span', 'tp-badge', 'Discarded'); b.dataset.kind = 'discarded'; titleRow.appendChild(b); }
    if (tab.status === 'loading') { const b = el('span', 'tp-badge', 'Loading'); b.dataset.kind = 'loading'; titleRow.appendChild(b); }

    const domainRow = el('div', 'tab-domain');
    domainRow.appendChild(el('span', null, tab.domain || shortenUrl(tab.url)));
    const idleSpan = el('span', 'tab-idle mono', '');
    idleSpan.dataset.role = 'idle';
    domainRow.appendChild(idleSpan);
    main.appendChild(titleRow);
    main.appendChild(domainRow);
    main.addEventListener('click', function () { openDetails(tab.id); });
    row.appendChild(main);

    const actions = el('div', 'tab-actions');
    actions.appendChild(actionBtn('focus', tab, 'Focus / open this tab'));
    actions.appendChild(actionBtn('reload', tab, 'Reload'));
    actions.appendChild(actionBtn('discard', tab, discardTitle(tab), !canDiscard(tab)));
    actions.appendChild(actionBtn('shield', tab, protectTitle(tab)));
    actions.appendChild(actionBtn('close', tab, 'Close tab'));
    row.appendChild(actions);

    return row;
  }

  function shortenUrl(url) {
    if (!url) return '—';
    return url.length > 42 ? url.slice(0, 39) + '…' : url;
  }

  function canDiscard(tab) {
    if (tab.active || tab.pinned || tab.discarded || tab.autoDiscardable === false) return false;
    if (String(tab.url || '').startsWith('chrome-extension://')) return false;
    // User site protection is ALWAYS enforced — even for explicit actions.
    // (Whitelisted domains remain discardable by explicit selection.)
    const prot = TP.Protection.isTabProtected(tab, protState);
    return !(prot.protected && prot.reason === 'user');
  }

  function discardTitle(tab) {
    if (tab.active) return 'Active tabs can never be discarded';
    if (tab.pinned) return 'Pinned tabs can never be discarded';
    if (tab.discarded) return 'Already discarded';
    if (tab.autoDiscardable === false) return 'Marked non-discardable by Chrome';
    const prot = TP.Protection.isTabProtected(tab, protState);
    if (prot.protected && prot.reason === 'user') {
      return 'Protected by you (always enforced) — remove protection first';
    }
    if (prot.protected) return 'Whitelisted domain — discard anyway (explicit action)';
    return 'Discard now (free its memory)';
  }

  function protectTitle(tab) {
    const prot = TP.Protection.isTabProtected(tab, protState);
    if (prot.protected && prot.reason === 'domain') {
      return 'Whitelisted domain — manage the list in Settings → Protection';
    }
    // v1.6.1 audit N2: the shield protects the whole SITE, not just this
    // tab — the tooltip must say so. v1.6.2 audit R3: the wording must
    // match what the code actually does for THIS tab — only http(s)
    // non-incognito protection survives restarts; incognito tabs are
    // session-only (never on disk) and hostless pages (file:, chrome:, …)
    // cover exactly this page, this session.
    const scope = TP.Protection.protectionScopeOf(tab, protState);
    if (scope.kind === 'page') {
      return prot.protected
        ? 'Remove protection for this page (until the browser closes)'
        : 'Protect this page only (until the browser closes — never saved to disk)';
    }
    if (!scope.durable) {
      return prot.protected
        ? 'Remove protection for this site (all its tabs — this session only, never saved to disk)'
        : 'Protect this site (all its tabs — incognito, this session only, never saved to disk)';
    }
    return prot.protected
      ? 'Remove protection for this site (all its tabs, survives restarts)'
      : 'Protect this site (all tabs, survives restarts)';
  }

  function actionBtn(icon, tab, title, disabled) {
    const btn = el('button', 'tp-icon-btn');
    btn.dataset.action = icon;
    btn.dataset.tabId = String(tab.id);
    btn.title = title;
    btn.setAttribute('aria-label', title);
    btn.innerHTML = ICONS[icon];
    if (disabled) btn.disabled = true;
    return btn;
  }

  function buildFavicon(tab) {
    const fav = el('span', 'tab-fav');
    const domain = tab.domain || '?';
    fav.style.background = domainColor(domain);
    // Favicons come from Chrome's OWN favicon store via the internal
    // _favicon endpoint — the extension never contacts any website
    // (tab.favIconUrl is deliberately NOT used: it points at the site's
    // server, which would make every list render a network request the
    // privacy policy forbids). Served from the browser's cache; falls
    // back to a letter tile when disabled or unavailable.
    const src = settings.privacy.favicons ? Util.faviconUrl(tab.url, 32) : '';
    if (src) {
      const img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.loading = 'lazy';
      img.onerror = function () { img.replaceWith(document.createTextNode(letterOf(domain))); };
      fav.appendChild(img);
    } else {
      fav.textContent = letterOf(domain);
    }
    return fav;
  }

  function letterOf(domain) {
    const ch = (domain || '?').replace(/^www\./, '')[0] || '?';
    return /[a-z0-9]/i.test(ch) ? ch.toUpperCase() : '?';
  }

  function domainColor(domain) {
    let hash = 0;
    for (let i = 0; i < domain.length; i++) hash = (hash * 31 + domain.charCodeAt(i)) | 0;
    const hues = [212, 152, 262, 187, 4, 330, 44];
    const h = hues[Math.abs(hash) % hues.length];
    return 'hsl(' + h + ', 32%, 34%)';
  }

  /* ------------------------------------------------------------------ *
   * Row / bulk actions
   * ------------------------------------------------------------------ */

  function findTab(id) {
    return tabsData.filter(function (t) { return t.id === Number(id); })[0] || null;
  }

  function onTabListClick(event) {
    const btn = event.target.closest('button[data-action]');
    if (!btn) return;
    const tab = findTab(btn.dataset.tabId);
    if (!tab) return;
    const action = btn.dataset.action;
    if (action === 'focus') {
      TP.Tabs.activate(tab).catch(function (err) { toast(err.message, 'error'); });
    } else if (action === 'reload') {
      TP.Tabs.reloadOne(tab.id).catch(function (err) { toast('Reload failed: ' + err.message, 'error'); })
        .then(function () { loadEverything(); });
    } else if (action === 'discard') {
      // Explicit single-tab discard — bypasses SOFT protections (whitelist,
      // idle rules) only. User site protection is always enforced, which
      // is why the button is disabled for protected tabs (canDiscard).
      requestOptimize('selection', [tab.id]).then(handleSelectionResponse);
    } else if (action === 'shield') {
      TP.Protection.toggleTab(tab)
        .catch(function (err) { toast(err.message, 'error'); })
        .then(loadEverything);
    } else if (action === 'close') {
      TP.Tabs.closeOne(tab.id).catch(function (err) { toast('Close failed: ' + err.message, 'error'); })
        .then(loadEverything);
    }
  }

  function handleSelectionResponse(response) {
    if (chrome.runtime.lastError || !response || !response.ok) {
      toast((response && response.error) || 'Discarding failed', 'error');
    } else {
      const summary = response.summary || {};
      const failed = (summary.failed || []).length;
      const protectedSkipped = (summary.skipped && summary.skipped['user-protected']) || 0;
      let text = summary.discardedCount
        ? summary.discardedCount + (summary.discardedCount === 1 ? ' tab discarded' : ' tabs discarded')
        : 'Nothing discarded';
      if (failed) text += ' · ' + failed + ' failed (Chrome restriction)';
      if (protectedSkipped) {
        text += ' · ' + protectedSkipped + ' protected tab' +
          (protectedSkipped === 1 ? ' skipped (unprotect first)' : 's skipped (unprotect first)');
      }
      toast(text, summary.discardedCount ? 'success' : '');
    }
    renderLastSummary();
    loadEverything();
  }

  function updateBulkBar() {
    const bar = $('bulkBar');
    bar.hidden = selection.size === 0;
    $('bulkCount').textContent = selection.size + ' selected';
    document.querySelectorAll('#tabList .tab-row').forEach(function (row) {
      row.dataset.selected = String(selection.has(Number(row.dataset.id)));
      const cb = row.querySelector('input[type="checkbox"]');
      if (cb) cb.checked = selection.has(Number(row.dataset.id));
    });
  }

  function bulkDiscard(event) {
    const btn = event.currentTarget;
    // Two-step confirmation, mirroring bulkClose: discarding drops
    // in-progress form state in the discarded tabs.
    if (btn.dataset.confirming !== '1') {
      btn.dataset.confirming = '1';
      btn.textContent = 'Confirm discard';
      setTimeout(function () { btn.textContent = 'Discard selected'; delete btn.dataset.confirming; }, 3000);
      return;
    }
    btn.textContent = 'Discard selected';
    delete btn.dataset.confirming;
    const ids = Array.from(selection);
    // Explicit selection = deliberate user action; the optimizer marks it
    // clearly in the summary ("selection") while Chrome hard rules apply
    // and user-protected tabs are always skipped (unprotect first).
    requestOptimize('selection', ids).then(function (response) {
      handleSelectionResponse(response);
      selection.clear();
    });
  }

  function bulkClose(event) {
    const btn = event.currentTarget;
    if (btn.dataset.confirming !== '1') {
      btn.dataset.confirming = '1';
      btn.textContent = 'Confirm close';
      setTimeout(function () { btn.textContent = 'Close selected'; delete btn.dataset.confirming; }, 3000);
      return;
    }
    btn.textContent = 'Close selected';
    delete btn.dataset.confirming;
    TP.Tabs.closeMany(Array.from(selection)).then(function (result) {
      const failed = result.failed.length;
      toast('Closed ' + result.ok.length + ' tabs' + (failed ? ' · ' + failed + ' failed' : ''),
        failed ? '' : 'success');
      selection.clear();
      loadEverything();
    });
  }

  function bulkProtect(protect) {
    const ids = Array.from(selection);
    // v1.6.2 audit R3: tell the truth about what bulk protect stores —
    // http(s) non-incognito tabs persist and survive restarts, incognito
    // and hostless-scheme tabs (file:, chrome:, …) are session-only.
    // v1.6.2 audit S4: the count is of distinct SITES, not tabs — five
    // tabs from one site are one durable site (deduplicated by site key;
    // the "www." variant shares the key).
    const durableSites = new Set();
    ids.forEach(function (id) {
      const tab = findTab(id);
      if (!tab) return;
      if (TP.Protection.protectionScopeOf(tab, protState).durable) {
        durableSites.add(TP.Protection.siteKeyOf(tab.url));
      }
    });
    const durable = durableSites.size;
    let chain = Promise.resolve();
    ids.forEach(function (id) {
      const tab = findTab(id);
      if (!tab) return;
      chain = chain.then(function () {
        return protect ? TP.Protection.protectTab(tab) : TP.Protection.unprotectTab(tab);
      });
    });
    chain.then(function () {
      let text = (protect ? 'Protected' : 'Unprotected') + ' ' + ids.length + ' tabs';
      if (protect && durable < ids.length) {
        text += durable
          ? ' — ' + durable + ' site' + (durable > 1 ? 's' : '') + ' persist, the rest this session only'
          : ' — this session only (never saved to disk)';
      }
      toast(text, 'success');
      loadEverything();
    }).catch(function (err) {
      toast((err && err.message) || 'Protection failed', 'error');
      loadEverything();
    });
  }

  /* Idle labels refresh without rebuilding the list */
  function renderIdleLabels() {
    const now = Date.now();
    document.querySelectorAll('#tabList .tab-row').forEach(function (row) {
      const tab = findTab(row.dataset.id);
      const span = row.querySelector('[data-role="idle"]');
      if (!tab || !span) return;
      if (tab.active) span.textContent = 'now';
      else if (tab.lastAccessedAt) {
        span.textContent = 'idle ' + Util.formatDuration(now - tab.lastAccessedAt);
      } else {
        span.textContent = 'idle ?';
      }
    });
  }

  /* ================================================================== *
   * Details dialog
   * ================================================================== */

  function wireDialog() {
    $('dialogClose').addEventListener('click', function () { $('tabDialog').close(); });
    $('dialogActions').addEventListener('click', function (event) {
      const btn = event.target.closest('button[data-action]');
      if (!btn || !currentDialogTab) return;
      dialogAction(btn.dataset.action, btn);
    });
  }

  /** Details-dialog text for the Protected row (v1.6.2 audit R3: it must
   *  describe what the protection ACTUALLY covers for this tab, not a
   *  blanket "survives restarts"). */
  function protectedRowText(tab, prot) {
    if (prot.reason === 'domain') return 'domain on whitelist';
    const scope = TP.Protection.protectionScopeOf(tab, protState);
    if (scope.kind === 'page') return 'you protected this page only — until the browser closes, never on disk';
    if (!scope.durable) return 'you protected this site — this session only (incognito), never on disk';
    return 'you protected this site — always enforced, survives restarts';
  }

  async function openDetails(tabId) {
    const tab = findTab(tabId);
    if (!tab) return;
    currentDialogTab = tab;
    const prot = TP.Protection.isTabProtected(tab, protState);

    $('dialogTitle').textContent = tab.title || 'Tab details';
    const body = $('dialogBody');
    body.innerHTML = '';

    const titleRow = el('div', 'd-title');
    titleRow.appendChild(buildFavicon(tab));
    titleRow.appendChild(el('strong', null, tab.title || 'Untitled'));
    body.appendChild(titleRow);

    body.appendChild(el('div', 'd-url mono', tab.url || ''));

    const dl = el('dl');
    const now = Date.now();
    const rows = [
      ['Status', tab.status === 'loading' ? 'Loading' : tab.discarded ? 'Discarded (unloaded from memory)' : 'Loaded'],
      ['Active', tab.active ? 'Yes — active in its window (never discardable)' : 'No'],
      ['Pinned', tab.pinned ? 'Yes — never discardable (Chrome rule)' : 'No'],
      ['Audible', tab.audible ? 'Yes — playing audio' : 'No'],
      ['Discardable by Chrome', tab.autoDiscardable === false ? 'No (autoDiscardable: false)' : 'Yes'],
      ['Protected', prot.protected ? 'Yes (' + protectedRowText(tab, prot) + ')' : 'No'],
      ['Domain', tab.domain || '—'],
      ['Window / index', (tab.windowId || '—') + ' / ' + (tab.index || '—')],
      ['Last accessed', tab.lastAccessedAt ? new Date(tab.lastAccessedAt).toLocaleString() : 'unknown'],
      ['Idle for', tab.active ? 'active now' : tab.lastAccessedAt ? Util.formatDuration(now - tab.lastAccessedAt, { long: true }) : 'unknown']
    ];
    rows.forEach(function (pair) {
      const wrap = el('div');
      wrap.appendChild(el('dt', null, pair[0]));
      wrap.appendChild(el('dd', null, pair[1]));
      dl.appendChild(wrap);
    });
    body.appendChild(dl);

    body.appendChild(el('p', 'd-note',
      'Per-tab CPU, memory and network activity are NOT shown because Chrome does not expose ' +
      'per-tab process metrics to extensions. Use Chrome\u2019s Task Manager (Shift+Esc) for per-process values. ' +
      'Discarding this tab will free its renderer memory; the measured system delta is reported in the optimization summary.'));

    const actions = $('dialogActions');
    actions.innerHTML = '';
    actions.appendChild(dialogBtn('focus', 'Focus / open', 'primary'));
    actions.appendChild(dialogBtn('reload', 'Reload', ''));
    actions.appendChild(dialogBtn('discard', 'Discard', canDiscard(tab) ? '' : 'danger'));
    actions.appendChild(dialogBtn(prot.protected ? 'unprotect' : 'protect', prot.protected ? 'Unprotect' : 'Protect', ''));
    actions.appendChild(dialogBtn('whitelist', 'Protect domain', ''));
    actions.appendChild(dialogBtn('closeTab', 'Close tab', 'danger'));

    const dialog = $('tabDialog');
    if (!dialog.open) dialog.showModal();
  }

  function dialogBtn(action, label, kind) {
    const btn = el('button', 'tp-btn' + (kind === 'primary' ? ' tp-btn-primary' : kind === 'danger' ? ' tp-btn-danger' : ''));
    btn.dataset.action = action;
    btn.textContent = label;
    return btn;
  }

  function dialogAction(action, btn) {
    const tab = currentDialogTab;
    if (!tab) return;
    if (action === 'focus') {
      TP.Tabs.activate(tab).catch(function (err) { toast(err.message, 'error'); });
      $('tabDialog').close();
    } else if (action === 'reload') {
      TP.Tabs.reloadOne(tab.id).catch(function (err) { toast('Reload failed: ' + err.message, 'error'); });
      $('tabDialog').close();
      loadEverything();
    } else if (action === 'discard') {
      $('tabDialog').close();
      requestOptimize('selection', [tab.id]).then(handleSelectionResponse);
    } else if (action === 'protect') {
      // v1.6.2 audit R3: the toast must match what protection actually
      // covers for THIS tab (persistent site / session-only site / this
      // page only) — the wording comes from the same helper as the shield.
      const scope = TP.Protection.protectionScopeOf(tab, protState);
      TP.Protection.protectTab(tab).then(function () {
        let text;
        if (scope.kind === 'page') {
          text = 'Protected — this page only (until the browser closes)';
        } else if (!scope.durable) {
          text = 'Protected — every tab of ' + (tab.domain || 'this site') +
            ' (this session only, never saved to disk)';
        } else {
          text = 'Protected — every tab of ' + (tab.domain || 'this site') + ' (survives restarts)';
        }
        toast(text, 'success');
        $('tabDialog').close();
        loadEverything();
      }).catch(function (err) { toast(err.message, 'error'); });
    } else if (action === 'unprotect') {
      TP.Protection.unprotectTab(tab).then(function () { toast('Protection removed'); $('tabDialog').close(); loadEverything(); });
    } else if (action === 'whitelist') {
      // v1.6.2 audit R2: an intranet host whose name looks like a public
      // suffix ("http://dev/") needs an explicit confirm step, like the
      // Settings form: the first click shows the warning and relabels the
      // button, the second click (within 6 s) confirms.
      // v1.6.2 audit S1: the success handler (toast, close dialog, reload)
      // is attached to BOTH calls — a normal domain succeeds on the FIRST
      // click and must give feedback; the confirm state is entered only
      // when the rejection carries err.confirmable.
      const confirmed = btn.dataset.confirming === '1';
      btn.textContent = 'Protect domain';
      delete btn.dataset.confirming;
      TP.Protection.protectTabDomain(tab, { confirmed: confirmed })
        .then(function () {
          toast('All tabs from ' + tab.domain + ' are now protected', 'success');
          $('tabDialog').close();
          loadEverything();
        })
        .catch(function (err) {
          if (!confirmed && err && err.confirmable) {
            btn.dataset.confirming = '1';
            btn.textContent = 'Confirm: add anyway';
            setTimeout(function () {
              btn.textContent = 'Protect domain';
              delete btn.dataset.confirming;
            }, 6000);
            toast(err.message, '');
          } else {
            toast(err.message, 'error');
          }
        });
    } else if (action === 'closeTab') {
      if (btn.dataset.confirming !== '1') {
        btn.dataset.confirming = '1';
        btn.textContent = 'Confirm close';
        setTimeout(function () { btn.textContent = 'Close tab'; delete btn.dataset.confirming; }, 3000);
        return;
      }
      TP.Tabs.closeOne(tab.id).catch(function (err) { toast('Close failed: ' + err.message, 'error'); });
      $('tabDialog').close();
      loadEverything();
    }
  }

  /* ================================================================== *
   * System info / external changes
   * ================================================================== */

  function renderSystemInfo() {
    const ua = navigator.userAgent;
    let browser = 'Chrome';
    const match = ua.match(/Chrome\/(\d+(\.\d+)?)/);
    if (match) browser = 'Chrome ' + match[1];
    $('sysBrowser').textContent = browser;
    const platform = (navigator.userAgentData && navigator.userAgentData.platform) ||
                     navigator.platform || '—';
    $('sysPlatform').textContent = platform;
    const manifest = chrome.runtime.getManifest();
    $('sysVersion').textContent = 'TabPilot ' + (manifest.version_name || manifest.version);
    Storage.getLocalUsage().then(function (bytes) {
      $('sysStorage').textContent = bytes == null ? 'not reported' : '≈ ' + Util.formatBytes(bytes) + ' (settings, whitelist, history)';
    });
    renderSelfOverhead();
  }

  function renderSelfOverhead() {
    const target = $('sysSelf');
    if (performance.memory) {
      target.textContent = '≈ ' + Util.formatBytes(performance.memory.usedJSHeapSize) +
        ' JS heap (this page, rough estimate) — idle service worker: none';
    } else {
      target.textContent = 'JS heap not reported in this context';
    }
  }

  function watchExternalChanges() {
    Storage.onLocalChanged([Storage.KEYS.SETTINGS], async function () {
      settings = await Storage.getSettings();
      startMonitor();
      syncOptPanel();
      chartsDirty = true;
      renderTabsSection(); // sections are always visible on the scrolling page
      renderTabChips();
    });
    Storage.onLocalChanged([Storage.KEYS.LAST_OPTIMIZATION, Storage.KEYS.LAST_SAVINGS], function () {
      renderLastSummary();
    });
    Storage.onLocalChanged([Storage.KEYS.PROTECTED_TABS, Storage.KEYS.WHITELIST], function () {
      loadEverything();
    });
    Storage.onLocalChanged([Storage.KEYS.HISTORY], function () {
      // History cleared from settings or flushed by another page.
      TP.History.load().then(function () { chartsDirty = true; });
    });
    // settings-ui and this page share settings; keep both in sync live.
    Storage.onLocalChanged([Storage.KEYS.SETTINGS], function () { syncOptPanel(); });
  }

  function saveSettings(partial) {
    return Storage.setSettings(partial).catch(function (err) {
      console.warn('[TabPilot] settings save failed:', err && err.message);
    });
  }

  /* ================================================================== *
   * Toast
   * ================================================================== */

  let toastTimer = null;

  function toast(message, kind) {
    const element = $('toast');
    element.textContent = message;
    element.dataset.kind = kind || '';
    element.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { element.classList.remove('show'); }, 4200);
  }
})();
