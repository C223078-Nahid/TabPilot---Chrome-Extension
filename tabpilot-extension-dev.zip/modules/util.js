/**
 * TabPilot — util.js
 * Shared helpers: safe Chrome API bridge (callback-style, works on every
 * supported Chrome version), formatters, domain utilities and DOM helpers.
 *
 * Context-agnostic: loaded by the MV3 service worker (importScripts) and by
 * extension pages (<script>). Uses the global TabPilot namespace.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});

  /* ------------------------------------------------------------------ *
   * Chrome API bridge
   * ------------------------------------------------------------------ */

  /**
   * Call any chrome.* API method and get a Promise back.
   * Uses the classic callback signature so it works on every Chrome version
   * regardless of when (or whether) that API gained promise support.
   * chrome.runtime.lastError is converted into a rejected Promise, so every
   * failure surfaces as a catchable exception instead of a silent log.
   *
   * @param {object} api      the chrome API namespace, e.g. chrome.tabs
   * @param {string} method   method name, e.g. 'query'
   * @param {...any} args     arguments that precede the callback
   */
  function callApi(api, method) {
    const args = Array.prototype.slice.call(arguments, 2);
    return new Promise(function (resolve, reject) {
      try {
        if (!api || typeof api[method] !== 'function') {
          reject(new Error('API unavailable: ' + methodName(api, method)));
          return;
        }
        let settled = false;
        const callback = function () {
          if (settled) return;
          settled = true;
          // lastError must be read synchronously inside the callback.
          const lastError =
            (root.chrome && root.chrome.runtime && root.chrome.runtime.lastError) || null;
          if (lastError) {
            reject(new Error(lastError.message || 'Unknown chrome API error'));
          } else {
            resolve(arguments.length <= 1 ? arguments[0] : Array.prototype.slice.call(arguments));
          }
        };
        api[method].apply(api, args.concat([callback]));
      } catch (err) {
        reject(err);
      }
    });
  }

  function methodName(api, method) {
    for (const key in root.chrome) {
      if (root.chrome[key] && root.chrome[key] === api) return 'chrome.' + key + '.' + method;
    }
    return 'chrome.?' + '.' + method;
  }

  /**
   * True when a rejected error looks like a permission/policy denial
   * (e.g. enterprise policy blocking chrome.system.* APIs).
   */
  function looksLikePermissionError(err) {
    const msg = String((err && err.message) || '').toLowerCase();
    return msg.indexOf('permission') !== -1 || msg.indexOf('denied') !== -1 ||
           msg.indexOf('blocked') !== -1 || msg.indexOf('not allowed') !== -1;
  }

  /* ------------------------------------------------------------------ *
   * Formatting
   * ------------------------------------------------------------------ */

  const UNITS = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];

  /** 1234567 -> "1.18 MB" (binary units, matching OS tools). */
  function formatBytes(bytes, decimals) {
    if (typeof bytes !== 'number' || !isFinite(bytes) || bytes < 0) return '—';
    if (bytes === 0) return '0 B';
    const i = Math.min(UNITS.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
    const value = bytes / Math.pow(1024, i);
    const d = typeof decimals === 'number' ? decimals : (i === 0 ? 0 : value >= 100 ? 0 : value >= 10 ? 1 : 2);
    return value.toFixed(d) + ' ' + UNITS[i];
  }

  /** Bytes per second -> "1.2 MB/s". */
  function formatThroughput(bytesPerSec) {
    if (typeof bytesPerSec !== 'number' || !isFinite(bytesPerSec) || bytesPerSec < 0) return '—';
    return formatBytes(bytesPerSec) + '/s';
  }

  function formatPercent(value, decimals) {
    if (typeof value !== 'number' || !isFinite(value)) return '—';
    return value.toFixed(typeof decimals === 'number' ? decimals : 1) + '%';
  }

  /** 3720000 -> "62m" / 6545000 -> "1h 49m" / 15000 -> "15s". */
  function formatDuration(ms, opts) {
    const long = !!(opts && opts.long);
    if (typeof ms !== 'number' || !isFinite(ms) || ms < 0) return '—';
    const sec = Math.floor(ms / 1000);
    if (sec < 5) return long ? 'just now' : 'now';
    const min = Math.floor(sec / 60);
    if (min < 1) return sec + 's';
    if (min < 60) return min + 'm' + (long && sec % 60 ? ' ' + (sec % 60) + 's' : '');
    const h = Math.floor(min / 60);
    const rest = min % 60;
    return h + 'h' + (rest ? ' ' + rest + 'm' : '');
  }

  /** "23 minutes" style for summaries. */
  function formatMinutesLong(minutes) {
    if (minutes === 60) return '60 minutes';
    return minutes + ' minutes';
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* ------------------------------------------------------------------ *
   * URLs / domains
   * ------------------------------------------------------------------ */

  /** Safe hostname extraction; returns '' for invalid/schemeless URLs. */
  function hostnameOf(url) {
    if (typeof url !== 'string' || !url) return '';
    try {
      const parsed = new URL(url);
      return (parsed.hostname || '').toLowerCase();
    } catch (err) {
      return '';
    }
  }

  /**
   * Normalize user input into a bare hostname.
   * Accepts "https://Mail.Example.com/path/", "www.example.com", "*.example.com".
   * Single-label intranet hosts ("localhost", "nas") are allowed — they are
   * legitimate deploy targets that must be protectable (bare public suffixes
   * are refused separately, see isLikelyPublicSuffix).
   * Returns '' when the input cannot be interpreted as a domain.
   */
  function normalizeDomain(input) {
    let raw = String(input || '').trim().toLowerCase();
    if (!raw) return '';
    if (raw.indexOf('://') === -1) raw = 'http://' + raw;
    try {
      const parsed = new URL(raw);
      let host = (parsed.hostname || '').toLowerCase();
      if (host.startsWith('www.')) host = host.slice(4);
      // Sanity check: non-empty and only domain characters. No dot required —
      // single-label hosts (localhost, intranet names) are valid.
      if (!host) return '';
      if (!/^[a-z0-9*.-]+$/.test(host)) return '';
      return host;
    } catch (err) {
      return '';
    }
  }

  /**
   * True when `hostname` matches a whitelist `pattern`.
   * "example.com" matches example.com and any subdomain (mail.example.com).
   * "*.example.com" matches subdomains only. "www." prefixes are ignored.
   */
  function matchesDomain(hostname, pattern) {
    const h = String(hostname || '').toLowerCase().replace(/\.$/, '');
    let p = String(pattern || '').toLowerCase().replace(/\.$/, '');
    if (!h || !p) return false;
    if (p.startsWith('www.')) p = p.slice(4);
    if (p.startsWith('*.')) {
      const bare = p.slice(2);
      return h !== bare && h.endsWith('.' + bare);
    }
    return h === p || h.endsWith('.' + p);
  }

  /* ------------------------------------------------------------------ *
   * Public-suffix guard (v1.6.1 audit N4, reworked in v1.6.2 audit R2,
   * pattern check added in v1.6.3 for v1.6.2 audit S3)
   * ------------------------------------------------------------------ */

  /**
   * Single labels that name an entire public suffix ("com", "io", "dev", …).
   * Whitelisting one would protect — i.e. switch off the optimizer for —
   * most of the web. These entries get a WARNING + explicit confirm step
   * (they may still be real single-label intranet hosts — audit R2), never
   * a silent acceptance — EXCEPT the five classic generic TLDs in
   * BARE_GENERIC_TLDS below, which are refused even after confirmation
   * (v1.6.2 audit S3). Intentionally a short, curated list of REAL
   * public suffixes people actually type by accident; shipping the full
   * Public Suffix List (~15k entries) inside an offline extension is not
   * worth it. Reserved-for-testing names that are NOT public suffixes
   * ("test", "local", "example", "invalid") are deliberately absent:
   * they are exactly what intranets use and must not warn (audit R2).
   */
  const PUBLIC_SUFFIXES = Object.freeze([
    // gTLDs people typo as bare entries
    'com', 'net', 'org', 'info', 'biz', 'name', 'pro', 'xyz', 'online',
    'site', 'store', 'tech', 'app', 'dev', 'ai', 'io', 'me', 'tv', 'cc',
    'ws', 'cloud', 'live', 'wiki', 'news', 'blog', 'shop', 'email',
    // classic infrastructure
    'edu', 'gov', 'mil', 'int', 'arpa', 'onion',
    // common ccTLDs
    'us', 'uk', 'ca', 'de', 'fr', 'es', 'it', 'nl', 'be', 'ch', 'at',
    'se', 'no', 'fi', 'dk', 'pl', 'pt', 'cz', 'gr', 'ru', 'ua', 'tr',
    'il', 'ae', 'sa', 'in', 'cn', 'jp', 'kr', 'tw', 'hk', 'sg', 'my',
    'th', 'vn', 'id', 'ph', 'au', 'nz', 'br', 'mx', 'ar', 'cl', 'co',
    'za', 'ng', 'ke', 'eg'
  ]);

  /**
   * The classic generic TLDs (v1.6.2 audit S3): unlike other suffix-like
   * single labels ("dev", "wiki", "app" — plausible intranet host names
   * that get a warning + confirm step), NOBODY runs a real intranet host
   * called "com" or "org". Confirming one through the "Add anyway" step
   * would protect every *.com / *.org site, so these five are REFUSED
   * outright — even with { confirmed: true }.
   */
  const BARE_GENERIC_TLDS = Object.freeze(['com', 'org', 'net', 'edu', 'gov']);

  /**
   * Common SECOND-LEVEL public suffixes ("co.uk", "com.au", …) — the
   * multi-label equivalents of the list above (v1.6.2 audit R2: the old
   * guard only checked single labels, so "co.uk" was silently accepted
   * and protected most of a country's commercial web). A multi-label
   * entry equal to one of these can never be an intranet host, so it is
   * REFUSED outright (no confirm step, unlike single labels). Same
   * deliberate curation: the common ones people actually type, not the
   * full Public Suffix List. Entries this list misses are caught by the
   * generic pattern check looksLikeSecondLevelSuffix() (v1.6.2 audit S3:
   * com.bd, net.bd, com.np, ac.in, gov.in and co.at were all silently
   * accepted because no hand-curated list can cover ~250 country-code
   * second levels).
   */
  const SECOND_LEVEL_SUFFIXES = Object.freeze([
    // United Kingdom
    'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'me.uk', 'net.uk', 'ltd.uk', 'plc.uk',
    // Australia / New Zealand
    'com.au', 'net.au', 'org.au', 'edu.au', 'gov.au', 'co.nz', 'net.nz', 'org.nz',
    // Japan / Korea
    'co.jp', 'or.jp', 'ne.jp', 'ac.jp', 'go.jp', 'co.kr', 'or.kr',
    // Latin America
    'com.br', 'com.mx', 'com.ar', 'com.pe', 'com.co', 'com.uy', 'com.ec', 'com.ve',
    // Asia
    'co.in', 'net.in', 'org.in', 'com.tr', 'com.cn', 'com.tw', 'com.hk',
    'com.sg', 'com.my', 'co.id', 'com.ph', 'com.vn', 'com.pk',
    // Others
    'co.za', 'co.il', 'com.ua', 'co.ke', 'com.ng', 'com.eg', 'co.th', 'com.sa'
  ]);

  /**
   * Prefix labels that real second-level public suffixes are built from:
   * "co.uk", "com.bd", "ac.in", "gov.br", "or.jp", … are all of the form
   * <prefix>.<two-letter country code>. Since every two-letter TLD IS a
   * country code, a two-label entry of this shape is a public suffix in
   * every country that registers one — and can never be a real intranet
   * host — so it is refused by PATTERN instead of by list membership
   * (v1.6.2 audit S3). A real host under such a suffix
   * ("example.com.bd") has three labels and never matches.
   */
  const SECOND_LEVEL_PREFIXES = Object.freeze([
    'co', 'com', 'org', 'net', 'gov', 'edu', 'ac', 'or', 'ne', 'go', 'ltd', 'plc'
  ]);

  /** True when `label` (no dot) names an entire public suffix (audit N4). */
  function isLikelyPublicSuffix(label) {
    return PUBLIC_SUFFIXES.indexOf(String(label || '').toLowerCase()) !== -1;
  }

  /**
   * True when `label` (no dot) is one of the five classic generic TLDs
   * (com, org, net, edu, gov) — refused even after confirmation, because
   * nobody has a real intranet host with one of these names (v1.6.2
   * audit S3).
   */
  function isBareGenericTld(label) {
    return BARE_GENERIC_TLDS.indexOf(String(label || '').toLowerCase()) !== -1;
  }

  /**
   * True when `entry` (one or more dots) is exactly a known second-level
   * public suffix like "co.uk" — not a host under it (audit R2). The
   * caller passes the entry without its "*." prefix and trailing dot.
   */
  function isKnownSecondLevelSuffix(entry) {
    return SECOND_LEVEL_SUFFIXES.indexOf(String(entry || '').toLowerCase()) !== -1;
  }

  /**
   * True when `entry` (no "*." prefix, no trailing dot) has the SHAPE of
   * a second-level public suffix: exactly two labels, the first a generic
   * prefix from SECOND_LEVEL_PREFIXES (co, com, org, net, gov, edu, ac,
   * or, ne, go, ltd, plc) and the second exactly two letters — i.e. a
   * country code (v1.6.2 audit S3: com.bd, net.bd, com.np, ac.in, gov.in
   * and co.at slipped through the curated list). Catches the ~250
   * country-code second levels no hand-curated list can cover; a real
   * host under such a suffix ("example.com.bd") has three labels and
   * never matches. Case-insensitive.
   */
  function looksLikeSecondLevelSuffix(entry) {
    const e = String(entry || '').toLowerCase().replace(/\.$/, '');
    const labels = e.split('.');
    if (labels.length !== 2) return false;
    if (!/^[a-z]{2}$/.test(labels[1])) return false; // two-letter country code
    return SECOND_LEVEL_PREFIXES.indexOf(labels[0]) !== -1;
  }

  /* ------------------------------------------------------------------ *
   * Hashing (session-only keys, not security)
   * ------------------------------------------------------------------ */

  /**
   * Fast, stable, NON-cryptographic string hash (FNV-1a, 32-bit, hex).
   * Used only to build compact RAM-backed session keys for very long
   * URLs (data:, blob:) that must never be stored verbatim — see
   * Protection.sessionKeyOf (v1.6.1 audit N1). Never use for security.
   */
  function shortHash(str) {
    const s = String(str);
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return ('0000000' + h.toString(16)).slice(-8);
  }

  /* ------------------------------------------------------------------ *
   * Favicons
   * ------------------------------------------------------------------ */

  /**
   * Source URL for a tab's favicon, served by Chrome's OWN favicon store
   * via the internal _favicon endpoint — never by the website.
   *
   * Why not tab.favIconUrl: that URL points at the site's server, so
   * rendering it makes the extension fetch an arbitrary URL chosen by the
   * page (a privacy leak the extension cannot vouch for). The _favicon
   * endpoint is part of this extension (chrome-extension://<id>/_favicon/),
   * is served from the browser's local favicon database/cache, and adds no
   * host access. It requires the "favicon" permission (Chrome 92+; the
   * extension requires Chrome 116+). Whether Chrome's install dialog
   * mentions the permission can change between Chrome versions — verify
   * the current behavior on chrome://extensions / the Web Store listing
   * (v1.6.1 audit N7: no "never warned" claim without a live check).
   *
   * Returns '' when the endpoint cannot be used (permission stripped from
   * the manifest, missing URL, unavailable runtime) — callers then fall
   * back to letter tiles.
   */
  function faviconUrl(pageUrl, size) {
    if (!pageUrl || typeof pageUrl !== 'string') return '';
    if (!(root.chrome && chrome.runtime && typeof chrome.runtime.getManifest === 'function')) return '';
    const perms = (chrome.runtime.getManifest().permissions || []);
    if (perms.indexOf('favicon') === -1) return '';
    const px = (size === 16 || size === 32 || size === 64) ? size : 32;
    // Relative URL resolves to chrome-extension://<this-id>/_favicon/
    return '/_favicon/?pageUrl=' + encodeURIComponent(pageUrl) + '&size=' + px;
  }

  /* ------------------------------------------------------------------ *
   * Time / timers
   * ------------------------------------------------------------------ */

  /** Trailing-edge throttle: coalesces bursts into one trailing call. */
  function throttle(fn, waitMs) {
    let pending = null;
    let timer = null;
    let lastRun = 0;
    function invoke() {
      lastRun = Date.now();
      timer = null;
      const args = pending;
      pending = null;
      if (args) fn.apply(null, args);
    }
    return function () {
      pending = Array.prototype.slice.call(arguments);
      if (timer) return;
      const elapsed = Date.now() - lastRun;
      timer = setTimeout(invoke, Math.max(0, waitMs - elapsed));
    };
  }

  function debounce(fn, waitMs) {
    let timer = null;
    return function () {
      const args = Array.prototype.slice.call(arguments);
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () { timer = null; fn.apply(null, args); }, waitMs);
    };
  }

  /* ------------------------------------------------------------------ *
   * Export
   * ------------------------------------------------------------------ */

  TP.Util = {
    callApi: callApi,
    looksLikePermissionError: looksLikePermissionError,
    formatBytes: formatBytes,
    formatThroughput: formatThroughput,
    formatPercent: formatPercent,
    formatDuration: formatDuration,
    formatMinutesLong: formatMinutesLong,
    clamp: clamp,
    escapeHtml: escapeHtml,
    hostnameOf: hostnameOf,
    normalizeDomain: normalizeDomain,
    matchesDomain: matchesDomain,
    isLikelyPublicSuffix: isLikelyPublicSuffix,
    isBareGenericTld: isBareGenericTld,
    isKnownSecondLevelSuffix: isKnownSecondLevelSuffix,
    looksLikeSecondLevelSuffix: looksLikeSecondLevelSuffix,
    shortHash: shortHash,
    faviconUrl: faviconUrl,
    throttle: throttle,
    debounce: debounce
  };
})(typeof self !== 'undefined' ? self : globalThis);
