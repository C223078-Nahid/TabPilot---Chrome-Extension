/**
 * TabPilot — cpu-monitor.js
 * CPU metrics via chrome.system.cpu.getInfo().
 *
 * What is ACTUALLY available (measured) on every supported platform:
 *  - CPU model name, architecture, core count, feature flags.
 *  - Per-core cumulative usage counters {user, kernel, idle, total} — two
 *    samples are differenced to compute REAL system CPU utilization.
 *  - On ChromeOS only: per-process data (processData[]) with cumulative CPU
 *    seconds and network byte counters for Browser/Renderer/GPU processes.
 *    On Windows/macOS/Linux Chrome returns an empty processData list; the
 *    monitor reports that state honestly instead of estimating.
 *
 * What is NOT available and is never faked:
 *  - per-tab CPU (extensions cannot map tabs to processes),
 *  - "Chrome process CPU" on non-ChromeOS platforms.
 *
 * The first sample cannot compute utilization yet (needs a delta), so it
 * reports status "warming" — the UI shows "Measuring…" instead of 0%.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  // Cache of counters that only change between browser restarts.
  let staticInfo = null;

  // Heuristic state for processData.cpu unit detection (see below).
  let processCpuUnit = null;

  const PER_TAB_NOTE = {
    status: 'unavailable',
    reason: 'Chrome does not map tabs to processes for extensions, so per-tab ' +
            'CPU cannot be measured. See the Chrome Task Manager (Shift+Esc).'
  };

  function sample() {
    if (!(root.chrome && chrome.system && chrome.system.cpu)) {
      return Promise.resolve(unavailable('chrome.system.cpu is not available ' +
        '(missing permission or unsupported platform).'));
    }
    return Util.callApi(chrome.system.cpu, 'getInfo').then(function (info) {
      if (!info) return unavailable('chrome.system.cpu.getInfo() returned no data.');
      staticInfo = {
        modelName: info.modelName || '',
        archName: info.archName || '',
        cores: info.numOfProcessors || null,
        features: Array.isArray(info.features) ? info.features.slice() : []
      };

      const snapshot = {
        status: 'warming', // until two samples exist
        source: 'chrome.system.cpu.getInfo()',
        static: staticInfo,
        utilization: null,      // { system: pct, perCore: [pct] } — real deltas
        perCore: null,
        processes: readProcesses(info, staticInfo.cores),
        perTabCpu: PER_TAB_NOTE
      };

      snapshot.processes = readProcesses(info, staticInfo.cores);
      const counters = readCounters(info);
      if (counters) {
        snapshot._counters = counters; // kept for the next delta
        if (counters.warmed) {
          snapshot.utilization = counters.utilization;
          snapshot.perCore = counters.utilization.perCore;
          snapshot.status = 'available';
        }
      }
      return snapshot;
    }).catch(function (err) {
      return unavailable(
        Util.looksLikePermissionError(err)
          ? 'CPU API blocked — permission required. ' + err.message
          : 'CPU API error: ' + err.message,
        Util.looksLikePermissionError(err) ? 'permission' : 'error'
      );
    });
  }

  /** Static info without a full sample (used for fast popup paint). */
  function getStaticInfo() {
    return staticInfo ? JSON.parse(JSON.stringify(staticInfo)) : null;
  }

  /* ------------------------------------------------------------------ *
   * Per-core utilization from cumulative counters
   * ------------------------------------------------------------------ */

  /**
   * chrome.system.cpu gives cumulative per-core counters since boot.
   * Utilization = busyDelta / totalDelta between two calls.
   * @returns object with { warmed, utilization } plus the raw counters.
   */
  function readCounters(info) {
    const cores = (info.processors || []).map(function (proc) {
      const u = proc && proc.usage ? proc.usage : null;
      return u ? { user: u.user || 0, kernel: u.kernel || 0, idle: u.idle || 0, total: u.total || 0 } : null;
    });
    if (!cores.length || cores.some(function (c) { return !c; })) return null;

    const warmed = readCounters._prev != null;
    const utilization = { system: null, perCore: [] };

    if (warmed) {
      const prev = readCounters._prev;
      let busySum = 0, totalSum = 0;
      utilization.perCore = cores.map(function (c, i) {
        const p = prev[i] || { user: 0, kernel: 0, idle: 0, total: 0 };
        const dTotal = c.total - p.total;
        if (dTotal <= 0) return 0; // counter reset (reboot/suspend)
        const dBusy = (c.user - p.user) + (c.kernel - p.kernel);
        busySum += dBusy;
        totalSum += dTotal;
        return clampPct((dBusy / dTotal) * 100);
      });
      utilization.system = totalSum > 0 ? clampPct((busySum / totalSum) * 100) : 0;
    }
    readCounters._prev = cores;
    return { warmed: warmed, utilization: utilization, counters: cores };
  }

  function clampPct(v) {
    return Math.max(0, Math.min(100, isFinite(v) ? v : 0));
  }

  /* ------------------------------------------------------------------ *
   * Per-process data (ChromeOS only)
   * ------------------------------------------------------------------ */

  /**
   * processData entries carry cumulative CPU "seconds" and network counters.
   *  - Availability is detected dynamically: ChromeOS returns entries,
   *    other platforms return [] — we mark the feature unavailable there.
   *  - Some Chrome builds have reported the CPU figure in non-second units;
   *    normalizeProcessCpuUnit() sanity-checks the delta and adapts, so the
   *    value shown is always plausible or suppressed (never fabricated).
   */
  function readProcesses(info, coreCount) {
    const processes = Array.isArray(info.processData) ? info.processData : [];
    if (!processes.length) {
      return {
        available: false,
        reason: 'Per-process CPU/network data is only exposed on ChromeOS ' +
                 '(chrome.system.cpu.processData is empty on this platform).',
        browserCpuPct: null,
        rendererCpuPct: null,
        gpuCpuPct: null,
        renderers: null,
        network: null,
        raw: []
      };
    }

    const byType = { Browser: [], Renderer: [], Gpu: [], Extension: [] };
    const netTotals = { bytesRead: 0, bytesWritten: 0 };
    processes.forEach(function (proc) {
      if (proc && byType[proc.type]) byType[proc.type].push(proc);
      if (proc && proc.network) {
        netTotals.bytesRead += Number(proc.network.bytesRead || 0);
        netTotals.bytesWritten += Number(proc.network.bytesWritten || 0);
      }
    });

    const prev = readProcesses._prev || {};
    const out = {
      available: true,
      reason: '',
      renderers: byType.Renderer.length,
      network: netTotals,
      raw: processes.map(function (p) { return { id: p.id, type: p.type, cpu: p.cpu || 0 }; })
    };

    ['browser', 'renderer', 'gpu'].forEach(function (key) {
      const type = key === 'browser' ? 'Browser' : key === 'renderer' ? 'Renderer' : 'Gpu';
      const sum = byType[type].reduce(function (acc, p) { return acc + (Number(p.cpu) || 0); }, 0);
      const prevSum = prev[type] != null ? prev[type] : null;
      const pct = processCpuToPct(sum, prevSum, coreCount);
      out[key + 'CpuPct'] = pct;
      prev[type] = sum;
    });
    // Extension renderers are aggregated with renderers for the UI row.
    if (out.rendererCpuPct != null && byType.Extension.length) {
      const extSum = byType.Extension.reduce(function (acc, p) { return acc + (Number(p.cpu) || 0); }, 0);
      const prevExt = prev.Extension != null ? prev.Extension : null;
      const extPct = processCpuToPct(extSum, prevExt, coreCount);
      if (extPct != null) out.rendererCpuPct = clampPct(out.rendererCpuPct + extPct);
      prev.Extension = extSum;
    }
    readProcesses._prev = prev;
    return out;
  }

  /**
   * Convert a cumulative process CPU figure into "% of total system capacity".
   * The documented unit is seconds; a sanity check detects mis-reporting and
   * switches the interpretation once, or suppresses the metric.
   */
  function processCpuToPct(sum, prevSum, coreCount) {
    if (prevSum == null) return null;
    if (sum < prevSum) return null; // process restarted -> counter reset
    const delta = sum - prevSum;
    const dtMs = processCpuToPct._dt || 1000;
    const cores = coreCount || 1;
    let cpuSeconds = delta;
    if (processCpuUnit === 'ms') cpuSeconds = delta / 1000;
    const usedCores = cpuSeconds / (dtMs / 1000);
    if (usedCores > cores * 1.5) {
      if (processCpuUnit == null) {
        // First sample looks like milliseconds — re-evaluate next round.
        processCpuUnit = 'ms';
        return null;
      }
      return null; // still implausible: suppress rather than fabricate
    }
    if (processCpuUnit == null) processCpuUnit = 'sec';
    return clampPct((usedCores / cores) * 100);
  }

  /** Called by resource-monitor with the real sampling interval. */
  function setSampleInterval(ms) {
    processCpuToPct._dt = ms;
  }

  function unavailable(reason, status) {
    return {
      status: status || 'unavailable',
      reason: reason,
      static: staticInfo,
      utilization: null,
      perCore: null,
      processes: null,
      perTabCpu: PER_TAB_NOTE
    };
  }

  TP.Cpu = {
    id: 'cpu',
    sample: sample,
    getStaticInfo: getStaticInfo,
    setSampleInterval: setSampleInterval
  };
})(typeof self !== 'undefined' ? self : globalThis);
