/**
 * TabPilot — optimizer.js
 * The smart tab optimization engine. One code path for every trigger:
 *  - 'manual'    : the "Optimize Browser" button (popup / dashboard)
 *  - 'auto'      : the periodic alarm in the service worker
 *  - 'selection' : an explicit "Discard selected tabs" action from the
 *                  dashboard tab manager (soft protections are bypassed
 *                  because the user chose the tabs; hard Chrome API rules —
 *                  active/pinned tabs — are never bypassed).
 *
 * Policy (from Settings):
 *  - mode            manual | balanced | aggressive | protected
 *  - idleMinutes     tab idle threshold (balanced & manual)
 *                    aggressive uses half of it (min 2 min)
 *  - preserveRecentTabs  hard floor of 5 minutes for automatic runs
 *  - minPreservedTabs    never discard down past N live (non-discarded) tabs
 *
 * Memory savings honesty (requirement §22: never claim unsupported numbers):
 *  - No per-tab memory exists in stable Chrome APIs, so savings are NEVER
 *    estimated per tab. Instead the engine measures the SYSTEM memory delta
 *    (chrome.system.memory availableCapacity) before and ~30-60 s after the
 *    batch, and reports it clearly as an approximate measured delta.
 *  - On ChromeOS it also records the renderer-process count before/after —
 *    a direct, observable effect of discarding.
 *
 * Service worker safety: the post-discard measurement is finished by a
 * one-shot chrome.alarms alarm, so it survives both page closure and
 * service worker termination (all pending state lives in storage.session).
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;
  const Storage = TP.Storage;

  const VERIFY_ALARM = 'tp:verify-savings';
  const VERIFY_DELAY_MIN = 0.5; // 30 s where supported; Chrome clamps to 1 min.

  /* ------------------------------------------------------------------ *
   * Pure policy helpers (unit tested in scripts/unit-tests.js)
   * ------------------------------------------------------------------ */

  function effectiveIdleMinutes(mode, idleMinutes) {
    if (mode === 'aggressive') return Math.max(2, Math.ceil(idleMinutes / 2));
    return idleMinutes;
  }

  /**
   * How many tabs may be discarded so that at least `minPreserved` live tabs
   * remain. Pure, testable.
   */
  function maxDiscardable(liveTabCount, candidatesCount, minPreserved) {
    const allowed = liveTabCount - Math.max(0, minPreserved);
    return Math.max(0, Math.min(candidatesCount, allowed));
  }

  const SKIP_REASONS = [
    'active', 'pinned', 'audible', 'already-discarded', 'user-protected',
    'whitelisted', 'recent', 'loading', 'extension-page', 'non-discardable',
    'unknown-age', 'min-preserve'
  ];

  function emptySkips() {
    const out = {};
    SKIP_REASONS.forEach(function (r) { out[r] = 0; });
    return out;
  }

  /* ------------------------------------------------------------------ *
   * Main entry
   * ------------------------------------------------------------------ */

  /**
   * @param {object} opts
   *   trigger      'manual' | 'auto' | 'selection'
   *   tabIds       array of tab ids (selection mode only)
   * @returns {Promise<object>} optimization summary (also persisted as the
   *                            "last optimization" shown in the UI).
   */
  function run(opts) {
    const trigger = (opts && opts.trigger) || 'manual';
    const selection = trigger === 'selection' ? new Set((opts && opts.tabIds) || []) : null;

    return Storage.getSettings().then(function (settings) {
      // An auto trigger may fire from a stale alarm after the user disabled
      // automation — quietly no-op instead of discarding anything.
      if (trigger === 'auto' && !isAutomationActive(settings)) {
        return { status: 'automation-disabled', time: Date.now() };
      }

      const mode = settings.optimization.mode;
      const idleMin = trigger === 'selection'
        ? 0
        : effectiveIdleMinutes(mode, settings.optimization.idleMinutes);

      return Promise.all([
        TP.Tabs.getAll(),
        Storage.getSession(Storage.SESSION_KEYS.LAST_ACCESS)
      ]).then(function (results) {
        const tabs = results[0] || [];
        let lastAccess = results[1] || {};
        lastAccess = pruneLastAccess(lastAccess, tabs);

        return TP.Protection.getState().then(function (protectionState) {
          return execute(settings, {
            trigger: trigger,
            selection: selection,
            idleMin: idleMin,
            tabs: tabs,
            lastAccess: lastAccess,
            protectionState: protectionState
          });
        });
      });
    });
  }

  function isAutomationActive(settings) {
    const o = settings.optimization;
    return o.autoDiscard &&
      (o.mode === 'balanced' || o.mode === 'aggressive');
  }

  /* ------------------------------------------------------------------ *
   * Core execution
   * ------------------------------------------------------------------ */

  function execute(settings, env) {
    const now = Date.now();
    const activeIds = TP.Tabs.activeTabIds(env.tabs);
    const skipped = emptySkips();
    let candidates = [];

    env.tabs.forEach(function (tab) {
      if (env.selection && !env.selection.has(tab.id)) return;

      const verdict = TP.Tabs.classifyTab(tab, {
        now: now,
        lastAccess: env.lastAccess,
        activeIds: activeIds,
        settings: settings,
        protectionState: env.protectionState,
        idleMinutes: env.idleMin,
        respectRules: env.trigger !== 'selection'
      });

      if (verdict.eligible) {
        candidates.push({ tab: tab, idleMs: verdict.idleMs != null ? verdict.idleMs : Infinity });
      } else if (skipped[verdict.reason] !== undefined) {
        skipped[verdict.reason]++;
      }
    });

    // Oldest-idle first: maximum resource recovery per discarded tab.
    candidates.sort(function (a, b) { return b.idleMs - a.idleMs; });

    // Preserve a minimum number of live tabs (never applied to selections).
    let trimmedForPreserve = 0;
    if (env.trigger !== 'selection') {
      const live = env.tabs.filter(function (t) { return !t.discarded; }).length;
      const allow = maxDiscardable(live, candidates.length, settings.optimization.minPreservedTabs);
      if (candidates.length > allow) {
        trimmedForPreserve = candidates.length - allow;
        candidates = candidates.slice(0, allow); // drop the least-idle ones
        skipped['min-preserve'] = trimmedForPreserve;
      }
    }

    // Pre-batch measurements (best effort, all optional):
    const measures = {
      beforeAvail: memoryAvailable(),
      renderersBefore: rendererCount()
    };

    return measures.beforeAvail.then(function (beforeAvail) {
      return measures.renderersBefore.then(function (renderersBefore) {
        return discardAll(candidates).then(function (results) {
          // NOTE: no immediate post-discard probing. Renderer teardown is
          // asynchronous; the accurate "after" values (renderer count,
          // memory delta) are captured by the deferred verification alarm,
          // which also avoids hammering system APIs in the same tick as the
          // discard (a race in some Chrome builds).
          const summary = {
            status: 'ok',
            time: now,
            trigger: env.trigger,
            mode: settings.optimization.mode,
            idleMinutes: env.idleMin,
            scanned: env.tabs.length,
            attempted: results.ok.length,
            discardedCount: results.ok.length,
            failed: results.failed,
            skipped: skipped,
            // PRIVACY (audit #6): only the tab id + bare domain are
            // persisted — never a title, never a full URL. Tabs that were
            // open in incognito windows are omitted entirely.
            tabsDiscarded: results.ok.map(function (id) {
              const tab = env.tabs.filter(function (t) { return t.id === id; })[0];
              if (!tab || tab.incognito) return null;
              return { id: id, domain: tab ? (tab.domain || Util.hostnameOf(tab.url)) : '' };
            }).filter(Boolean),
            renderers: { before: renderersBefore, after: null },
            // v1.6.1 audit N7: named "memoryFreedBytes" through v1.6.0 —
            // renamed to match the neutral wording (it is an observed
            // system delta, not an attribution). Readers fall back to the
            // legacy field for summaries stored by older versions.
            memoryDeltaBytes: null,
            memoryMeasured: false,
            memoryNote: 'Measuring the system memory delta…'
          };

          // Persist as the "last operation" when something was actually
          // discarded, or when this was a user-visible action (manual /
          // selection). A periodic auto check that discarded nothing does
          // NOT clobber the previous summary — it would spam the UI with
          // "0 discarded" every minute and race the deferred measurement.
          const persist = (results.ok.length > 0 || env.trigger !== 'auto')
            ? Storage.set(Storage.KEYS.LAST_OPTIMIZATION, summary)
            : Promise.resolve();
          const schedule = results.ok.length
            ? scheduleVerification({ availBytes: beforeAvail, ts: now })
            : Promise.resolve();
          return Promise.all([persist, schedule]).then(function () { return summary; });
        });
      });
    });
  }

  function discardAll(candidates) {
    const ids = candidates.map(function (c) { return c.tab.id; });
    return TP.Tabs.discardMany(ids);
  }

  /* ------------------------------------------------------------------ *
   * Optional observability helpers
   * ------------------------------------------------------------------ */

  /** Currently available system memory in bytes, or null. */
  function memoryAvailable() {
    if (!(root.chrome && chrome.system && chrome.system.memory)) {
      return Promise.resolve(null);
    }
    return Util.callApi(chrome.system.memory, 'getInfo')
      .then(function (info) {
        return info && typeof info.availableCapacity === 'number' ? info.availableCapacity : null;
      })
      .catch(function () { return null; });
  }

  /**
   * Renderer process count (ChromeOS only — per-process data is not exposed
   * on other platforms). Falls back to null anywhere else.
   */
  function rendererCount() {
    if (!(root.chrome && chrome.system && chrome.system.cpu)) {
      return Promise.resolve(null);
    }
    return Util.callApi(chrome.system.cpu, 'getInfo')
      .then(function (info) {
        const list = (info && Array.isArray(info.processData)) ? info.processData : [];
        if (!list.length) return null;
        return list.filter(function (p) { return p.type === 'Renderer' || p.type === 'Extension'; }).length;
      })
      .catch(function () { return null; });
  }

  /* ------------------------------------------------------------------ *
   * Deferred memory-delta measurement (survives SW restarts)
   *
   * QUEUE, not a single slot (audit #7): a second run inside a minute no
   * longer overwrites the first measurement — pending verifications stack
   * in an array (RAM-backed) and one one-shot alarm drains them one by
   * one. Completed records go into LAST_SAVINGS (latest, merged into the
   * matching summary) AND a capped SAVINGS_HISTORY (last 3).
   *
   * HONEST FRAMING (audit #7): the system-memory delta is reported NEUTRALLY
   * in both directions. A positive delta says "available memory rose by ≈X
   * (system-wide; other processes contribute)" — never "TabPilot freed X".
   * A non-positive delta is reported as INCONCLUSIVE with the actual change,
   * never as "no net change".
   * ------------------------------------------------------------------ */

  const VERIFY_QUEUE_MAX = 5;
  const SAVINGS_HISTORY_MAX = 3;

  /** Read the pending-verification queue; tolerates the v1.5 single-object
   *  slot (mid-flight upgrade) by wrapping it into an array. */
  function readVerifyQueue() {
    return Storage.getSession(Storage.SESSION_KEYS.PENDING_VERIFY).then(function (raw) {
      if (Array.isArray(raw)) return raw;
      if (raw && typeof raw === 'object' && raw.ts) return [raw];
      return [];
    });
  }

  function writeVerifyQueue(queue) {
    return Storage.setSession(Storage.SESSION_KEYS.PENDING_VERIFY, queue);
  }

  /** Queue a verification unless one with the same ts is already pending. */
  function scheduleVerification(before) {
    return readVerifyQueue().then(function (queue) {
      const duplicate = queue.some(function (p) { return p.ts === before.ts; });
      if (!duplicate) {
        queue.push({ availBytes: before.availBytes, ts: before.ts, scheduledAt: Date.now() });
        if (queue.length > VERIFY_QUEUE_MAX) queue = queue.slice(queue.length - VERIFY_QUEUE_MAX);
      }
      return writeVerifyQueue(queue).then(function () {
        // Create the alarm ONLY when it is not already armed — recreating
        // it would reset the countdown of a verification already waiting.
        return Util.callApi(chrome.alarms, 'get', VERIFY_ALARM).then(function (existing) {
          if (!existing) {
            return Util.callApi(chrome.alarms, 'create', VERIFY_ALARM, { delayInMinutes: VERIFY_DELAY_MIN });
          }
          return null;
        }).catch(function () {
          // alarms.get unavailable (unit-test stub) — arm anyway.
          return Util.callApi(chrome.alarms, 'create', VERIFY_ALARM, { delayInMinutes: VERIFY_DELAY_MIN });
        });
      });
    });
  }

  /** Called by the service worker when the verification alarm fires. */
  function completePendingMeasurement() {
    return readVerifyQueue().then(function (queue) {
      if (!queue.length) {
        return Util.callApi(chrome.alarms, 'clear', VERIFY_ALARM).catch(function () {}).then(function () { return null; });
      }
      const pending = queue.shift();
      return Promise.all([memoryAvailable(), rendererCount(), writeVerifyQueue(queue)]).then(function (results) {
        const afterAvail = results[0];
        const renderersAfter = results[1];

        const record = {
          ts: pending.ts,
          completedAt: Date.now(),
          // v1.6.1 audit N7: "freedBytes" through v1.6.0 — the value is an
          // observed system-memory delta, not a per-tab "freed" number;
          // the field name now says so. Readers fall back to the legacy name.
          memoryDeltaBytes: null,
          measured: false,
          note: 'The system memory delta could not be measured on this platform.',
          renderersAfter: renderersAfter
        };
        if (afterAvail != null && pending.availBytes != null) {
          const delta = afterAvail - pending.availBytes;
          if (delta > 0) {
            // Neutral framing: system-wide observation, no attribution.
            record.memoryDeltaBytes = delta;
            record.measured = true;
            record.note = 'System available memory rose by ≈ ' + Util.formatBytes(delta) +
              ' between measurements (system-wide delta — approximate; other processes' +
              ' contribute; not attributable to TabPilot alone).';
          } else {
            record.measured = true;
            record.note = 'Inconclusive: system available memory ' +
              (delta === 0 ? 'was unchanged' : 'DECREASED by ≈ ' + Util.formatBytes(-delta)) +
              ' between measurements — the discards did not produce a measurable' +
              ' system-memory increase (OS and other-app activity can mask it).';
          }
        }

        return Storage.set(Storage.KEYS.LAST_SAVINGS, record).then(function () {
          // Keep the last few measurements so consecutive runs (routine in
          // auto mode) never overwrite history (audit #7).
          return Storage.get(Storage.KEYS.SAVINGS_HISTORY).then(function (history) {
            const list = Array.isArray(history) ? history : [];
            list.push(record);
            const trimmed = list.slice(list.length - SAVINGS_HISTORY_MAX);
            return Storage.set(Storage.KEYS.SAVINGS_HISTORY, trimmed);
          });
        }).then(function () {
          // Re-arm when more verifications are queued.
          if (queue.length) {
            return Util.callApi(chrome.alarms, 'create', VERIFY_ALARM, { delayInMinutes: VERIFY_DELAY_MIN }).catch(function () {});
          }
          return Util.callApi(chrome.alarms, 'clear', VERIFY_ALARM).catch(function () {});
        }).then(function () {
          // Best-effort immediate merge when the summary still matches.
          return Storage.get(Storage.KEYS.LAST_OPTIMIZATION).then(function (summary) {
            if (summary && summary.time === pending.ts) {
              summary.memoryDeltaBytes = record.memoryDeltaBytes;
              summary.memoryMeasured = record.measured;
              summary.memoryNote = record.note;
              if (record.renderersAfter != null && summary.renderers) summary.renderers.after = record.renderersAfter;
              return Storage.set(Storage.KEYS.LAST_OPTIMIZATION, summary).then(function () { return summary; });
            }
            return summary;
          });
        }).then(function () { return record; });
      });
    });
  }

  /**
   * Drop lastAccess entries for tabs that no longer exist — LOCAL view
   * only. The copy is never written back: an async write of a stale map
   * raced tab-switch handlers and made live tabs look older than they are
   * (audit #5). Deletion happens synchronously in the onRemoved handler
   * instead (serialized in the service worker).
   */
  function pruneLastAccess(map, tabs) {
    const live = {};
    tabs.forEach(function (t) { live[t.id] = true; });
    const out = {};
    Object.keys(map).forEach(function (id) {
      if (live[id]) out[id] = map[id];
    });
    return out;
  }

  TP.Optimizer = {
    run: run,
    effectiveIdleMinutes: effectiveIdleMinutes,
    maxDiscardable: maxDiscardable,
    isAutomationActive: isAutomationActive,
    completePendingMeasurement: completePendingMeasurement,
    VERIFY_ALARM: VERIFY_ALARM,
    SKIP_REASONS: SKIP_REASONS
  };
})(typeof self !== 'undefined' ? self : globalThis);
