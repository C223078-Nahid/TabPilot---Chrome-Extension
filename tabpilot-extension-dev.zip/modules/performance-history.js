/**
 * TabPilot — performance-history.js
 * Lightweight performance history for the graphs (CPU / RAM / disk / network).
 *
 * Lightweightness rules:
 *  - In-memory at full sampling resolution while a page is open.
 *  - Persisted to chrome.storage.local only every 10 s (throttled), at 2 s
 *    resolution (downsampled) — bounded, predictable writes.
 *  - Hard caps: points older than the retention window (5/15/30 min) are
 *    dropped on every push; storage never grows beyond a few hundred KB.
 *  - "Clear performance history" (Settings) wipes both buffers at once.
 *
 * Only real measurements are charted: CPU% (system), RAM% (system),
 * disk% (primary volume) and network throughput (ChromeOS only). The GPU
 * utilization is never charted because no API provides it.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;
  const Storage = TP.Storage;

  const SERIES = ['cpu', 'mem', 'disk', 'netDown', 'netUp'];
  const FLUSH_EVERY_MS = 10000;
  const STORE_RESOLUTION_MS = 2000;

  const state = {
    buffer: { cpu: [], mem: [], disk: [], netDown: [], netUp: [] },
    retentionMs: 30 * 60000,
    maxPoints: 1800,
    lastFlush: 0,
    dirty: false
  };

  function init(settings) {
    state.retentionMs = settings.monitoring.retentionMinutes * 60000;
    // Safety cap on in-memory buffer size regardless of sampling interval.
    state.maxPoints = Math.max(300, Math.ceil(state.retentionMs / 500));
    return load();
  }

  /** Restore persisted points so reopening the dashboard shows continuity. */
  function load() {
    return Storage.get(Storage.KEYS.HISTORY).then(function (stored) {
      if (stored && stored.series) {
        const cutoff = Date.now() - state.retentionMs;
        SERIES.forEach(function (key) {
          const pts = Array.isArray(stored.series[key]) ? stored.series[key] : [];
          state.buffer[key] = pts.filter(function (p) { return p && p[0] >= cutoff; });
        });
      }
      return get();
    });
  }

  /** Record one monitor snapshot (called on every sampling tick). */
  function push(snapshot) {
    const t = snapshot.t;
    const cpu = snapshot.cpu && snapshot.cpu.utilization ? snapshot.cpu.utilization.system : null;
    const mem = snapshot.memory && snapshot.memory.usedPct != null ? snapshot.memory.usedPct : null;
    const disk = snapshot.disk && snapshot.disk.primary && snapshot.disk.primary.usedPct != null
      ? snapshot.disk.primary.usedPct : null;
    const net = snapshot.network && snapshot.network.browser ? snapshot.network.browser : null;

    addPoint('cpu', t, cpu);
    addPoint('mem', t, mem);
    addPoint('disk', t, disk);
    addPoint('netDown', t, net ? net.downBps : null);
    addPoint('netUp', t, net ? net.upBps : null);

    const cutoff = t - state.retentionMs;
    SERIES.forEach(function (key) { trimOld(state.buffer[key], cutoff); });
    state.dirty = true;
  }

  function addPoint(key, t, value) {
    if (typeof value !== 'number' || !isFinite(value)) return; // no gaps filled with fake data
    const arr = state.buffer[key];
    arr.push([t, value]);
    if (arr.length > state.maxPoints) arr.splice(0, arr.length - state.maxPoints);
  }

  function trimOld(points, cutoff) {
    // Points are pushed chronologically -> binary-search-free front scan.
    let i = 0;
    while (i < points.length && points[i][0] < cutoff) i++;
    if (i > 0) points.splice(0, i);
  }

  /**
   * Downsample to STORE_RESOLUTION_MS by averaging — pure, unit tested.
   * `maxPoints` caps the OUTPUT length (the newest points are kept); it is
   * NOT a per-bucket sample cap — that misuse (v1.5) let buckets silently
   * split again once more than maxPoints samples landed in one window.
   */
  function downsample(points, resolutionMs, maxPoints) {
    if (!points.length) return [];
    let out = [];
    let bucket = null;
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      if (bucket && p[0] - bucket.t0 < resolutionMs) {
        bucket.sum += p[1];
        bucket.n += 1;
        bucket.t = p[0];
      } else {
        if (bucket) out.push([bucket.t, bucket.sum / bucket.n]);
        bucket = { t0: p[0], t: p[0], sum: p[1], n: 1 };
      }
    }
    if (bucket) out.push([bucket.t, bucket.sum / bucket.n]);
    if (maxPoints && out.length > maxPoints) out = out.slice(out.length - maxPoints);
    return out;
  }

  /** Persist current buffers; throttled, merges with other pages' data. */
  function flush(force) {
    const now = Date.now();
    if (!force && !state.dirty) return Promise.resolve();
    if (!force && (now - state.lastFlush) < FLUSH_EVERY_MS) return Promise.resolve();

    return Storage.get(Storage.KEYS.HISTORY).then(function (stored) {
      const series = {};
      const cutoff = now - state.retentionMs;
      SERIES.forEach(function (key) {
        const storedPts = (stored && stored.series && Array.isArray(stored.series[key]))
          ? stored.series[key] : [];
        const mine = state.buffer[key];
        // Replace stored points that my buffer covers (my data is newer);
        // keep stored points from a time window my buffer doesn't cover.
        const earliest = mine.length ? mine[0][0] : Infinity;
        const merged = storedPts.filter(function (p) { return p && p[0] < earliest && p[0] >= cutoff; })
          .concat(mine);
        series[key] = downsample(merged, STORE_RESOLUTION_MS, state.maxPoints);
      });
      state.lastFlush = now;
      state.dirty = false;
      const payload = { v: 1, updated: now, series: series };
      return Storage.set(Storage.KEYS.HISTORY, payload).catch(function (err) {
        // Quota pressure: degrade gracefully by clearing history once.
        console.warn('[TabPilot] history flush failed:', err && err.message);
        return Storage.remove(Storage.KEYS.HISTORY);
      });
    });
  }

  function get() {
    const out = {};
    SERIES.forEach(function (key) { out[key] = state.buffer[key].slice(); });
    return out;
  }

  /** Points of one series within the last rangeMs, oldest first. */
  function getRange(key, rangeMs) {
    const cutoff = Date.now() - rangeMs;
    return state.buffer[key].filter(function (p) { return p[0] >= cutoff; });
  }

  function clear() {
    SERIES.forEach(function (key) { state.buffer[key] = []; });
    state.dirty = false;
    return Storage.remove(Storage.KEYS.HISTORY);
  }

  TP.History = {
    SERIES: SERIES,
    init: init,
    load: load,
    push: push,
    flush: flush,
    get: get,
    getRange: getRange,
    clear: clear,
    downsample: downsample,
    trimOld: trimOld
  };
})(typeof self !== 'undefined' ? self : globalThis);
