/**
 * TabPilot — tab-memory.js
 * Per-tab memory usage via the chrome.processes API.
 *
 * Two tiers, never mixed up in the UI:
 *
 *  1. MEASURED — wherever Chrome actually exposes chrome.processes to this
 *     extension. Verified facts (probe: scripts/probe-processes*.js, Nov
 *     2026, Chromium 143 CfT + chrome/common/extensions/api/_permission_features.json):
 *       - The "processes" permission is granted to ALL extensions only on
 *         Chrome's Dev channel; on beta/stable it is limited to a small
 *         Google allowlist (Hangouts & friends). ChromeOS stable is NOT
 *         exempt. Shipped TabPilot therefore does not declare the
 *         permission; the dev-channel build does (see README).
 *       - Where the API IS present: getProcessIdForTab() and
 *         getProcessInfo(pids, false) (the skeleton: tasks/shared mapping)
 *         respond normally, but getProcessInfo(pids, true) — the
 *         documented includeMemory path — NEVER CALLS BACK on desktop
 *         builds (hangs; Chromium bug). The onUpdatedWithMemory EVENT,
 *         however, delivers real privateMemory bytes per process reliably
 *         within ~1–2 s of subscribing. Measured memory therefore flows
 *         through the event stream: watchProcessMemory().
 *       - Entries carry `pid` + `sharedWith` so the UI can label renderers
 *         shared by several tabs instead of double-counting.
 *
 *  2. ESTIMATED (fallback for stable Chrome). estimateTabMemory() derives
 *     a clearly-labeled heuristic from signals extensions CAN see:
 *     active/inactive, discarded, audible, and the site's domain class.
 *     Everything it produces is rendered amber with an "est." marker — an
 *     order-of-magnitude anchor, NOT a measurement. (Chrome's own hover
 *     "Memory usage: …" tooltip and Task Manager use internal APIs
 *     extensions cannot access; Shift+Esc shows real values.)
 *
 *  - Discarded tabs have no renderer process at all — their memory is
 *    genuinely freed, which the UI can state as fact on BOTH tiers.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});

  const UNSUPPORTED_REASON =
    'chrome.processes (real per-tab memory) is exposed to third-party extensions only on ' +
    'Chrome\u2019s Dev channel — stable/beta restrict it to a Google allowlist, and ' +
    'system.memory provides system-wide RAM only. TabPilot therefore shows clearly-labeled ' +
    'estimates here. Real values: Chrome\u2019s Task Manager (Shift+Esc).';

  /** True only when this build actually exposes the processes API. */
  function isSupported() {
    return !!(root.chrome && chrome.processes &&
      typeof chrome.processes.getProcessIdForTab === 'function' &&
      (typeof chrome.processes.getProcessInfo === 'function' ||
        typeof chrome.processes.onUpdatedWithMemory === 'object'));
  }

  function getProcessIdForTab(tabId) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.processes.getProcessIdForTab(tabId, function (processId) {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(processId);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  /**
   * Skeleton process info: type + tasks (which tabs live in which process).
   * NOTE: the second getProcessInfo argument is the includeMemory flag —
   * with `true` the call NEVER calls back on desktop builds (Chromium
   * bug, verified by probe), so we always ask for the skeleton and take
   * memory from onUpdatedWithMemory events instead.
   */
  function getProcessInfo(pids) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.processes.getProcessInfo(pids, false, function (infoMap) {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(infoMap);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  /**
   * Subscribe to live process memory via the onUpdatedWithMemory event.
   * Fires every ~1–2 s with real privateMemory bytes per process id.
   *
   * @param {Function} onSample  called with { [pid]: { bytes, cpuPct } }
   * @returns {Function} stop() — always safe to call
   */
  function watchProcessMemory(onSample) {
    if (!isSupported() || !chrome.processes.onUpdatedWithMemory ||
      typeof chrome.processes.onUpdatedWithMemory.addListener !== 'function') {
      return function () {};
    }
    const listener = function (processMap) {
      const sample = {};
      Object.keys(processMap || {}).forEach(function (pidKey) {
        const proc = processMap[pidKey] || {};
        if (typeof proc.privateMemory === 'number' && proc.privateMemory > 0) {
          sample[Number(pidKey)] = {
            bytes: proc.privateMemory,
            cpuPct: typeof proc.cpu === 'number' ? proc.cpu : null
          };
        }
      });
      if (Object.keys(sample).length) {
        try { onSample(sample); } catch (e) { /* listener error must not kill the event */ }
      }
    };
    try {
      chrome.processes.onUpdatedWithMemory.addListener(listener);
    } catch (e) {
      return function () {};
    }
    return function () {
      try { chrome.processes.onUpdatedWithMemory.removeListener(listener); } catch (e) { /* ignore */ }
    };
  }

  /**
   * Resolve the tab -> renderer-process skeleton.
   *
   * @param {Array} tabs  enriched tab objects (TP.Tabs.getAll() output)
   * @returns {Promise} resolving to one of:
   *   { supported: true,  map: { [tabId]: { pid, bytes: null, cpuPct: null, sharedWith } },
   *     memoryAvailable: false, estimates }
   *     // measured bytes arrive LATER via watchProcessMemory(); entries
   *     // start as null and the caller merges events into them.
   *   { supported: false, memoryAvailable: false, reason, estimates }
   *
   * `estimates` (heuristic fallback map) is always attached so callers
   * have something honest to show until/unless measurements arrive.
   *
   * Discarded tabs never appear in the map (no renderer process).
   */
  function getTabMemoryMap(tabs) {
    if (!isSupported()) {
      return Promise.resolve({
        supported: false,
        memoryAvailable: false,
        reason: UNSUPPORTED_REASON,
        estimates: buildEstimateMap(tabs)
      });
    }

    const live = (tabs || []).filter(function (tab) { return !tab.discarded; });
    const map = {};

    return Promise.all(live.map(function (tab) {
      return getProcessIdForTab(tab.id).then(function (pid) {
        return { tabId: tab.id, pid: pid };
      }, function () {
        return { tabId: tab.id, pid: null }; // closing / not yet spawned
      });
    })).then(function (pairs) {
      const seen = {};
      const pids = [];
      pairs.forEach(function (pair) {
        if (pair.pid != null && !seen[pair.pid]) {
          seen[pair.pid] = true;
          pids.push(pair.pid);
        }
      });

      // Seed entries (bytes null until events deliver).
      const perProcess = {};
      pairs.forEach(function (pair) {
        if (pair.pid == null) return;
        (perProcess[pair.pid] = perProcess[pair.pid] || []).push(pair.tabId);
      });

      const seed = function () {
        Object.keys(perProcess).forEach(function (pidKey) {
          const tabIds = perProcess[pidKey];
          tabIds.forEach(function (tabId) {
            map[tabId] = {
              pid: Number(pidKey),
              bytes: null,           // filled by watchProcessMemory events
              cpuPct: null,
              sharedWith: tabIds.length
            };
          });
        });
        return {
          supported: true,
          memoryAvailable: false,   // true once the caller merges real events
          map: map,
          estimates: buildEstimateMap(tabs)
        };
      };

      if (!pids.length) {
        return seed();
      }

      return getProcessInfo(pids).then(function (infoMap) {
        // tabIds we mapped to each process id (from getProcessIdForTab) …
        const robust = {};
        pairs.forEach(function (pair) {
          if (pair.pid == null) return;
          (robust[pair.pid] = robust[pair.pid] || []).push(pair.tabId);
        });
        // …plus any tabs the process reports itself (robust superset).
        Object.keys(infoMap || {}).forEach(function (pidKey) {
          const proc = infoMap[pidKey] || {};
          ((proc.tasks || [])).forEach(function (task) {
            if (!task || task.tabId == null) return;
            const list = robust[Number(pidKey)] = robust[Number(pidKey)] || [];
            if (list.indexOf(task.tabId) === -1) list.push(task.tabId);
          });
        });
        Object.keys(robust).forEach(function (pidKey) {
          perProcess[pidKey] = robust[pidKey];
        });
        return seed();
      }).catch(function () {
        // Skeleton query failed — the pid map from getProcessIdForTab is
        // still valid; seed from it rather than failing.
        return seed();
      });
    }).catch(function (err) {
      // Supported platform but resolution failed — estimates, never fake data.
      return {
        supported: true,
        memoryAvailable: false,
        map: {},
        partial: true,
        reason: 'chrome.processes resolution failed: ' + ((err && err.message) || 'unknown error'),
        estimates: buildEstimateMap(tabs)
      };
    });
  }

  /* ------------------------------------------------------------------ *
   * Heuristic estimator (fallback — ALWAYS labeled "estimated")
   * ------------------------------------------------------------------ */

  const MB = 1024 * 1024;

  /* Anchor points for typical renderer footprints (order-of-magnitude,
   * deliberately coarse). Calibrated against real privateMemory observed
   * through chrome.processes.onUpdatedWithMemory where available (a bare
   * static page's renderer measures ~20–25 MB private; real-world pages
   * run heavier, the focused tab heavier still, heavyweight web apps
   * much more). Every number derived from these anchors is marked "est."
   * in the UI — a heuristic, not a measurement. */
  const ESTIMATE_MODEL = {
    baseActiveMb: 95,   // focused/active renderer baseline
    baseIdleMb: 40,     // backgrounded renderer baseline
    audioMb: 18,        // audio pipeline kept alive
    internalMb: 14,     // chrome://, extension, devtools pages
    minMb: 8,           // never suggest a renderer below this
    heavyMult: 2.2,     // heavyweight web apps (docs, figma, slack…)
    mediumMult: 1.55    // media-rich feeds (social, shopping, video-ish)
  };

  const HEAVY_APP_DOMAINS = [
    'docs.google.com', 'sheets.google.com', 'slides.google.com', 'drive.google.com',
    'figma.com', 'canva.com', 'slack.com', 'discord.com', 'teams.microsoft.com',
    'notion.so', 'spotify.com', 'youtube.com', 'twitch.tv', 'netflix.com',
    'maps.google.com', 'meet.google.com', 'zoom.us', 'chatgpt.com',
    'claude.ai', 'gmail.com', 'outlook.live.com', 'medium.com'
  ];

  const MEDIUM_DOMAINS = [
    'facebook.com', 'instagram.com', 'x.com', 'twitter.com', 'reddit.com',
    'linkedin.com', 'tiktok.com', 'pinterest.com', 'web.whatsapp.com',
    'web.telegram.org', 'amazon.com', 'ebay.com', 'aliexpress.com', 'etsy.com',
    'wikipedia.org', 'github.com'
  ];

  /** 'heavy' | 'medium' | 'standard' for a bare hostname. */
  function domainClass(domain) {
    const host = String(domain || '').toLowerCase().replace(/^www\./, '');
    if (!host) return 'standard';
    const hit = function (list) {
      return list.some(function (d) { return host === d || host.endsWith('.' + d); });
    };
    if (hit(HEAVY_APP_DOMAINS)) return 'heavy';
    if (hit(MEDIUM_DOMAINS)) return 'medium';
    return 'standard';
  }

  /**
   * Heuristic per-tab memory estimate. Pure function — unit tested.
   * Returns { bytes, factors[] } with factors naming every applied signal
   * (shown in the tooltip) so the estimate is always explainable.
   */
  function estimateTabMemory(tab) {
    if (!tab) return { bytes: null, factors: ['unknown tab'] };

    if (tab.discarded) {
      // Factual on every platform: a discarded tab's renderer is unloaded.
      return { bytes: 0, factors: ['discarded'] };
    }

    const url = typeof tab.url === 'string' ? tab.url : '';
    if (/^(chrome|edge|about|devtools|view-source|chrome-extension):/i.test(url)) {
      return {
        bytes: ESTIMATE_MODEL.internalMb * MB,
        factors: ['browser-internal page']
      };
    }

    const factors = [];
    let mb = tab.active ? ESTIMATE_MODEL.baseActiveMb : ESTIMATE_MODEL.baseIdleMb;
    factors.push(tab.active ? 'active tab' : 'background tab');

    const klass = domainClass(tab.domain);
    if (klass === 'heavy') {
      mb *= ESTIMATE_MODEL.heavyMult;
      factors.push('heavyweight web app');
    } else if (klass === 'medium') {
      mb *= ESTIMATE_MODEL.mediumMult;
      factors.push('media-rich site');
    }

    if (tab.audible) {
      mb += ESTIMATE_MODEL.audioMb;
      factors.push('playing audio');
    }
    if (tab.pinned) factors.push('pinned'); // no size effect — informational

    mb = Math.max(ESTIMATE_MODEL.minMb, Math.round(mb));
    return { bytes: mb * MB, factors: factors };
  }

  /** { [tabId]: { bytes, factors } } for a whole tab list. */
  function buildEstimateMap(tabs) {
    const map = {};
    (tabs || []).forEach(function (tab) {
      map[tab.id] = estimateTabMemory(tab);
    });
    return map;
  }

  /** Tooltip text for an estimated memory cell. */
  function describeEstimate(entry, tab) {
    if (!tab) return '';
    if (tab.discarded) return 'Discarded — its renderer memory is already freed.';
    if (!entry || typeof entry.bytes !== 'number') return 'No estimate available for this tab.';
    return 'Memory usage (ESTIMATE): \u2248 ' + Math.round(entry.bytes / MB) + ' MB' +
      '\nDerived from: ' + (entry.factors || []).join(' \u00b7 ') + '.' +
      '\nHeuristic — NOT measured: Chrome\u2019s stable channel does not expose per-tab' +
      '\nmemory to extensions (chrome.processes is Dev-channel / allowlisted).' +
      '\nFor measured values use Chrome\u2019s own Task Manager (Shift+Esc).';
  }

  /** Tooltip text for a measured memory cell, used by the popup list. */
  function describe(entry, tab) {
    if (!tab) return '';
    if (tab.discarded) return 'Discarded — its renderer memory is already freed.';
    if (!entry) return 'No renderer process data for this tab yet.';
    if (typeof entry.bytes !== 'number') {
      return 'Renderer process resolved (pid ' + entry.pid + ') — waiting for the first ' +
        'memory sample from chrome.processes; showing an estimate meanwhile.';
    }
    const shared = entry.sharedWith > 1
      ? ' Renderer process shared by ' + entry.sharedWith + ' tabs — memory shown is process-wide.'
      : '';
    const cpu = typeof entry.cpuPct === 'number'
      ? ' Process CPU: ' + Math.round(entry.cpuPct) + '% (as reported by chrome.processes).'
      : '';
    return 'Renderer private memory, MEASURED via chrome.processes (onUpdatedWithMemory).' + shared + cpu;
  }

  TP.TabMemory = {
    isSupported: isSupported,
    getTabMemoryMap: getTabMemoryMap,
    watchProcessMemory: watchProcessMemory,
    describe: describe,
    estimateTabMemory: estimateTabMemory,
    buildEstimateMap: buildEstimateMap,
    describeEstimate: describeEstimate,
    domainClass: domainClass,
    UNSUPPORTED_REASON: UNSUPPORTED_REASON
  };
})(typeof self !== 'undefined' ? self : globalThis);
