/**
 * TabPilot — storage.js
 * Single source of truth for persistent state. Everything TabPilot stores is
 * local (chrome.storage.local / chrome.storage.session) — no sync, no cloud.
 *
 * Design notes:
 *  - Persistent keys (chrome.storage.local): settings, domain whitelist,
 *    user-protected tabs, performance history, last optimization summary.
 *  - Session keys (chrome.storage.session, RAM-backed, cleared when the
 *    browser exits): per-tab "last accessed" timestamps used for idle
 *    detection. This keeps frequent tab-switch writes out of disk storage.
 *  - Every read is validated through normalizeSettings() so corrupt or
 *    invalid data can never crash the extension (requirement §17).
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  const KEYS = {
    SETTINGS: 'tp:settings',
    HISTORY: 'tp:history',
    WHITELIST: 'tp:whitelist',
    PROTECTED_TABS: 'tp:protectedTabs',
    LAST_OPTIMIZATION: 'tp:lastOptimization',
    LAST_SAVINGS: 'tp:lastSavings',
    SAVINGS_HISTORY: 'tp:savingsHistory'
  };

  const SESSION_KEYS = {
    LAST_ACCESS: 'tp:lastAccess',
    WINDOW_ACTIVE: 'tp:windowActive',
    PENDING_VERIFY: 'tp:pendingVerify',
    // Sites protected WITHOUT touching disk (audit N1/N6, v1.6.1):
    //  - protection started from an INCOGNITO tab (incognito browsing data
    //    never reaches disk storage), and
    //  - pages whose URL has no trustworthy hostname (file:, about:, data:,
    //    blob:, chrome:, …) — their keys would contain (parts of) the URL,
    //    so they are RAM-backed by design.
    // Session storage dies with the browser: both kinds are session-scoped.
    PROTECTED_SESSION: 'tp:protectedSession'
  };

  /**
   * Domains seeded into the whitelist on a FRESH install only (the key has
   * never been written). Conferencing and web-mail hosts carry muted calls
   * and half-written drafts — exactly the in-progress state idle-based
   * discarding cannot see (audit #3). Users can remove any entry.
   */
  const DEFAULT_WHITELIST = Object.freeze([
    'meet.google.com', 'zoom.us', 'teams.microsoft.com', 'hangouts.google.com',
    'discord.com', 'slack.com', 'web.whatsapp.com', 'web.telegram.org',
    'mail.google.com', 'outlook.live.com', 'outlook.office.com', 'mail.yahoo.com'
  ]);

  const DEFAULT_SETTINGS = Object.freeze({
    v: 1,
    monitoring: {
      enabled: true,
      intervalMs: 1000,          // sampling interval: 1000 | 2000 | 5000
      retentionMinutes: 30,      // history window: 5 | 15 | 30
      showGraphs: true,
      monitors: { cpu: true, memory: true, disk: true, network: true, gpu: true }
    },
    optimization: {
      mode: 'manual',            // manual | balanced | aggressive | protected
                                  // manual = default: automatic discarding is
                                  // OPT-IN — first-run defaults never discard
                                  // anything (audit #3)
      autoDiscard: true,         // master switch for automatic discarding
                                  // (only effective in balanced/aggressive)
      idleMinutes: 10,           // 5 | 10 | 15 | 30 | 60
      minPreservedTabs: 5,       // keep at least N non-discarded tabs
      preserveRecentTabs: true   // never auto-discard tabs younger than 5 min
    },
    protection: {
      neverPinned: true,         // hard rule — Chrome API also blocks pinned
      neverAudible: true,
      neverActive: true,         // hard rule — always enforced
      keepUserProtected: true    // hard rule — always enforced (even for
                                  // explicit selections; unprotect first)
    },
    appearance: {
      theme: 'dark'              // dark | light | system
    },
    privacy: {
      favicons: true             // favicons from Chrome's local cache via
                                  // the _favicon endpoint (zero network to
                                  // sites) vs letter tiles
    }
  });

  const VALID_INTERVALS = [1000, 2000, 5000];
  const VALID_RETENTIONS = [5, 15, 30];
  const VALID_IDLE = [5, 10, 15, 30, 60];
  const VALID_MODES = ['manual', 'balanced', 'aggressive', 'protected'];
  const VALID_THEMES = ['dark', 'light', 'system'];

  /* ------------------------------------------------------------------ *
   * Raw area helpers
   * ------------------------------------------------------------------ */

  function localGet(key) {
    return Util.callApi(chrome.storage.local, 'get', key).then(function (obj) {
      return obj != null && key in obj ? obj[key] : undefined;
    });
  }

  function localSet(key, value) {
    const payload = {};
    payload[key] = value;
    return Util.callApi(chrome.storage.local, 'set', payload);
  }

  function localRemove(key) {
    return Util.callApi(chrome.storage.local, 'remove', key);
  }

  /** chrome.storage.session is RAM-backed (Chrome 102+). Falls back to local. */
  function sessionArea() {
    return (chrome.storage && chrome.storage.session) ? chrome.storage.session : chrome.storage.local;
  }

  function sessionGet(key) {
    return Util.callApi(sessionArea(), 'get', key).then(function (obj) {
      return obj != null && key in obj ? obj[key] : undefined;
    });
  }

  function sessionSet(key, value) {
    const payload = {};
    payload[key] = value;
    return Util.callApi(sessionArea(), 'set', payload);
  }

  function sessionRemove(key) {
    return Util.callApi(sessionArea(), 'remove', key);
  }

  /* ------------------------------------------------------------------ *
   * Settings validation
   * ------------------------------------------------------------------ */

  function cloneDefaults() {
    return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  }

  function pickEnum(value, valid, fallback) {
    return valid.indexOf(value) !== -1 ? value : fallback;
  }

  function pickBool(value, fallback) {
    return typeof value === 'boolean' ? value : fallback;
  }

  function pickNumber(value, valid, fallback) {
    return valid.indexOf(value) !== -1 ? value : fallback;
  }

  function pickRange(value, min, max, fallback) {
    return typeof value === 'number' && isFinite(value) ? Util.clamp(Math.round(value), min, max) : fallback;
  }

  /**
   * Validate/repair an arbitrary object into a complete settings object.
   * Invalid fields silently fall back to defaults — the UI must never crash
   * because one value is missing or has the wrong type.
   */
  function normalizeSettings(raw) {
    const s = cloneDefaults();
    if (!raw || typeof raw !== 'object') return s;

    if (raw.monitoring && typeof raw.monitoring === 'object') {
      const m = raw.monitoring;
      s.monitoring.enabled = pickBool(m.enabled, s.monitoring.enabled);
      s.monitoring.intervalMs = pickNumber(Number(m.intervalMs), VALID_INTERVALS, s.monitoring.intervalMs);
      s.monitoring.retentionMinutes = pickNumber(Number(m.retentionMinutes), VALID_RETENTIONS, s.monitoring.retentionMinutes);
      s.monitoring.showGraphs = pickBool(m.showGraphs, s.monitoring.showGraphs);
      if (m.monitors && typeof m.monitors === 'object') {
        ['cpu', 'memory', 'disk', 'network', 'gpu'].forEach(function (k) {
          s.monitoring.monitors[k] = pickBool(m.monitors[k], s.monitoring.monitors[k]);
        });
      }
    }

    if (raw.optimization && typeof raw.optimization === 'object') {
      const o = raw.optimization;
      s.optimization.mode = pickEnum(o.mode, VALID_MODES, s.optimization.mode);
      s.optimization.autoDiscard = pickBool(o.autoDiscard, s.optimization.autoDiscard);
      s.optimization.idleMinutes = pickNumber(Number(o.idleMinutes), VALID_IDLE, s.optimization.idleMinutes);
      s.optimization.minPreservedTabs = pickRange(o.minPreservedTabs, 1, 20, s.optimization.minPreservedTabs);
      s.optimization.preserveRecentTabs = pickBool(o.preserveRecentTabs, s.optimization.preserveRecentTabs);
    }

    if (raw.protection && typeof raw.protection === 'object') {
      const p = raw.protection;
      s.protection.neverPinned = pickBool(p.neverPinned, s.protection.neverPinned);
      s.protection.neverAudible = pickBool(p.neverAudible, s.protection.neverAudible);
      s.protection.neverActive = pickBool(p.neverActive, s.protection.neverActive);
      s.protection.keepUserProtected = pickBool(p.keepUserProtected, s.protection.keepUserProtected);
    }

    if (raw.appearance && typeof raw.appearance === 'object') {
      s.appearance.theme = pickEnum(raw.appearance.theme, VALID_THEMES, s.appearance.theme);
    }

    if (raw.privacy && typeof raw.privacy === 'object') {
      s.privacy.favicons = pickBool(raw.privacy.favicons, s.privacy.favicons);
    }

    return s;
  }

  /* ------------------------------------------------------------------ *
   * Public API
   * ------------------------------------------------------------------ */

  const Storage = {
    KEYS: KEYS,
    SESSION_KEYS: SESSION_KEYS,
    DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    DEFAULT_WHITELIST: DEFAULT_WHITELIST,
    VALID: {
      intervals: VALID_INTERVALS,
      retentions: VALID_RETENTIONS,
      idleMinutes: VALID_IDLE,
      modes: VALID_MODES,
      themes: VALID_THEMES
    },

    normalizeSettings: normalizeSettings,

    /** Read validated settings; writes defaults on first run. */
    getSettings: function () {
      return localGet(KEYS.SETTINGS).then(function (raw) {
        if (raw === undefined) {
          return localSet(KEYS.SETTINGS, normalizeSettings(null)).then(function () {
            return normalizeSettings(null);
          });
        }
        return normalizeSettings(raw);
      });
    },

    /** Read-modify-write partial settings. Returns the new full settings. */
    setSettings: function (partial) {
      return localGet(KEYS.SETTINGS).then(function (raw) {
        const current = normalizeSettings(raw);
        const next = normalizeSettings(deepMerge(current, partial || {}));
        return localSet(KEYS.SETTINGS, next).then(function () { return next; });
      });
    },

    resetSettings: function () {
      return localSet(KEYS.SETTINGS, normalizeSettings(null)).then(function () {
        return normalizeSettings(null);
      });
    },

    get: localGet,
    set: localSet,
    remove: localRemove,

    getSession: sessionGet,
    setSession: sessionSet,
    removeSession: sessionRemove,

    /** Local storage footprint in bytes (for the Settings → Privacy card). */
    getLocalUsage: function () {
      if (chrome.storage.local && typeof chrome.storage.local.getBytesInUse === 'function') {
        return Util.callApi(chrome.storage.local, 'getBytesInUse', null).catch(function () { return null; });
      }
      return Promise.resolve(null);
    },

    /**
     * Seed the conferencing/web-mail whitelist on a FRESH INSTALL only
     * (audit #3 + v1.6.1 audit N3): writes DEFAULT_WHITELIST when (and only
     * when) the whitelist key has never been written — an update never
     * re-adds domains the user deliberately removed. The service worker
     * additionally gates the call on details.reason === 'install', so this
     * idempotence check is a second line of defense, not the only one.
     */
    seedWhitelistIfFresh: function () {
      return localGet(KEYS.WHITELIST).then(function (existing) {
        if (existing !== undefined) return existing;
        const seed = DEFAULT_WHITELIST.slice().sort();
        return localSet(KEYS.WHITELIST, seed).then(function () { return seed; });
      });
    },

    /**
     * PRIVACY (v1.6.1 audit N6): v1.5.0 persisted discarded-tab TITLES (and
     * possibly URLs) inside the stored last-optimization summary. Scrub them
     * once on install/update/startup — only tab ids and bare domains may
     * remain on disk. Idempotent: reads once, writes only when something
     * actually had to be removed.
     */
    scrubLegacySummaries: function () {
      return localGet(KEYS.LAST_OPTIMIZATION).then(function (summary) {
        if (!summary || typeof summary !== 'object' ||
            !Array.isArray(summary.tabsDiscarded)) return null;
        let changed = false;
        summary.tabsDiscarded = summary.tabsDiscarded.map(function (t) {
          if (t && typeof t === 'object' && (t.title != null || t.url != null)) {
            changed = true;
            return { id: t.id, domain: t.domain }; // keep only id + bare domain
          }
          return t;
        });
        if (!changed) return null;
        return localSet(KEYS.LAST_OPTIMIZATION, summary);
      });
    },

    /** Subscribe to changes for one or more local keys. Returns an unsubscribe. */
    onLocalChanged: function (keys, handler) {
      const list = Array.isArray(keys) ? keys : [keys];
      const listener = function (changes, area) {
        if (area !== 'local') return;
        for (let i = 0; i < list.length; i++) {
          if (list[i] in changes) { handler(changes, list[i]); return; }
        }
      };
      chrome.storage.onChanged.addListener(listener);
      return function () { chrome.storage.onChanged.removeListener(listener); };
    }
  };

  /** Shallow-deep merge: objects merged recursively, everything else replaced. */
  function deepMerge(base, patch) {
    const out = JSON.parse(JSON.stringify(base));
    Object.keys(patch).forEach(function (key) {
      const pv = patch[key];
      if (pv && typeof pv === 'object' && !Array.isArray(pv) &&
          out[key] && typeof out[key] === 'object' && !Array.isArray(out[key])) {
        out[key] = deepMerge(out[key], pv);
      } else {
        out[key] = pv;
      }
    });
    return out;
  }

  TP.Storage = Storage;
})(typeof self !== 'undefined' ? self : globalThis);
