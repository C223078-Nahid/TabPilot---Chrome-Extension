/**
 * TabPilot — memory-monitor.js
 * System RAM measurements via chrome.system.memory.getInfo().
 *
 * What is ACTUALLY available (measured):
 *  - total system capacity, currently available capacity -> used = difference.
 * What is NOT available through any stable Chrome extension API:
 *  - browser memory, per-process memory, per-tab memory.
 * The snapshot marks those explicitly so the UI never fakes a number.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  const UNAVAILABLE_BROWSER = {
    status: 'unavailable',
    reason: 'Chrome does not expose browser or per-tab memory to extensions ' +
            '(the chrome.processes API is not available on the stable channel).'
  };

  function sample() {
    if (!(root.chrome && chrome.system && chrome.system.memory)) {
      return Promise.resolve(unavailable('chrome.system.memory is not available ' +
        '(missing permission or unsupported platform).'));
    }
    return Util.callApi(chrome.system.memory, 'getInfo').then(function (info) {
      const capacity = info && typeof info.capacity === 'number' ? info.capacity : null;
      const available = info && typeof info.availableCapacity === 'number' ? info.availableCapacity : null;
      if (capacity == null || available == null) {
        return unavailable('Memory values were not provided by the platform.');
      }
      const used = capacity - available;
      return {
        status: 'available',
        source: 'chrome.system.memory.getInfo()',
        capacity: capacity,
        available: available,
        used: used,
        usedPct: capacity > 0 ? (used / capacity) * 100 : null,
        // Deliberately explicit about what we cannot know:
        browserMemory: UNAVAILABLE_BROWSER,
        perTabMemory: UNAVAILABLE_BROWSER
      };
    }).catch(function (err) {
      return unavailable(
        Util.looksLikePermissionError(err)
          ? 'Memory API blocked — permission required. ' + err.message
          : 'Memory API error: ' + err.message,
        Util.looksLikePermissionError(err) ? 'permission' : 'error'
      );
    });
  }

  function unavailable(reason, status) {
    return {
      status: status || 'unavailable',
      reason: reason,
      capacity: null, available: null, used: null, usedPct: null,
      browserMemory: UNAVAILABLE_BROWSER,
      perTabMemory: UNAVAILABLE_BROWSER
    };
  }

  TP.Memory = { id: 'memory', sample: sample };
})(typeof self !== 'undefined' ? self : globalThis);
