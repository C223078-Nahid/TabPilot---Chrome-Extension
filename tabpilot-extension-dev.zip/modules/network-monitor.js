/**
 * TabPilot — network-monitor.js
 * Network metrics.
 *
 * Two honest data sources, clearly separated in every snapshot:
 *  1. Observed BROWSER traffic (Available — ChromeOS only):
 *     per-process byte counters from chrome.system.cpu's processData.
 *     Deltas between samples give real browser download/upload throughput.
 *     This is browser traffic only — it is never presented as OS-wide traffic.
 *  2. Connection estimate (Estimated — all platforms):
 *     navigator.connection (effectiveType / downlink / rtt). These are coarse
 *     browser estimates, not measurements, and are always labelled as such.
 *
 * Unavailable and never faked:
 *  - OS-wide network traffic (no extension API),
 *  - per-tab network activity (tabs cannot be mapped to processes).
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  const THROUGHPUT_UNAVAILABLE = {
    status: 'unavailable',
    reason: 'Network throughput is only observable on ChromeOS (via per-process ' +
            'byte counters). Chrome does not expose OS-wide traffic to extensions.'
  };

  const PER_TAB_UNAVAILABLE = {
    status: 'unavailable',
    reason: 'Chrome does not expose per-tab network activity to extensions.'
  };

  function sample(prev, ctx) {
    const out = {
      status: 'unavailable',       // overall status = throughput availability
      source: 'navigator.connection (estimate)',
      browser: null,               // {downBps, upBps, totalDown, totalUp} when available
      connection: readConnection(),
      perTab: PER_TAB_UNAVAILABLE,
      osWide: { status: 'unavailable', reason: 'OS-wide traffic is not accessible to extensions.' }
    };

    // Reuse the CPU sample from the same tick (one getInfo call, two metrics).
    const cpu = ctx && ctx.cpu;
    const processes = cpu && cpu.processes;
    const prevNetwork = prev ? prev._networkTotals : null;

    if (processes && processes.available && processes.network) {
      const totals = processes.network; // {bytesRead, bytesWritten} cumulative
      if (prevNetwork &&
          totals.bytesRead >= prevNetwork.bytesRead &&
          totals.bytesWritten >= prevNetwork.bytesWritten) {
        const dtMs = Math.max(1, (ctx.t - (prev._t || ctx.t - 1000)));
        out.browser = {
          downBps: Math.max(0, ((totals.bytesRead - prevNetwork.bytesRead) * 1000) / dtMs),
          upBps: Math.max(0, ((totals.bytesWritten - prevNetwork.bytesWritten) * 1000) / dtMs),
          totalDown: totals.bytesRead,
          totalUp: totals.bytesWritten
        };
        out.status = 'available';
        out.source = 'per-process byte counters (chrome.system.cpu.processData — ChromeOS)';
      }
      out._networkTotals = totals;
    }
    return Promise.resolve(out);
  }

  /**
   * navigator.connection — coarse, browser-internal estimates.
   * downlink is capped/quantized by Chrome (values like 0.25 … 10 Mbps),
   * so it is always reported with status "estimated".
   */
  function readConnection() {
    const conn = (typeof navigator !== 'undefined' && navigator.connection) || null;
    if (!conn) {
      return { status: 'unavailable', reason: 'navigator.connection is not available in this context.' };
    }
    return {
      status: 'estimated',
      reason: 'Coarse estimate maintained by the browser — not a live measurement.',
      effectiveType: conn.effectiveType || null,   // slow-2g..4g
      type: conn.type || null,                     // wifi/cellular/ethernet…
      downlinkMbps: typeof conn.downlink === 'number' ? conn.downlink : null,
      rttMs: typeof conn.rtt === 'number' ? conn.rtt : null,
      saveData: !!conn.saveData
    };
  }

  TP.Network = { id: 'network', sample: sample, THROUGHPUT_UNAVAILABLE: THROUGHPUT_UNAVAILABLE };
})(typeof self !== 'undefined' ? self : globalThis);
