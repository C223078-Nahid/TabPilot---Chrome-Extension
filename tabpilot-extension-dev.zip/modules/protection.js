/**
 * TabPilot — protection.js
 * Tab protection & domain whitelist.
 *
 * Two mechanisms protect tabs from TabPilot's optimizer:
 *  1. Rule-based protection (pinned / audible / active) — configured in
 *     Settings; "active" and "user-protected" are always enforced.
 *  2. Explicit protection — the site of a user-protected tab, or any tab
 *     whose domain is on the permanent whitelist.
 *
 * DURABILITY (audit #2): tab ids are session-scoped in Chrome — they change
 * on every browser restart, so protection can NOT be keyed by tab id. It is
 * keyed by HOSTNAME instead ("site-level protection"): protecting a tab
 * protects every open tab of that exact site (www. variants included) and
 * survives restarts and service-worker restarts. The whitelist remains the
 * coarser tool (whole domain trees, suffix-matched).
 *
 * PRIVACY (audit #6 + v1.6.1 audit N1): ONLY the bare hostname of http(s)
 * URLs is ever persisted to disk — never a tab title, never any part of a
 * URL. Pages whose scheme has no trustworthy hostname (file:, about:,
 * data:, blob:, chrome:, …) are protected for the CURRENT SESSION ONLY, in
 * RAM-backed chrome.storage.session: their keys would contain (parts of)
 * the URL, and v1.6.0 wrongly persisted whole file:/data: URLs. The same
 * session-only rule applies to protection started from an INCOGNITO tab,
 * so incognito browsing data never reaches disk either.
 *
 * PURGE (v1.6.2 audit R1): v1.6.0 also wrote hostless keys (full URLs)
 * and bare browser-internal names ("settings" for chrome://settings) into
 * the v2 sites map; v1.6.1 stopped WRITING them but never removed the
 * ones already on disk. Every read now normalizes the map — keys that are
 * not plain hostnames are dropped, and the map is rewritten once with a
 * `purgedHostless` marker so later intranet hosts that merely share a
 * browser-internal name keep persisting (see normalizeSitesMap). The
 * name-based purge is deliberately NARROW (v1.6.2 audit S2): maps written
 * by v1.6.1 carry no marker but may legitimately hold intranet hosts
 * called "help", "apps" or "history", so only names that are implausible
 * as real hosts are dropped — see BROWSER_INTERNAL_HOSTS.
 *
 * MIGRATION: v1.5.0 stored { [tabId]: {title, url, domain, ts} }. On read,
 * legacy entries are folded into the hostname map (their `domain` field)
 * and the old shape is replaced; entries whose URL reveals a non-http(s)
 * page (chrome://, file://, …) are dropped instead of persisted — see
 * docs/RELEASE-NOTES.md.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;
  const Storage = TP.Storage;

  /**
   * True only for http(s) URLs — the only schemes whose "hostname" is a
   * real network host that identifies the site. chrome://settings has
   * hostname "settings" (v1.6.1 audit N5) and chrome-extension:// pages
   * have the extension id as hostname — neither may be persisted or
   * suffix-matched against the whitelist like an intranet host.
   */
  function isHttpSite(url) {
    if (typeof url !== 'string' || !url) return false;
    const scheme = (url.split(':')[0] || '').toLowerCase();
    return scheme === 'http' || scheme === 'https';
  }

  /**
   * Durable, disk-persisted protection key for a tab: the hostname of its
   * http(s) URL ("www." ignored) — shared by all tabs of the same site and
   * stable across restarts. '' for every other scheme: those pages are
   * protected session-only via sessionKeyOf() instead (v1.6.1 audit N1).
   */
  function siteKeyOf(url) {
    if (!isHttpSite(url)) return '';
    const host = Util.hostnameOf(url);
    if (!host) return '';
    return host.indexOf('www.') === 0 ? host.slice(4) : host;
  }

  /**
   * SESSION-ONLY protection key for pages whose scheme has no trustworthy
   * hostname (file:, about:, data:, blob:, chrome:, edge:, view-source:, …).
   *  - Prefixed with the scheme so the key can never collide with a
   *    same-named intranet host ("chrome://settings" ≠ intranet
   *    "settings") — v1.6.1 audit N5.
   *  - Hashed (FNV-1a) when the URL is long, so a giant data: URL cannot
   *    blow up storage — v1.6.1 audit N1.
   *  - NEVER persisted: these keys live only in RAM-backed
   *    chrome.storage.session and die with the browser (v1.6.1 audit N1).
   * '' when no session key can be derived (protect is then refused).
   */
  function sessionKeyOf(url) {
    if (typeof url !== 'string' || !url) return '';
    const colon = url.indexOf(':');
    if (colon < 1) return '';
    const scheme = url.slice(0, colon).toLowerCase();
    if (!/^[a-z][a-z0-9+.-]*$/.test(scheme)) return '';
    if (scheme === 'http' || scheme === 'https') return '';
    return url.length > 192
      ? scheme + ':#<' + Util.shortHash(url) + '>'
      : scheme + ':' + url.slice(colon + 1);
  }

  /* ------------------------------------------------------------------ *
   * State
   * ------------------------------------------------------------------ */

  /**
   * Hostnames of browser-internal pages that are IMPLAUSIBLE as real
   * intranet hosts (chrome://settings → "settings", chrome://newtab →
   * "newtab", …). v1.6.0 wrongly persisted these as site keys (audit
   * N5/R1): in a NOT-YET-PURGED map, a v2 key equal to one of these names
   * is a v1.6.0 leftover, not an intranet host, and is dropped by the
   * one-time purge below.
   *
   * Deliberately NARROW (v1.6.2 audit S2): the purge also runs on
   * marker-less maps written by v1.6.1, which could legitimately contain
   * intranet hosts named "help", "apps", "system", "downloads" or
   * "history" (the audit's simulation lost three of four such entries).
   * Those plausible-host names are deliberately NOT in this list — a
   * stale v1.6.0 leftover with such a name surviving is far less harmful
   * than silently losing a user's real protection. Only names that are
   * essentially never used as hostnames remain.
   */
  const BROWSER_INTERNAL_HOSTS = Object.freeze([
    'settings', 'newtab', 'new-tab-page', 'net-internals', 'gpu',
    'flags', 'discards', 'crashes', 'version'
  ]);

  /**
   * True for keys that may live in the persisted v2 sites map: plain
   * hostnames only — no scheme, no path, no whitespace (v1.6.0 wrote
   * full file:/data:/about: URLs as keys — audit R1). `allowInternal`
   * must be false only for maps not yet purged: there, a bare name from
   * BROWSER_INTERNAL_HOSTS ("settings") is a v1.6.0 chrome:// leftover
   * (audit N5), while a purged map can only contain names written by
   * v1.6.1+ — where "settings" is a legitimate intranet host. Names that
   * are plausible intranet hosts ("help", "history", …) never fail this
   * check, even unpurged (v1.6.2 audit S2).
   */
  function isPlainHostnameKey(key, allowInternal) {
    if (typeof key !== 'string' || !key) return false;
    if (/[:\s/]/.test(key)) return false; // URL-ish key: never a hostname
    if (!allowInternal &&
        BROWSER_INTERNAL_HOSTS.indexOf(key.toLowerCase()) !== -1) {
      return false;
    }
    return true;
  }

  /**
   * Normalize a raw PROTECTED_TABS value into the v2 sites map.
   * Returns { sites, rewrite }:
   *  - sites:   the clean { [host]: ts } map (http(s) hostnames only);
   *  - rewrite: true when the stored value must be REPLACED once, so the
   *             stale keys are actively removed from disk — for the legacy
   *             v1.5.0 shape, and for a v2 map that still holds v1.6.0
   *             hostless keys (full URLs, browser-internal names) or lacks
   *             the purge marker (v1.6.2 audit R1: the v1.6.1 code copied
   *             every v2 key as-is, so URLs written by v1.6.0 stayed on
   *             disk and kept matching).
   */
  function normalizeSitesMap(raw) {
    // v2 shape: { v: 2, purgedHostless?: true, sites: { [host]: ts } }
    if (raw && typeof raw === 'object' && !Array.isArray(raw) &&
        raw.v === 2 && raw.sites && typeof raw.sites === 'object') {
      const purged = raw.purgedHostless === true;
      const sites = {};
      let dropped = false;
      Object.keys(raw.sites).forEach(function (host) {
        if (isPlainHostnameKey(host, purged)) {
          sites[host] = raw.sites[host];
        } else {
          dropped = true; // v1.6.0 leftover (or a rolled-back map) — purge
        }
      });
      return { sites: sites, rewrite: dropped || !purged };
    }
    // Legacy shape: { [numericTabId]: {title, url, domain, ts} } — keep only
    // the hostname (never the title/URL). Entries whose stored `url` shows a
    // non-http(s) page (chrome://, file://, … — v1.5.0 stored their parsed
    // hostname, e.g. "settings") are DROPPED, not migrated: their "hostname"
    // is not a real site key and would collide with intranet hosts
    // (v1.6.1 audit N5). The stale entry (title + full URL!) is actively
    // removed from storage by the v2 rewrite below.
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      const sites = {};
      Object.keys(raw).forEach(function (key) {
        const entry = raw[key];
        if (entry && typeof entry === 'object' && typeof entry.domain === 'string') {
          const host = entry.url
            ? siteKeyOf(entry.url)
            : siteKeyOf('http://' + entry.domain);
          if (host) sites[host] = entry.ts || Date.now();
        }
      });
      return { sites: sites, rewrite: true };
    }
    return { sites: {}, rewrite: false };
  }

  function isLegacyShape(raw) {
    return !(raw && typeof raw === 'object' && !Array.isArray(raw) && raw.v === 2);
  }

  /** Persisted sites map (v2 wrapper around the hostname map). */
  function readSites() {
    return Storage.get(Storage.KEYS.PROTECTED_TABS).then(function (raw) {
      const normalized = normalizeSitesMap(raw);
      if (isLegacyShape(raw) || normalized.rewrite) {
        // Replace the stored value once: migrate the legacy shape, purge
        // v1.6.0's hostless keys and set the purge marker (audit R1) — so
        // the old titles/URLs and the marker-less v2 shape are actively
        // REMOVED from storage, exactly like the legacy migration.
        return writeSites(normalized.sites).then(function () {
          return normalized.sites;
        });
      }
      return normalized.sites;
    });
  }

  function writeSites(sites) {
    // purgedHostless marks maps written by v1.6.2+: from here on, a bare
    // "settings" key can only be an intranet host (audit R1) — never
    // re-purged, so intranet hosts sharing a browser-internal name keep
    // persisting across restarts like any other site.
    return Storage.set(Storage.KEYS.PROTECTED_TABS,
      { v: 2, purgedHostless: true, sites: sites });
  }

  /** RAM-backed session sites: incognito-sourced sites and hostless-scheme
   *  pages (file:, chrome:, …). Never written to disk (v1.6.1 audit N1). */
  function readSessionSites() {
    return Storage.getSession(Storage.SESSION_KEYS.PROTECTED_SESSION).then(function (raw) {
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) return raw;
      return {};
    });
  }

  /**
   * Read the protection state: whitelist + persistent site map +
   * session-only site map (incognito-sourced sites, hostless-scheme pages).
   * One object passed to the pure checkers below.
   */
  function getState() {
    return Promise.all([
      Storage.get(Storage.KEYS.WHITELIST),
      readSites(),
      readSessionSites()
    ]).then(function (results) {
      const whitelist = Array.isArray(results[0]) ? results[0].filter(function (d) {
        return typeof d === 'string' && d;
      }) : [];
      return {
        whitelist: whitelist,
        protectedSites: results[1],     // persistent { [host]: ts } — http(s) hostnames only
        sessionSites: results[2]        // RAM-only { [host|scheme:key]: ts }
      };
    });
  }

  /* ------------------------------------------------------------------ *
   * Pure checks
   * ------------------------------------------------------------------ */

  /**
   * Explicit protection check: user-protected site (persistent hostname map
   * or RAM-backed session map) or whitelisted domain (http(s) only —
   * v1.6.1 audit N5: chrome://settings must not match an intranet
   * "settings" whitelist entry).
   * Returns { protected: boolean, reason: 'user' | 'domain' | null }.
   */
  function isTabProtected(tab, state) {
    const st = state || {};
    const sites = st.protectedSites || {};
    const session = st.sessionSites || {};
    const whitelist = Array.isArray(st.whitelist) ? st.whitelist : [];
    const site = siteKeyOf(tab && tab.url);          // http(s) hostname key
    if (site && (sites[site] || session[site])) {
      return { protected: true, reason: 'user' };
    }
    const skey = sessionKeyOf(tab && tab.url);       // hostless-scheme key
    if (skey && session[skey]) {
      return { protected: true, reason: 'user' };
    }
    if (isHttpSite(tab && tab.url)) {
      const host = Util.hostnameOf(tab && tab.url);
      if (host) {
        for (let i = 0; i < whitelist.length; i++) {
          if (Util.matchesDomain(host, whitelist[i])) {
            return { protected: true, reason: 'domain' };
          }
        }
      }
    }
    return { protected: false, reason: null };
  }

  /** Combined check used for badges/UI: explicit + rule-based protection. */
  function isTabShielded(tab, ctx) {
    // ctx = { state, settings, activeIds:Set }
    const explicit = isTabProtected(tab, ctx.state);
    if (explicit.protected) return explicit;
    if (tab && tab.pinned && ctx.settings.protection.neverPinned) return { protected: true, reason: 'pinned' };
    if (tab && tab.audible && ctx.settings.protection.neverAudible) return { protected: true, reason: 'audible' };
    if (tab && tab.active && ctx.settings.protection.neverActive) return { protected: true, reason: 'active' };
    return { protected: false, reason: null };
  }

  /**
   * Honest description of what protection for THIS tab means (v1.6.2 audit
   * R3 — the UI wording must not promise more than the code delivers):
   *   { kind: 'site', durable: true  } — every tab of the site, on disk,
   *                                    survives restarts (http(s), not
   *                                    incognito, protected persistently);
   *   { kind: 'site', durable: false } — every tab of the site, but RAM-only
   *                                    for this session (incognito-sourced
   *                                    protection, never written to disk);
   *   { kind: 'page', durable: false } — this EXACT page only, RAM-only for
   *                                    this session (file:, chrome:, …).
   * For an already-protected tab the ACTUAL store decides (a site protected
   * from an incognito tab covers normal tabs too — but only until the
   * browser closes); `state` may be omitted when only the tab is known
   * (e.g. right after protectTab wrote exactly what the tab implies).
   */
  function protectionScopeOf(tab, state) {
    const url = tab && tab.url;
    const site = siteKeyOf(url);
    if (site) {
      const st = state || {};
      const session = st.sessionSites || {};
      const persistent = st.protectedSites || {};
      if (session[site]) return { kind: 'site', durable: false };
      if (persistent[site]) return { kind: 'site', durable: true };
      // Not (user-)protected: describe what protecting this tab WOULD do.
      return (tab && tab.incognito)
        ? { kind: 'site', durable: false }
        : { kind: 'site', durable: true };
    }
    // No trustworthy hostname (file:, chrome:, about:, data:, blob:, …):
    // session key covers exactly this page, RAM-only (audit N1/R3).
    return { kind: 'page', durable: false };
  }

  /* ------------------------------------------------------------------ *
   * Mutations
   * ------------------------------------------------------------------ */

  /**
   * Protect a tab by its SITE. http(s) tabs are keyed by hostname (all tabs
   * of the same site are protected, survives restarts, only the hostname is
   * stored). Everything else is SESSION-ONLY (v1.6.1 audit N1):
   *  - incognito tabs (any scheme): RAM-backed, never on disk;
   *  - hostless-scheme pages (file:, about:, data:, blob:, chrome:, …):
   *    RAM-backed too — no part of their URL may be persisted.
   */
  function protectTab(tab) {
    const url = tab && tab.url;
    const site = siteKeyOf(url);
    const skey = site ? '' : sessionKeyOf(url);
    if (!site && !skey) {
      return Promise.reject(new Error('Cannot protect this tab yet — its address is not available (still loading?)'));
    }
    if (skey || (tab && tab.incognito)) {
      return readSessionSites().then(function (map) {
        map[site || skey] = Date.now();
        return Storage.setSession(Storage.SESSION_KEYS.PROTECTED_SESSION, map);
      });
    }
    return readSites().then(function (sites) {
      sites[site] = Date.now();
      return writeSites(sites);
    });
  }

  /** Remove site protection (persistent and session stores, both key kinds). */
  function unprotectTab(tab) {
    const url = tab && tab.url;
    const site = siteKeyOf(url);
    const skey = site ? '' : sessionKeyOf(url);
    if (!site && !skey) return Promise.resolve();
    return Promise.all([readSites(), readSessionSites()]).then(function (maps) {
      const chain = [];
      if (maps[0][site]) {
        delete maps[0][site];
        chain.push(writeSites(maps[0]));
      }
      if ((site && maps[1][site]) || (skey && maps[1][skey])) {
        if (site) delete maps[1][site];
        if (skey) delete maps[1][skey];
        chain.push(Storage.setSession(Storage.SESSION_KEYS.PROTECTED_SESSION, maps[1]));
      }
      return Promise.all(chain);
    });
  }

  /**
   * Toggle. User site protection: on → off. A tab protected ONLY by the
   * whitelist is left untouched — the whitelist is managed in Settings,
   * and the UI tooltip says so instead of pretending to remove it.
   * Resolves to true when the tab is protected afterwards.
   */
  function toggleTab(tab) {
    return getState().then(function (state) {
      const verdict = isTabProtected(tab, state);
      if (verdict.protected && verdict.reason === 'domain') return 'whitelisted';
      return verdict.protected ? unprotectTab(tab) : protectTab(tab);
    }).then(function (result) {
      if (result === 'whitelisted') return true; // still protected (by the whitelist)
      return getState().then(function (state) {
        return isTabProtected(tab, state).protected;
      });
    });
  }

  /**
   * Whitelist a domain (v1.6.1 audit N4, reworked in v1.6.2 audit R2,
   * tightened in v1.6.3 for v1.6.2 audit S3). Known public suffixes are
   * dangerous entries — one would silently switch the optimizer off for a
   * large part of the web — so:
   *  - a SINGLE label that looks like a public suffix ("dev", "wiki",
   *    "io", …) is NOT refused outright: it may be a real intranet
   *    host, so it gets a warning + explicit confirm step. The UI shows
   *    the warning and re-calls with { confirmed: true } ("Add anyway");
   *    the rejected Error carries .confirmable = true for that. The
   *    five classic generic TLDs ("com", "org", "net", "edu", "gov") are
   *    the exception: nobody has an intranet host with one of those
   *    names, and confirming one would protect the whole gTLD, so they
   *    are REFUSED even with confirmation (v1.6.2 audit S3).
   *  - a MULTI-label entry that IS a known public suffix ("co.uk",
   *    "com.au", "*.co.uk") can never be an intranet host and is
   *    refused outright with a precise message. Curated lists can never
   *    be complete (v1.6.2 audit S3: "com.bd", "ac.in", "co.at" and
   *    friends were all silently accepted), so multi-label entries of
   *    the form <generic prefix>.<two-letter country code> ("com.bd",
   *    "gov.in", "or.jp", …) are refused by PATTERN as well — every
   *    two-letter TLD is a country code, and a two-label entry of that
   *    shape is always a public suffix, never a real host (a real host
   *    under it, "example.com.bd", has three labels and stays
   *    acceptable).
   *  - plausible single-label intranet hosts — "localhost", "nas", "db",
   *    "wiki" after confirming, "test"/"local" (not public suffixes at
   *    all) — are accepted, short ones included (audit R2: the old
   *    under-3-characters and curated-list refusals blocked real
   *    intranet hosts with a misleading "bare top-level domain" message).
   */
  function addDomain(domain, opts) {
    const confirmed = !!(opts && opts.confirmed);
    const normalized = Util.normalizeDomain(domain);
    if (!normalized) return Promise.reject(new Error('Invalid domain: ' + domain));
    // Check the entry without its "*." prefix and any trailing dot
    // ("*.com", "com." are just as dangerous as "com").
    const bareLabel = normalized.replace(/^\*\./, '').replace(/\.$/, '');
    if (bareLabel === '*' || normalized === '*') {
      return Promise.reject(new Error(
        '"*" alone matches nothing — use a full domain (example.com) or a pattern (*.example.com).'));
    }
    if (bareLabel.indexOf('.') === -1) {
      // v1.6.2 audit S3: the classic generic TLDs are refused OUTRIGHT —
      // nobody has an intranet host called "com", and the "Add anyway"
      // step must not be able to protect every *.com site.
      if (Util.isBareGenericTld(bareLabel)) {
        return Promise.reject(new Error(
          '"' + bareLabel + '" is a top-level domain — protecting it would cover every *.' + bareLabel +
          ' site. Add a full domain (e.g. example.' + bareLabel + ') instead.'));
      }
      if (Util.isLikelyPublicSuffix(bareLabel) && !confirmed) {
        const err = new Error(
          '"' + bareLabel + '" looks like a public suffix — protecting it would cover every *.' + bareLabel +
          ' site. If "' + bareLabel + '" is an intranet host you really use, add it anyway.');
        err.confirmable = true; // UI: show warning + "Add anyway" step
        return Promise.reject(err);
      }
    } else if (Util.isKnownSecondLevelSuffix(bareLabel) ||
               Util.looksLikeSecondLevelSuffix(bareLabel)) {
      // Known by list, or matching the <generic prefix>.<country code>
      // pattern (v1.6.2 audit S3) — either way a public suffix that can
      // never be a real intranet host: refuse, no confirm step.
      return Promise.reject(new Error(
        '"' + bareLabel + '" is a public suffix — it would protect every *.' + bareLabel +
        ' site. Add a full domain (e.g. example.' + bareLabel + ') instead.'));
    }
    return getState().then(function (state) {
      if (state.whitelist.indexOf(normalized) !== -1) return state.whitelist;
      const next = state.whitelist.concat([normalized]).sort();
      return Storage.set(Storage.KEYS.WHITELIST, next).then(function () { return next; });
    });
  }

  function removeDomain(domain) {
    return getState().then(function (state) {
      const next = state.whitelist.filter(function (d) { return d !== domain; });
      return Storage.set(Storage.KEYS.WHITELIST, next).then(function () { return next; });
    });
  }

  /** Whitelist a tab's whole domain in one action ("Protect all tabs from…").
   * `opts.confirmed` (audit R2) passes the confirm step through for
   * intranet hosts whose name looks like a public suffix ("http://dev/"). */
  function protectTabDomain(tab, opts) {
    return addDomain(Util.hostnameOf(tab && tab.url), opts);
  }

  /** Count of currently open tabs that explicit protection covers. */
  function protectedCount(tabs, state) {
    let count = 0;
    (tabs || []).forEach(function (tab) {
      if (isTabProtected(tab, state).protected) count++;
    });
    return count;
  }

  TP.Protection = {
    getState: getState,
    isTabProtected: isTabProtected,
    isTabShielded: isTabShielded,
    protectionScopeOf: protectionScopeOf,
    siteKeyOf: siteKeyOf,
    sessionKeyOf: sessionKeyOf,
    protectTab: protectTab,
    unprotectTab: unprotectTab,
    toggleTab: toggleTab,
    addDomain: addDomain,
    removeDomain: removeDomain,
    protectTabDomain: protectTabDomain,
    protectedCount: protectedCount,
    matchesDomain: Util.matchesDomain
  };
})(typeof self !== 'undefined' ? self : globalThis);
