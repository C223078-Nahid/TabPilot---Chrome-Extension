/**
 * TabPilot — tab-manager.js
 * Chrome tab access layer: querying, enrichment, classification helpers and
 * tab actions (discard / close / reload / focus).
 *
 * Honest-metrics note: Chrome does NOT expose per-tab CPU, memory or network
 * usage to extensions. The chrome.processes API that would provide this is
 * not available on the stable channel (see docs/API-COMPATIBILITY.md), so we
 * never pretend to show those values.
 *
 * chrome.tabs.discard() constraints handled here:
 *  - the active tab of any window can never be discarded (API error),
 *  - pinned tabs can never be discarded (API error),
 *  - tabs with autoDiscardable:false are skipped,
 *  - every call is wrapped so one failure never breaks a batch.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  /* ------------------------------------------------------------------ *
   * Query & enrich
   * ------------------------------------------------------------------ */

  /** All tabs in all windows, enriched with domain + last accessed time. */
  function getAll() {
    return Util.callApi(chrome.tabs, 'query', {}).then(function (tabs) {
      return (tabs || []).map(enrich);
    });
  }

  function enrich(tab) {
    const copy = Object.assign({}, tab);
    copy.domain = Util.hostnameOf(tab.url);
    copy.lastAccessedAt = lastAccessedOf(tab, {});
    return copy;
  }

  /**
   * Best known "last accessed" timestamp for a tab.
   * Prefers the larger (more recent) of the undocumented-but-present
   * tab.lastAccessed field and our own event-tracked timestamp, so idle
   * time is never over-estimated (conservative = never discards too early).
   */
  function lastAccessedOf(tab, lastAccessMap) {
    const tracked = (lastAccessMap && lastAccessMap[tab.id]) || 0;
    const native = (typeof tab.lastAccessed === 'number' && tab.lastAccessed > 0) ? tab.lastAccessed : 0;
    const best = Math.max(tracked, native);
    return best > 0 ? best : null;
  }

  /** Set of tab ids that are active in their window. */
  function activeTabIds(tabs) {
    const set = {};
    (tabs || []).forEach(function (tab) { if (tab.active) set[tab.id] = true; });
    return set;
  }

  /** Aggregate counts for the overview chips. */
  function counts(tabs, protectionState, settings) {
    const out = {
      total: tabs.length, active: 0, inactive: 0, discarded: 0,
      protected: 0, audible: 0, pinned: 0, loading: 0
    };
    (tabs || []).forEach(function (tab) {
      if (tab.active) out.active++;
      if (tab.discarded) out.discarded++;
      else if (!tab.active) out.inactive++;
      if (tab.audible) out.audible++;
      if (tab.pinned) out.pinned++;
      if (tab.status === 'loading') out.loading++;
      // "Protected" counts EXPLICIT protection (user-protected tab or
      // whitelisted domain). Rule-based protection (pinned/audible/active)
      // is displayed through those tabs' own badges.
      if (TP.Protection && TP.Protection.isTabProtected(tab, protectionState).protected) {
        out.protected++;
      }
    });
    return out;
  }

  /**
   * Single source of truth for "can/should this tab be discarded?".
   * Pure function — unit tested in scripts/unit-tests.js.
   *
   * ctx = {
   *   now,                    ms timestamp
   *   lastAccess,             map tabId -> last accessed ms (may be empty)
   *   activeIds,              object of active tab ids (from activeTabIds)
   *   settings,               normalized settings
   *   protectionState,        { whitelist, protectedSites, sessionSites }
   *   idleMinutes,            effective idle threshold
   *   respectRules            boolean; false = explicit user selection:
   *                           bypasses SOFT protections (whitelist/audible/
   *                           recent/loading) — but never the Chrome API hard
   *                           rules NOR user site protection ("Keep
   *                           user-protected tabs" is always enforced;
   *                           unprotect the site first to discard it).
   * }
   * Returns { eligible: boolean, reason: string, idleMs: number|null }.
   */
  function classifyTab(tab, ctx) {
    const out = { eligible: false, reason: '', idleMs: null };
    if (!tab) { out.reason = 'missing-tab'; return out; }

    const activeIds = ctx.activeIds || {};
    if (tab.active || activeIds[tab.id]) { out.reason = 'active'; return out; }
    if (tab.pinned) { out.reason = 'pinned'; return out; }          // Chrome API hard rule
    if (tab.discarded) { out.reason = 'already-discarded'; return out; }
    if (tab.autoDiscardable === false) { out.reason = 'non-discardable'; return out; }

    const url = typeof tab.url === 'string' ? tab.url : '';
    // Extension pages (TabPilot's own dashboard, other extensions' UIs) and
    // DevTools windows are never discarded — unloading them breaks tooling.
    if (url.indexOf('chrome-extension://') === 0 || url.indexOf('devtools://') === 0) {
      out.reason = 'extension-page'; return out;
    }

    // USER SITE PROTECTION is a hard rule (Settings: "Keep user-protected
    // tabs — always enforced"), so it applies to EVERY trigger, including
    // explicit selections. Whitelisted domains remain bypassable by an
    // explicit selection (the whitelist is documented as "never discarded
    // AUTOMATICALLY").
    const explicit = TP.Protection.isTabProtected(tab, ctx.protectionState);
    if (explicit.protected && explicit.reason === 'user') {
      out.reason = 'user-protected'; return out;
    }

    const respectRules = ctx.respectRules !== false;
    if (respectRules) {
      if (explicit.protected) { out.reason = 'whitelisted'; return out; }
      if (ctx.settings.protection.neverAudible && tab.audible) { out.reason = 'audible'; return out; }
      // A still-loading tab may be mid-submit (form POST, upload, nav):
      // idle-time heuristics cannot see that, so skip it (audit #3).
      if (tab.status === 'loading') { out.reason = 'loading'; return out; }
      const lastAccessed = lastAccessedOf(tab, ctx.lastAccess);
      if (lastAccessed == null) { out.reason = 'unknown-age'; return out; } // never guess idle time
      const idleMs = ctx.now - lastAccessed;
      out.idleMs = idleMs;
      let idleMin = ctx.idleMinutes;
      if (ctx.settings.optimization.preserveRecentTabs) idleMin = Math.max(idleMin, 5);
      if (idleMs < idleMin * 60000) { out.reason = 'recent'; return out; }
    }
    out.eligible = true;
    out.reason = 'eligible';
    return out;
  }

  /* ------------------------------------------------------------------ *
   * Actions (each resolves or rejects per tab; batches collect results)
   * ------------------------------------------------------------------ */

  /** Discard one tab. Rejects with the Chrome API error when not allowed. */
  function discardOne(tabId) {
    return Util.callApi(chrome.tabs, 'discard', tabId);
  }

  function closeOne(tabId) {
    return Util.callApi(chrome.tabs, 'remove', tabId);
  }

  function reloadOne(tabId) {
    return Util.callApi(chrome.tabs, 'reload', tabId);
  }

  /** Focus/open a tab in its window. */
  function activate(tab) {
    return Util.callApi(chrome.tabs, 'update', tab.id, { active: true }).then(function () {
      if (tab.windowId != null) return Util.callApi(chrome.windows, 'update', tab.windowId, { focused: true });
    });
  }

  /** Discard several tabs; resolves to { ok: [...], failed: [{id, error}] }. */
  function discardMany(tabIds) {
    return runBatch(discardOne, tabIds);
  }

  function closeMany(tabIds) {
    return runBatch(closeOne, tabIds);
  }

  /** Reload several tabs (e.g. wake up every discarded tab). */
  function reloadMany(tabIds) {
    return runBatch(reloadOne, tabIds);
  }

  /** Sequential execution so one API error can never break the batch. */
  function runBatch(action, tabIds) {
    const ok = [];
    const failed = [];
    let chain = Promise.resolve();
    (tabIds || []).forEach(function (id) {
      chain = chain.then(function () {
        return action(id).then(function () { ok.push(id); },
                              function (err) { failed.push({ id: id, error: (err && err.message) || 'error' }); });
      });
    });
    return chain.then(function () { return { ok: ok, failed: failed }; });
  }

  /** Human-readable discard eligibility, used for tooltips in the UI. */
  const REASON_LABELS = {
    'active': 'Active tab — Chrome never discards the focused tab',
    'pinned': 'Pinned tab — Chrome never discards pinned tabs',
    'already-discarded': 'Already discarded',
    'non-discardable': 'Marked non-discardable by Chrome (autoDiscardable: false)',
    'extension-page': 'Extension pages are always protected',
    'user-protected': 'Protected by you (site-level — always enforced)',
    'whitelisted': 'Domain is on the whitelist',
    'audible': 'Playing audio',
    'loading': 'Still loading — may be mid-submit, skipped for safety',
    'recent': 'Accessed recently (idle period not reached)',
    'unknown-age': 'Idle time unknown — skipped for safety',
    'eligible': 'Can be discarded',
    'missing-tab': 'Tab no longer exists'
  };

  TP.Tabs = {
    getAll: getAll,
    enrich: enrich,
    lastAccessedOf: lastAccessedOf,
    activeTabIds: activeTabIds,
    counts: counts,
    classifyTab: classifyTab,
    discardOne: discardOne,
    closeOne: closeOne,
    reloadOne: reloadOne,
    activate: activate,
    discardMany: discardMany,
    closeMany: closeMany,
    reloadMany: reloadMany,
    REASON_LABELS: REASON_LABELS
  };
})(typeof self !== 'undefined' ? self : globalThis);
