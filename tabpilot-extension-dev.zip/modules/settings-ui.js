/**
 * TabPilot — settings-ui.js
 * Shared settings component, mounted by BOTH the dashboard Settings section
 * and the standalone options page. Single implementation = zero drift.
 *
 * Every control persists through chrome.storage.local immediately; the
 * service worker reacts to storage.onChanged and re-syncs its alarm, so
 * settings take effect without any explicit messaging.
 *
 * Honesty by design: locked rows explain hard rules (pinned/active/user
 * protection) that TabPilot always enforces regardless of toggles.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;
  const Storage = TP.Storage;

  const MODES = [
    { value: 'manual', name: 'Manual', desc: 'Default. You control everything — no automatic discarding. Switch to Balanced once you have reviewed your protection settings.' },
    { value: 'balanced', name: 'Balanced', desc: 'Automatically discards eligible inactive tabs after the idle period. Conferencing and web-mail sites are protected by the seeded whitelist.' },
    { value: 'aggressive', name: 'Aggressive', desc: 'Discards more, sooner (half the idle period, minimum 2 minutes) to prioritize memory recovery. All protection rules still apply.' },
    { value: 'protected', name: 'Protected', desc: 'No automatic discarding at all. Your selected tabs and whitelist are preserved; optimize manually anytime.' }
  ];

  const MONITORS = [
    { id: 'cpu', name: 'CPU' },
    { id: 'memory', name: 'RAM' },
    { id: 'disk', name: 'Disk' },
    { id: 'network', name: 'Network' },
    { id: 'gpu', name: 'GPU' }
  ];

  /* small DOM helper */
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function row(labelText, description, control) {
    const rowEl = el('div', 'set-row');
    const left = el('div', 'set-row-left');
    const label = el('span', 'set-label', labelText);
    left.appendChild(label);
    if (description) left.appendChild(el('span', 'set-desc', description));
    rowEl.appendChild(left);
    rowEl.appendChild(control);
    return rowEl;
  }

  function toggle(checked, disabled, onChange) {
    const input = el('input');
    input.type = 'checkbox';
    input.className = 'tp-toggle';
    input.checked = !!checked;
    input.disabled = !!disabled;
    input.addEventListener('change', function () { onChange(input.checked); });
    return input;
  }

  function select(options, value, onChange) {
    const selectEl = el('select');
    options.forEach(function (opt) {
      const option = el('option', null, opt.label);
      option.value = opt.value;
      selectEl.appendChild(option);
    });
    selectEl.value = String(value);
    selectEl.addEventListener('change', function () { onChange(selectEl.value); });
    return selectEl;
  }

  /* ------------------------------------------------------------------ *
   * Mount
   * ------------------------------------------------------------------ */

  function mount(container) {
    const root = el('div', 'tp-settings');

    Storage.getSettings().then(function (settings) {
      render(root, settings);
      container.innerHTML = '';
      container.appendChild(root);

      // Re-render when settings change elsewhere — unless the user is
      // mid-interaction here (focused control); then skip this round.
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area !== 'local' || !(Storage.KEYS.SETTINGS in changes)) return;
        const next = Storage.normalizeSettings(changes[Storage.KEYS.SETTINGS].newValue);
        if (root.contains(document.activeElement) && document.activeElement !== document.body) return;
        render(root, next);
      });
    });
  }

  function render(root, settings) {
    root.innerHTML = '';

    root.appendChild(group('Monitoring', 'tp-group-monitoring', function (body) {
      body.appendChild(row('Monitor resources', 'Master switch for all sampling while a TabPilot page is open',
        toggle(settings.monitoring.enabled, false, function (v) { save({ monitoring: { enabled: v } }); })));

      const monitorWrap = el('div', 'monitor-toggles');
      MONITORS.forEach(function (m) {
        const chip = el('label', 'monitor-chip');
        const cb = el('input');
        cb.type = 'checkbox';
        cb.className = 'tp-toggle';
        cb.checked = settings.monitoring.monitors[m.id];
        cb.addEventListener('change', function () {
          const patch = { monitors: {} };
          patch.monitors[m.id] = cb.checked;
          save({ monitoring: patch });
        });
        chip.appendChild(cb);
        chip.appendChild(el('span', null, m.name));
        monitorWrap.appendChild(chip);
      });
      body.appendChild(row('Individual monitors', 'Disable monitors you don\u2019t need', monitorWrap));

      body.appendChild(row('Refresh interval', 'How often metrics are sampled while a page is open',
        select(Storage.VALID.intervals.map(function (v) { return { value: v, label: v / 1000 === 1 ? '1 second' : v / 1000 + ' seconds' }; }),
          settings.monitoring.intervalMs,
          function (v) { save({ monitoring: { intervalMs: Number(v) } }); })));

      body.appendChild(row('History retention', 'How long performance samples are kept',
        select(Storage.VALID.retentions.map(function (v) { return { value: v, label: v + ' minutes' }; }),
          settings.monitoring.retentionMinutes,
          function (v) { save({ monitoring: { retentionMinutes: Number(v) } }); })));

      body.appendChild(row('Performance graphs', 'Draw history sparklines and charts',
        toggle(settings.monitoring.showGraphs, false, function (v) { save({ monitoring: { showGraphs: v } }); })));
    }));

    root.appendChild(group('Optimization', 'tp-group-optimization', function (body) {
      const modeGrid = el('div', 'set-mode-grid');
      MODES.forEach(function (mode) {
        const label = el('label', 'set-mode-card');
        const radio = el('input');
        radio.type = 'radio';
        radio.name = 'set-mode';
        radio.value = mode.value;
        radio.checked = settings.optimization.mode === mode.value;
        radio.addEventListener('change', function () { if (radio.checked) save({ optimization: { mode: mode.value } }); });
        label.appendChild(radio);
        label.appendChild(el('strong', null, mode.name));
        label.appendChild(el('span', null, mode.desc));
        modeGrid.appendChild(label);
      });
      body.appendChild(modeGrid);

      const autoToggle = toggle(
        settings.optimization.autoDiscard && (settings.optimization.mode === 'balanced' || settings.optimization.mode === 'aggressive'),
        !(settings.optimization.mode === 'balanced' || settings.optimization.mode === 'aggressive'),
        function (v) { save({ optimization: { autoDiscard: v } }); }
      );
      body.appendChild(row('Automatic optimization', 'Runs a 1-minute event-driven check while enabled (Balanced/Aggressive modes)',
        autoToggle));

      body.appendChild(row('Idle period', 'Tabs untouched for this long become eligible for discarding',
        select(Storage.VALID.idleMinutes.map(function (v) { return { value: v, label: Util.formatMinutesLong(v) }; }),
          settings.optimization.idleMinutes,
          function (v) { save({ optimization: { idleMinutes: Number(v) } }); })));

      const minKeep = el('input');
      minKeep.type = 'number';
      minKeep.min = '1';
      minKeep.max = '20';
      minKeep.step = '1';
      minKeep.value = String(settings.optimization.minPreservedTabs);
      minKeep.addEventListener('change', function () {
        save({ optimization: { minPreservedTabs: Util.clamp(parseInt(minKeep.value, 10) || 5, 1, 20) } });
      });
      body.appendChild(row('Minimum preserved tabs', 'TabPilot never discards down past this many live (non-discarded) tabs', minKeep));

      body.appendChild(row('Preserve recently accessed tabs', 'Automatic runs always ignore tabs used within the last 5 minutes, even in Aggressive mode',
        toggle(settings.optimization.preserveRecentTabs, false, function (v) { save({ optimization: { preserveRecentTabs: v } }); })));
    }));

    root.appendChild(group('Protection', 'tp-group-protection', function (body) {
      const lock = el('span', 'set-lock', 'Always enforced');
      body.appendChild(row('Never discard active tabs', 'Hard Chrome API rule — the focused tab can never be discarded', lock));

      const lock2 = el('span', 'set-lock', 'Always enforced');
      body.appendChild(row('Never discard pinned tabs', 'Hard Chrome API rule — pinned tabs are never discarded', lock2));

      const lock3 = el('span', 'set-lock', 'Always enforced');
      body.appendChild(row('Keep user-protected tabs', 'Sites you protect (shield button) are never discarded — not even by an explicit selection; the shield covers every tab of that site and, for normal windows, survives restarts. Unprotect first. Only the hostname is stored on disk. Incognito tabs and local/internal pages (file:, chrome:, …) are protected for the current session only — never on disk.', lock3));

      body.appendChild(row('Never discard audible tabs', 'Tabs playing audio (audible flag — the only reliable media signal available to extensions)',
        toggle(settings.protection.neverAudible, false, function (v) { save({ protection: { neverAudible: v } }); })));

      body.appendChild(whitelistWidget());
    }));

    root.appendChild(group('Appearance', 'tp-group-appearance', function (body) {
      const wrap = el('div', 'set-theme-options');
      [['dark', 'Dark'], ['light', 'Light'], ['system', 'System']].forEach(function (pair) {
        const label = el('label', 'set-mode-card set-theme-card');
        const radio = el('input');
        radio.type = 'radio';
        radio.name = 'set-theme';
        radio.value = pair[0];
        radio.checked = settings.appearance.theme === pair[0];
        radio.addEventListener('change', function () { if (radio.checked) save({ appearance: { theme: pair[0] } }); });
        label.appendChild(radio);
        label.appendChild(el('strong', null, pair[1]));
        label.appendChild(el('span', null, pair[0] === 'system' ? 'Follows your OS preference' : pair[0] === 'dark' ? 'Charcoal with green accents' : 'Bright paper theme'));
        wrap.appendChild(label);
      });
      const rowEl = el('div', 'set-row');
      rowEl.appendChild(wrap);
      body.appendChild(rowEl);

      body.appendChild(row('Website favicons', 'Show site favicons served by Chrome from its own local favicon cache (the _favicon endpoint — the extension never contacts any website). Disable for letter tiles.',
        toggle(settings.privacy.favicons, false, function (v) { save({ privacy: { favicons: v } }); })));
    }));

    root.appendChild(group('Privacy & data', 'tp-group-privacy', function (body) {
      const note = el('p', 'd-note',
        'TabPilot stores everything on this device. There is no backend, no account, no analytics, ' +
        'no telemetry and no network request made by the extension itself. Browsing data never leaves your machine. ' +
        'Tab titles and URLs are never written to disk — protection stores bare hostnames only, optimization ' +
        'summaries store tab ids and domains only, and anything originating in an incognito window stays in ' +
        'RAM-backed session storage that dies with the browser. Favicons are rendered by Chrome from its own local cache.');
      body.appendChild(note);

      const usage = el('div', 'set-row');
      const usageLeft = el('div', 'set-row-left');
      usageLeft.appendChild(el('span', 'set-label', 'Local data stored'));
      const usageValue = el('span', 'set-desc', 'calculating…');
      usageLeft.appendChild(usageValue);
      usage.appendChild(usageLeft);
      body.appendChild(usage);
      Storage.getLocalUsage().then(function (bytes) {
        usageValue.textContent = bytes == null ? 'not reported by this Chrome version' : '≈ ' + Util.formatBytes(bytes);
      });

      const clearHistory = el('button', 'tp-btn', 'Clear monitoring history');
      clearHistory.addEventListener('click', function () {
        Storage.remove(Storage.KEYS.HISTORY).then(function () {
          clearHistory.textContent = 'History cleared';
          setTimeout(function () { clearHistory.textContent = 'Clear monitoring history'; }, 1800);
          Storage.getLocalUsage().then(function (bytes) {
            usageValue.textContent = bytes == null ? 'not reported' : '≈ ' + Util.formatBytes(bytes);
          });
        });
      });
      body.appendChild(row('Performance history', 'Deletes all stored samples immediately', clearHistory));

      const reset = el('button', 'tp-btn tp-btn-danger', 'Reset all settings');
      reset.addEventListener('click', function () {
        if (reset.dataset.confirming === '1') {
          Storage.resetSettings();
          reset.textContent = 'Reset all settings';
          delete reset.dataset.confirming;
        } else {
          reset.dataset.confirming = '1';
          reset.textContent = 'Click again to confirm reset';
          setTimeout(function () {
            reset.textContent = 'Reset all settings';
            delete reset.dataset.confirming;
          }, 3000);
        }
      });
      body.appendChild(row('Settings', 'Restores every option to its default value (whitelist and protected tabs are kept)', reset));
    }));
  }

  function group(title, className, fill) {
    const section = el('section', 'tp-card set-group ' + (className || ''));
    section.appendChild(el('h2', 'set-group-title', title));
    const body = el('div', 'set-group-body');
    fill(body);
    section.appendChild(body);
    return section;
  }

  /* ------------------------------------------------------------------ *
   * Whitelist manager
   * ------------------------------------------------------------------ */

  function whitelistWidget() {
    const wrap = el('div', 'whitelist-widget');
    wrap.appendChild(el('div', 'set-label', 'Protected domains (whitelist)'));
    wrap.appendChild(el('span', 'set-desc',
      'Tabs from these domains are never discarded automatically. "example.com" covers all subdomains; "www." is ignored; single-label hosts like "localhost" are accepted. Bare generic TLDs ("com", "org", "net", "edu", "gov") and public suffixes ("co.uk", "com.bd", …) are refused outright — one would protect the whole web; single labels that might be your intranet host ("dev", "wiki") ask you to confirm. A fresh install seeds conferencing and web-mail sites — remove any you don\u2019t need.'));

    const form = el('form', 'whitelist-form');
    const input = el('input');
    input.type = 'text';
    input.placeholder = 'example.com or localhost';
    input.setAttribute('aria-label', 'Domain to protect');
    const addBtn = el('button', 'tp-btn', 'Add domain');
    addBtn.type = 'submit';
    form.appendChild(input);
    form.appendChild(addBtn);
    wrap.appendChild(form);

    const status = el('div', 'whitelist-status text-3', '');
    wrap.appendChild(status);

    const list = el('div', 'whitelist-list');
    wrap.appendChild(list);

    // v1.6.2 audit R2: a single label that looks like a public suffix
    // ("dev", "wiki") may still be a real intranet host — the first Add
    // shows the warning and relabels the button; the next Add of the SAME
    // entry confirms ("Add anyway"). Editing the input cancels the step.
    let pendingConfirm = null;
    function resetConfirm() {
      pendingConfirm = null;
      addBtn.textContent = 'Add domain';
      delete addBtn.dataset.confirming;
    }
    input.addEventListener('input', resetConfirm);

    function refresh() {
      TP.Protection.getState().then(function (state) {
        list.innerHTML = '';
        status.textContent = state.whitelist.length
          ? state.whitelist.length + ' domain' + (state.whitelist.length > 1 ? 's' : '') + ' protected'
          : 'No domains protected yet';
        state.whitelist.forEach(function (domain) {
          const item = el('div', 'whitelist-item tp-chip');
          item.appendChild(el('span', 'mono', domain));
          const remove = el('button', 'tp-icon-btn whitelist-remove', '×');
          remove.title = 'Remove ' + domain;
          remove.setAttribute('aria-label', 'Remove ' + domain);
          remove.addEventListener('click', function () {
            TP.Protection.removeDomain(domain).then(refresh);
          });
          item.appendChild(remove);
          list.appendChild(item);
        });
      });
    }

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const domain = input.value.trim();
      if (!domain) return;
      const confirmingSame = pendingConfirm &&
        TP.Util.normalizeDomain(domain) === pendingConfirm;
      TP.Protection.addDomain(domain, { confirmed: confirmingSame }).then(function () {
        input.value = '';
        resetConfirm();
        refresh();
      }).catch(function (err) {
        // v1.6.1 audit N4 / v1.6.2 audit R2: rejections explain exactly
        // why (public suffixes, invalid input); suffix-like single labels
        // become a two-step confirm instead of a flat refusal.
        if (err && err.confirmable) {
          pendingConfirm = TP.Util.normalizeDomain(domain);
          addBtn.textContent = 'Add anyway';
          addBtn.dataset.confirming = '1';
        } else {
          resetConfirm();
        }
        status.textContent = err.message;
      });
    });

    // Keep in sync when the whitelist changes from the dashboard tab manager.
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'local' && Storage.KEYS.WHITELIST in changes) refresh();
    });

    refresh();
    return wrap;
  }

  /* ------------------------------------------------------------------ */

  function save(partial) {
    return Storage.setSettings(partial).catch(function (err) {
      console.warn('[TabPilot] failed to persist settings:', err && err.message);
    });
  }

  TP.SettingsUI = { mount: mount };
})(typeof self !== 'undefined' ? self : globalThis);
