/**
 * TabPilot — resource-monitor.js
 * Sampling orchestrator. Pulls one snapshot per tick from every enabled
 * provider and hands it to the UI.
 *
 * Lightweightness rules enforced here:
 *  - No sampling happens in the service worker, ever. Monitoring runs only
 *    while a TabPilot page (popup / dashboard) is open and visible.
 *  - Tabs hidden by the user are skipped (visibilitychange), so a background
 *    dashboard tab costs nothing.
 *  - One failure in one provider never breaks the loop — each provider is
 *    isolated and reports its own status/error.
 *  - The CPU provider runs first and its snapshot is shared with the network
 *    provider (one chrome.system.cpu call feeds two metrics).
 *
 * Extensibility: registerProvider() is the documented hook for a future
 * native companion application (see docs/API-COMPATIBILITY.md). A companion
 * could feed real per-process / per-tab metrics through this same interface
 * without any change to the UI layer.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});

  const registry = {};
  const ORDER = ['cpu', 'memory', 'network', 'disk', 'gpu'];

  /** Register (or replace) a metrics provider: { id, sample(prev, ctx) }. */
  function registerProvider(provider) {
    if (provider && provider.id && typeof provider.sample === 'function') {
      registry[provider.id] = provider;
    }
  }

  function isHidden() {
    return typeof document !== 'undefined' && document.visibilityState === 'hidden';
  }

  /**
   * Create a monitor bound to a UI page.
   * opts = {
   *   intervalMs,               sampling period (>= 500 ms)
   *   enabled(id),              predicate: is provider enabled in settings?
   *   onSample(snapshot),       callback per successful tick
   *   quickStart                optional: extra tick ~450 ms after start so
   *                             CPU% appears fast in the popup
   * }
   */
  function create(opts) {
    const intervalMs = Math.max(500, (opts && opts.intervalMs) || 1000);
    const enabled = (opts && opts.enabled) || function () { return true; };
    const onSample = (opts && opts.onSample) || function () {};

    let timer = null;
    let quickTimer = null;
    let prev = {};
    let running = false;

    async function sampleAll() {
      const ctx = { t: Date.now() };
      const snapshot = { t: ctx.t };
      const providers = ORDER.concat(Object.keys(registry).filter(function (id) {
        return ORDER.indexOf(id) === -1;
      }));
      for (let i = 0; i < providers.length; i++) {
        const id = providers[i];
        const provider = registry[id];
        if (!provider || !enabled(id)) continue;
        try {
          const result = await provider.sample(prev[id], ctx);
          snapshot[id] = result;
          if (result) {
            // Keep private underscore fields out of the returned snapshot.
            prev[id] = result;
          }
        } catch (err) {
          snapshot[id] = { status: 'error', reason: (err && err.message) || 'Provider failed' };
        }
        if (id === 'cpu') ctx.cpu = snapshot.cpu; // share with network provider
      }
      return snapshot;
    }

    async function tick() {
      if (isHidden()) return;   // hidden dashboard = zero sampling cost
      try {
        const snapshot = await sampleAll();
        if (running) onSample(snapshot);
      } catch (err) {
        // Never crash the page loop; report and carry on.
        try { console.warn('[TabPilot] sample tick failed:', err && err.message); } catch (e) {}
      }
    }

    return {
      start: function () {
        if (running) return;
        running = true;
        if (TP.Cpu && TP.Cpu.setSampleInterval) TP.Cpu.setSampleInterval(intervalMs);
        tick(); // immediate first sample (CPU reports "warming")
        if (opts && opts.quickStart) {
          quickTimer = setTimeout(function () { if (running) tick(); }, 450);
        }
        timer = setInterval(tick, intervalMs);
      },
      stop: function () {
        running = false;
        if (timer) { clearInterval(timer); timer = null; }
        if (quickTimer) { clearTimeout(quickTimer); quickTimer = null; }
      },
      isRunning: function () { return running; },
      sampleOnce: sampleAll,
      get last() { return prev; }
    };
  }

  /* Built-in providers. */
  registerProvider(TP.Cpu);
  registerProvider(TP.Memory);
  registerProvider(TP.Network);
  registerProvider(TP.Disk);
  registerProvider(TP.Gpu);

  TP.Metrics = {
    registerProvider: registerProvider,
    create: create,
    ids: ORDER.slice()
  };
})(typeof self !== 'undefined' ? self : globalThis);
