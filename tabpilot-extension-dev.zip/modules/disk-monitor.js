/**
 * TabPilot — disk-monitor.js
 * Storage metrics via chrome.system.storage.
 *
 * Actually available (measured):
 *  - list of storage units with type, name and total capacity (getInfo),
 *  - per-unit available capacity (getAvailableCapacity) -> used = difference.
 * NOT available through any stable Chrome extension API:
 *  - disk read/write activity and throughput. There is no public API that
 *    exposes disk I/O to extensions, so the snapshot marks it "unavailable"
 *    and the UI never invents a value.
 *
 * getAvailableCapacity() is relatively expensive per volume, so samples are
 * cached for a short interval (internal throttle) and the number of volumes
 * is capped.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  const MAX_VOLUMES = 8;
  const CACHE_MS = 3000;       // capacity values: cached for 3 s
  const DEVICE_CACHE_MS = 60000; // device list: cached for 60 s

  let lastSample = null;
  let lastSampleAt = 0;
  let deviceCache = null;
  let deviceCacheAt = 0;

  const IO_UNAVAILABLE = {
    status: 'unavailable',
    reason: 'Chrome does not expose disk read/write activity or throughput to ' +
            'extensions — no public API exists for disk I/O.'
  };

  function sample() {
    if (!(root.chrome && chrome.system && chrome.system.storage)) {
      return Promise.resolve(unavailable('chrome.system.storage is not available ' +
        '(missing permission or unsupported platform).'));
    }
    const now = Date.now();
    if (lastSample && (now - lastSampleAt) < CACHE_MS) {
      return Promise.resolve(lastSample);
    }
    return getDevices().then(function (devices) {
      const capped = (devices || []).slice(0, MAX_VOLUMES);
      return Promise.all(capped.map(function (device) {
        return Util.callApi(chrome.system.storage, 'getAvailableCapacity', device.id)
          .then(function (res) { return res && typeof res.availableCapacity === 'number' ? res.availableCapacity : null; })
          .catch(function () { return null; });
      })).then(function (freeValues) {
        const volumes = capped.map(function (device, i) {
          const free = freeValues[i];
          const capacity = typeof device.capacity === 'number' ? device.capacity : null;
          const used = (free != null && capacity != null) ? capacity - free : null;
          return {
            id: device.id,
            name: device.name || device.id,
            type: device.type || 'unknown',     // fixed | removable | unknown
            capacity: capacity,
            available: free,
            used: used,
            usedPct: (used != null && capacity > 0) ? (used / capacity) * 100 : null
          };
        });
        const snapshot = {
          status: volumes.some(function (v) { return v.usedPct != null; }) ? 'available' : 'unavailable',
          source: 'chrome.system.storage.getInfo() + getAvailableCapacity()',
          volumes: volumes,
          primary: pickPrimary(volumes),
          io: IO_UNAVAILABLE
        };
        lastSample = snapshot;
        lastSampleAt = now;
        return snapshot;
      });
    }).catch(function (err) {
      return unavailable(
        Util.looksLikePermissionError(err)
          ? 'Storage API blocked — permission required. ' + err.message
          : 'Storage API error: ' + err.message,
        Util.looksLikePermissionError(err) ? 'permission' : 'error'
      );
    });
  }

  function getDevices() {
    const now = Date.now();
    if (deviceCache && (now - deviceCacheAt) < DEVICE_CACHE_MS) {
      return Promise.resolve(deviceCache);
    }
    return Util.callApi(chrome.system.storage, 'getInfo').then(function (devices) {
      deviceCache = Array.isArray(devices) ? devices : [];
      deviceCacheAt = now;
      return deviceCache;
    });
  }

  /** The fixed volume that most likely holds the user profile. */
  function pickPrimary(volumes) {
    const fixed = volumes.filter(function (v) { return v.type === 'fixed'; });
    const pool = fixed.length ? fixed : volumes;
    return pool.length ? pool[0] : null;
  }

  function unavailable(reason, status) {
    return {
      status: status || 'unavailable',
      reason: reason,
      volumes: [],
      primary: null,
      io: IO_UNAVAILABLE
    };
  }

  TP.Disk = { id: 'disk', sample: sample };
})(typeof self !== 'undefined' ? self : globalThis);
