/**
 * TabPilot — theme.js
 * Theme handling shared by all extension pages: dark / light / system,
 * persisted in settings, applied via the [data-theme] attribute using the
 * tokens from assets/base.css. Page contexts only (uses document/matchMedia).
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Storage = TP.Storage;

  const state = { setting: 'dark', unwatch: null };

  function resolve(theme) {
    if (theme !== 'system') return theme;
    try {
      return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    } catch (err) {
      return 'dark';
    }
  }

  function apply(theme) {
    state.setting = theme;
    const resolved = resolve(theme);
    document.documentElement.dataset.theme = resolved;
    return resolved;
  }

  /** Live theme management: settings-driven + OS-scheme listener. */
  function init() {
    return Storage.getSettings().then(function (settings) {
      apply(settings.appearance.theme);
      // OS theme change -> only relevant while set to "system".
      try {
        const mq = window.matchMedia('(prefers-color-scheme: light)');
        mq.addEventListener('change', function () {
          if (state.setting === 'system') apply('system');
        });
      } catch (err) { /* older engines use addListener; degrade silently */ }
      // Settings changed in another TabPilot page.
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area !== 'local' || !(Storage.KEYS.SETTINGS in changes)) return;
        const next = changes[Storage.KEYS.SETTINGS].newValue;
        if (next && next.appearance && next.appearance.theme) apply(next.appearance.theme);
      });
      return state.setting;
    });
  }

  TP.Theme = { init: init, apply: apply, resolve: resolve };
})(typeof self !== 'undefined' ? self : globalThis);
