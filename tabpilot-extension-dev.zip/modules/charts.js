/**
 * TabPilot — charts.js
 * Minimal Canvas 2D renderers for the performance graphs. No chart library,
 * no external assets. Rendering is:
 *  - DPI-aware (crisp lines on HiDPI screens),
 *  - theme-aware (colors come from CSS custom properties with fallbacks),
 *  - trivially cheap: a few hundred points per redraw, redraws are folded
 *    into one requestAnimationFrame by the callers.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});

  /* ------------------------------------------------------------------ *
   * Internals
   * ------------------------------------------------------------------ */

  function cssVar(name, fallback) {
    try {
      const value = getComputedStyle(root.document.documentElement).getPropertyValue(name);
      return (value && value.trim()) || fallback;
    } catch (err) {
      return fallback;
    }
  }

  function prepare(canvas) {
    if (!canvas || !canvas.getContext) return null;
    const dpr = Math.max(1, (root.devicePixelRatio || 1) * 1);
    const width = canvas.clientWidth || 0;
    const height = canvas.clientHeight || 0;
    if (width < 4 || height < 4) return null;
    const need = Math.round(width * dpr) + 'x' + Math.round(height * dpr);
    if (canvas.dataset.dprSize !== need) {
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      canvas.dataset.dprSize = need;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    return { ctx: ctx, w: width, h: height };
  }

  function niceRange(seriesList, fixedMin, fixedMax) {
    let min = Infinity, max = -Infinity;
    seriesList.forEach(function (points) {
      points.forEach(function (p) {
        if (p[1] < min) min = p[1];
        if (p[1] > max) max = p[1];
      });
    });
    if (!isFinite(min)) { min = fixedMin != null ? fixedMin : 0; max = fixedMax != null ? fixedMax : 1; }
    if (fixedMin != null) min = fixedMin;
    if (fixedMax != null) max = fixedMax;
    if (max - min < 1e-9) max = min + 1;
    return { min: min, max: max };
  }

  /* ------------------------------------------------------------------ *
   * Public renderers
   * ------------------------------------------------------------------ */

  /**
   * Full chart with grid + one or more line series.
   * cfg = {
   *   series: [{ points: [[t, v]...], color, label, fill }],
   *   fixedMin, fixedMax  optional axis clamp (e.g. 0..100 for %),
   *   nowMs               window end (defaults to Date.now())
   *   windowMs            visible time window
   *   format              value formatter for the right-side max labels
   * }
   */
  function drawChart(canvas, cfg) {
    const prepared = prepare(canvas);
    if (!prepared) return;
    const ctx = prepared.ctx;
    const w = prepared.w, h = prepared.h;
    const gridColor = cssVar('--chart-grid', 'rgba(128,140,160,0.14)');
    const textColor = cssVar('--chart-text', 'rgba(128,140,160,0.55)');

    const nowMs = cfg.nowMs || Date.now();
    const windowMs = cfg.windowMs || 300000;
    const tStart = nowMs - windowMs;
    const tEnd = nowMs + windowMs * 0.02; // small right padding
    const seriesList = cfg.series || [];
    const range = niceRange(seriesList.map(function (s) { return s.points || []; }),
                            cfg.fixedMin, cfg.fixedMax);
    const padTop = 6, padBottom = 4;

    // Empty state: not enough data yet -> tell the user instead of an
    // almost-blank grid (which reads as broken).
    let pointCount = 0;
    seriesList.forEach(function (s) {
      (s.points || []).forEach(function (p) { if (p[0] >= tStart) pointCount++; });
    });
    if (pointCount < 2) {
      ctx.fillStyle = textColor;
      ctx.font = '11px Inter, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Collecting data…', w / 2, h / 2);
      ctx.textAlign = 'left';
      return;
    }

    const x = function (t) { return ((t - tStart) / (tEnd - tStart)) * w; };
    const y = function (v) {
      const frac = (v - range.min) / (range.max - range.min);
      return padTop + (1 - frac) * (h - padTop - padBottom);
    };

    // Horizontal grid lines (4 rows)
    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const yy = Math.round(padTop + (i / 4) * (h - padTop - padBottom)) + 0.5;
      ctx.beginPath();
      ctx.moveTo(0, yy);
      ctx.lineTo(w, yy);
      ctx.stroke();
    }

    // Left-bottom time label & right-top max label (kept minimal)
    ctx.fillStyle = textColor;
    ctx.font = '10px ui-monospace, monospace';
    ctx.textBaseline = 'top';
    ctx.fillText('-' + Math.round(windowMs / 60000) + 'm', 2, h - 13);
    ctx.textAlign = 'right';
    const maxLabel = cfg.format ? cfg.format(range.max) : String(Math.round(range.max));
    ctx.fillText(maxLabel, w - 2, 2);
    ctx.textAlign = 'left';

    seriesList.forEach(function (s) {
      const points = s.points || [];
      if (!points.length) return;
      const pointsInWindow = points.filter(function (p) { return p[0] >= tStart; });
      if (!pointsInWindow.length) return;

      // Path
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 1.6;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.beginPath();
      let started = false;
      pointsInWindow.forEach(function (p) {
        const px = x(p[0]);
        const py = y(p[1]);
        if (!started) { ctx.moveTo(px, py); started = true; }
        else ctx.lineTo(px, py);
      });
      ctx.stroke();

      // Subtle area fill for single-series charts
      if (s.fill !== false && seriesList.length === 1) {
        ctx.lineTo(x(pointsInWindow[pointsInWindow.length - 1][0]), h - padBottom);
        ctx.lineTo(x(pointsInWindow[0][0]), h - padBottom);
        ctx.closePath();
        ctx.globalAlpha = 0.14;
        ctx.fillStyle = s.color;
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    });
  }

  /** Tiny inline sparkline for the resource cards. */
  function drawSparkline(canvas, points, opts) {
    const prepared = prepare(canvas);
    if (!prepared) return;
    const ctx = prepared.ctx;
    const w = prepared.w, h = prepared.h;
    const values = (points || []).map(function (p) { return p[1]; });
    if (values.length < 2) return;

    let min = Infinity, max = -Infinity;
    values.forEach(function (v) { if (v < min) min = v; if (v > max) max = v; });
    if (opts && opts.fixedMin != null) min = opts.fixedMin;
    if (opts && opts.fixedMax != null) max = opts.fixedMax;
    if (max - min < 1e-9) max = min + 1;

    ctx.strokeStyle = (opts && opts.color) || '#3ddc97';
    ctx.lineWidth = 1.4;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.beginPath();
    values.forEach(function (v, i) {
      const px = (i / (values.length - 1)) * (w - 2) + 1;
      const py = h - 2 - ((v - min) / (max - min)) * (h - 4);
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    });
    ctx.stroke();

    if (!opts || opts.fill !== false) {
      const lastX = w - 1;
      const firstX = 1;
      ctx.lineTo(lastX, h - 1);
      ctx.lineTo(firstX, h - 1);
      ctx.closePath();
      ctx.globalAlpha = 0.12;
      ctx.fillStyle = (opts && opts.color) || '#3ddc97';
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  /** Micro bar chart for per-core CPU usage. */
  function drawCoreBars(canvas, perCore, opts) {
    const prepared = prepare(canvas);
    if (!prepared) return;
    const ctx = prepared.ctx;
    const w = prepared.w, h = prepared.h;
    const values = perCore || [];
    if (!values.length) return;
    const maxBars = 16;
    const count = Math.min(maxBars, values.length);
    const step = values.length / count;
    const buckets = [];
    for (let i = 0; i < count; i++) {
      let sum = 0, n = 0;
      for (let j = Math.floor(i * step); j < Math.floor((i + 1) * step) && j < values.length; j++) {
        sum += values[j]; n++;
      }
      buckets.push(n ? sum / n : 0);
    }
    const gap = 2;
    const barW = Math.max(2, (w - gap * (buckets.length - 1)) / buckets.length);
    const color = (opts && opts.color) || '#5aa9ff';
    buckets.forEach(function (v, i) {
      const barH = Math.max(1.5, (Math.min(100, Math.max(0, v)) / 100) * (h - 2));
      ctx.fillStyle = color;
      ctx.globalAlpha = v > 80 ? 0.95 : v > 40 ? 0.75 : 0.45;
      ctx.fillRect(Math.round(i * (barW + gap)), h - barH, Math.round(barW), barH);
    });
    ctx.globalAlpha = 1;
  }

  TP.Charts = {
    drawChart: drawChart,
    drawSparkline: drawSparkline,
    drawCoreBars: drawCoreBars
  };
})(typeof self !== 'undefined' ? self : globalThis);
