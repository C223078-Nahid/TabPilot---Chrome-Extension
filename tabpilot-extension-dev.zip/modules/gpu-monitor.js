/**
 * TabPilot — gpu-monitor.js
 * GPU identification via WebGL (page contexts only).
 *
 * Actually available:
 *  - GPU vendor and renderer/device name, read from the WebGL
 *    WEBGL_debug_renderer_info extension (real hardware info exposed by the
 *    graphics stack). When the debug extension is missing, masked values
 *    are used and marked "estimated".
 * Unavailable and never fabricated:
 *  - GPU utilization %. No Chrome extension API exposes it, period.
 *  - GPU process info outside ChromeOS (no per-process data on other
 *    platforms; see cpu-monitor.js).
 *
 * The info is static, so it is fetched ONCE per page load and the WebGL
 * context is immediately released via WEBGL_lose_context — zero ongoing
 * GPU cost from TabPilot.
 *
 * The service worker has no DOM/WebGL, so sampling there reports an honest
 * "unavailable" state.
 */
(function (root) {
  'use strict';

  const TP = root.TabPilot || (root.TabPilot = {});
  const Util = TP.Util;

  let cached = null;
  let fetching = null;

  const UTIL_UNAVAILABLE = {
    status: 'unavailable',
    reason: 'No Chrome extension API exposes GPU utilization. TabPilot never displays a guessed value.'
  };

  function sample() {
    if (cached) return Promise.resolve(Object.assign({}, cached));
    if (typeof document === 'undefined') {
      return Promise.resolve({
        status: 'unavailable',
        reason: 'GPU detection requires a page context (WebGL); it is not available in the service worker.',
        vendor: null, renderer: null, utilization: UTIL_UNAVAILABLE
      });
    }
    if (fetching) return fetching;
    fetching = detect().then(function (snap) {
      cached = snap;
      fetching = null;
      return Object.assign({}, snap);
    });
    return fetching;
  }

  function detect() {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = 1;
      let gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
      if (!gl) {
        return Promise.resolve({
          status: 'unavailable',
          reason: 'WebGL is unavailable in this browser session — GPU info cannot be read.',
          vendor: null, renderer: null, utilization: UTIL_UNAVAILABLE
        });
      }
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      let vendor, renderer, status;
      if (dbg) {
        vendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) || null;
        renderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || null;
        status = 'available';
      } else {
        // Masked strings ("WebKit WebGL") — still a real answer, but generic.
        vendor = gl.getParameter(gl.VENDOR) || null;
        renderer = gl.getParameter(gl.RENDERER) || null;
        status = 'estimated';
      }
      // Release the GPU resources immediately — one-shot detection.
      const lose = gl.getExtension('WEBGL_lose_context');
      if (lose) lose.loseContext();
      gl = null;
      return Promise.resolve({
        status: status,
        reason: status === 'available'
          ? 'Read from WEBGL_debug_renderer_info (real GPU string).'
          : 'Debug renderer info blocked — showing masked WebGL strings.',
        vendor: typeof vendor === 'string' ? vendor : null,
        renderer: typeof renderer === 'string' ? renderer : null,
        device: shortDeviceName(renderer),
        utilization: UTIL_UNAVAILABLE
      });
    } catch (err) {
      return Promise.resolve({
        status: 'error',
        reason: 'GPU detection failed: ' + err.message,
        vendor: null, renderer: null, utilization: UTIL_UNAVAILABLE
      });
    }
  }

/**
 * Distill a short, headline-friendly device name from a WebGL renderer
 * string, e.g. "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 ...)" ->
 * "NVIDIA GeForce RTX 3060". Falls back to the raw string.
 */
function shortDeviceName(renderer) {
  if (typeof renderer !== 'string' || !renderer) return null;
  // Software rasterizers first — name them explicitly.
  const soft = renderer.match(/SwiftShader|llvmpipe|Software Adapter|softpipe/i);
  if (soft) return soft[0].replace(/^soft/i, 'Soft') + ' (software renderer)';
  let inner = renderer;
  const angle = inner.match(/^ANGLE\s*\((.*)\)\s*$/i);
  if (angle) inner = angle[1];
  const parts = inner.split(/,\s*/);
  // ANGLE strings are "vendor, device details..." — prefer the device part.
  let device = (parts.length > 1 ? parts[1] : parts[0]) || inner;
  // Strip API/feature noise: "NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0"
  device = device.split(/\s+(?:Direct3D|Direct|OpenGL|Vulkan|Metal|vs_|ps_)/i)[0];
  device = device.replace(/\s*\(.*$/, '').trim() || device.trim();
  return device || null;
}

  TP.Gpu = { id: 'gpu', sample: sample };
})(typeof self !== 'undefined' ? self : globalThis);
