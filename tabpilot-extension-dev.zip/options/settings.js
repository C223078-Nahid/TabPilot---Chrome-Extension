/**
 * TabPilot — options/settings.js
 * Thin bootstrap for the standalone options page: theme + shared settings.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    self.TabPilot.Theme.init().then(function () {
      self.TabPilot.SettingsUI.mount(document.getElementById('settingsRoot'));
    });
  });
})();
